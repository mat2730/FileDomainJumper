/*
 * Martin Alexander Thomsen den 16 Juli 2024
 */

 /*
Nyt Zip program
    rootfolder=.
    destfolder=skal kunne være den samme
    groupby=rootfolder, levl1folder, levl2folder
    grouptime=year,month,day
    ignoreZipfilesWhenZip=true
        if (false) extract zip files and zip them again into new the structure of zip files
    type=zip,unzip
    zip filerne skal gruperes efter year, month, 
 */
package com.maikenwinterberg.zipauto;

import java.io.File;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ZipAuto {

    public enum GROUP_BY_FOLDER {
        ROOT, LEVEL1, LEVEL2
    }

    public enum GROUP_BY_TIME {
        YEAR, MONTH, DAY
    }

    public static boolean processDirectory(File source, File dest, GROUP_BY_FOLDER g1, GROUP_BY_TIME g2) {        
        return true;
    }

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
