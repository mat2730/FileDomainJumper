echo unInstalling service...
sudo systemctl stop ${serviceName}.service
sudo rm /etc/systemd/system/${serviceName}.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s