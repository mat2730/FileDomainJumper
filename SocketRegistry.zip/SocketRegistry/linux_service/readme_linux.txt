This program requires that Java 1.17+ is installed on you computer.

Installation on linux in 3 stepts:
1) Install Java onto your system if not allready installed
    sudo apt-get install openjdk-17-jdk2) 
2) Execute the installRegistryService.sh: 4 files are being created to the folder
3) Open up for port 6666 on your firewall
