echo installing registry service
java --class-path ./target/classes com.maikenwinterberg.linuxserviceinstaller.LinuxServiceInstaller MaikenWinterbergRegistry ../bin startRegistry.sh conf
echo done installing registry service
#ls -a
#sleep 10s
