echo installing registry service
java --class-path ./target/LinuxServiceInstaller-1.0-SNAPSHOT.jar martin.linuxserviceinstaller.LinuxServiceInstaller registry .. startRegistry.sh
echo done installing registry service
#ls -a
#sleep 10s
