java --class-path target/classes:./lib/h2-2.2.224.jar martin/socketregistry/server/Registry 6666 > /dev/null
