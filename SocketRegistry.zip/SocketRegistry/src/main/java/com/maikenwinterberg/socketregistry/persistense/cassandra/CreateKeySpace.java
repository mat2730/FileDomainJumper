/*
* from page: https://medium.com/@rajithabhanuka/connecting-java-to-cassandra-database-with-a-simple-application-b2fd53995af2
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maikenwinterberg.socketregistry.persistense.cassandra;

/**
 *
 * @author bhanuka
 */
public class CreateKeySpace {

    public static void main(String[] args) {
        try {
            DBConnector connector = new DBConnector();
            connector.connectdb("172.18.0.1", 9042);

            final String createmovieKeySpace = "CREATE KEYSPACE IF NOT EXISTS registry_keyspace WITH "
                    + "replication = {'class' : 'SimpleStrategy','replication_factor' :3}";

            connector.getSession().execute(createmovieKeySpace);

            connector.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
