/*
* from page: https://medium.com/@rajithabhanuka/connecting-java-to-cassandra-database-with-a-simple-application-b2fd53995af2
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maikenwinterberg.socketregistry.persistense.cassandra;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

/**
 *
 * @author bhanuka
 */
public class InsertData {

    public static void main(String[] args) {
        try {
            DBConnector connector = new DBConnector();
            connector.connectdb("localhost", 9042);

            final String insertQuery = "INSERT INTO movies_keyspace.movies (title,year,descreiption,rating) "
                    + "VALUES (?,?,?,?)";

            PreparedStatement psInsert = connector.getSession().prepare(insertQuery);
            BoundStatement bsInsert = psInsert.bind("Annabelle", 2019, "Horror", "4.5");
            connector.getSession().execute(bsInsert);

            connector.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
