/*
* from page: https://medium.com/@rajithabhanuka/connecting-java-to-cassandra-database-with-a-simple-application-b2fd53995af2
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.maikenwinterberg.socketregistry.persistense.cassandra;

import com.datastax.driver.core.BoundStatement;
import com.datastax.driver.core.PreparedStatement;

/**
 *
 * @author bhanuka
 */
public class UpdateData {

    public static void main(String[] args) {
        try {
            DBConnector connector = new DBConnector();
            connector.connectdb("localhost", 9042);

            final String updateQuery = "UPDATE movies_keyspace.movies SET rating= ? WHERE "
                    + "title= ? AND year = ?";

            PreparedStatement psUpdate = connector.getSession().prepare(updateQuery);
            BoundStatement bsUpdate = psUpdate.bind("10.0", "Annabelle", 2019);
            connector.getSession().execute(bsUpdate);

            connector.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
