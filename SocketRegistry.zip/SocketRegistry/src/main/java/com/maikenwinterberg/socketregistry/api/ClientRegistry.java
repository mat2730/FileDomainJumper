/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * Changes to this file you must do in coloboration with me(Martin Alexander Thomsen) see license.txt
 * You can extends the ClientRegistry and make your own version. 
 * You are welcome to change between private, public and protected keywords. That way you can override what you dont like
 */
public class ClientRegistry {

    private final static boolean DEBUG = false;
    private final static boolean INFO = false;
    private static ClientRegistry registrySingleton;

    private Object key2SecurityImpl = null;
    private final String registryIp;
    private final int registryPort;
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in;
    private String defaultDomainNameOfClient;
    private boolean useExternalID;

    //enum CMD {
    //    com.maikenwinterberg.RegisterCmd, lookup, unregister, registerpublickey;
    //}
    enum CMD {
        com_maikenwinterberg_socketregistry_server_RegisterCmd,
        com_maikenwinterberg_socketregistry_server_LookupCmd,
        com_maikenwinterberg_socketregistry_server_UnregisterCmd,
        com_maikenwinterberg_socketregistry_server_RegisterpublickeyCmd,
        com_maikenwinterberg_socketregistry_server_SendInfoToParentRegistriesCmd,
        com_maikenwinterberg_socketregistry_server_ReceiveBulkRegistrationCmd
    }

    public enum TYPE {
        jdbc, socket, map;
    }

    private ClientRegistry(String defaultDomainNameOfClient, String ip, int port) throws Exception {
        String newip = getRedirectUrl(ip);
        if (!newip.equals(ip)) {
            System.out.println("redirection url from " + ip + " to " + newip);
            ip = newip;
        }
        this.registryIp = ip;
        this.registryPort = port;
        this.defaultDomainNameOfClient = defaultDomainNameOfClient;
        System.out.println("connecing to socket " + registryIp + ":" + registryPort + "...");
        this.socket = new Socket();
        //if (!redirect(ip)) {
        this.socket = new Socket(getRedirectUrl(ip), port);
        //socket.connect(new InetSocketAddress(ip, port), 5000);
        this.out = new DataOutputStream(
                socket.getOutputStream());
        this.in = new DataInputStream(
                socket.getInputStream());
        System.out.println("connected to socket " + registryIp + ":" + registryPort);
        //} else {
        //    System.out.println("do notconnect to redirected ip " + registryIp + ":" + registryPort);
        //}
    }

    public boolean isLocalhost() {
        if (registryIp.equalsIgnoreCase("locahost")) {
            return true;
        } else if (registryIp.equalsIgnoreCase("127.0.0.1")) {
            return true;
        } else if (DomainCheck.getExternalId() != null && registryIp.equalsIgnoreCase(DomainCheck.getExternalId())) {
            return true;
        }
        return false;
    }

    //without this method all redirect urls will make the system stop. 
    private String getRedirectUrl(String canonicalUrl) throws Exception {
        if (canonicalUrl == null || canonicalUrl.equals("localhost")) {
            return canonicalUrl;
        }
        try {
            //https
            URL url = new URL("https://" + canonicalUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(true);
            int status = connection.getResponseCode();
            String redirectedUrl = null;
            if (status == HttpURLConnection.HTTP_MOVED_PERM || status == HttpURLConnection.HTTP_MOVED_TEMP) {
                redirectedUrl = connection.getHeaderField("Location");
                int index = redirectedUrl.indexOf("//");
                if (index != -1) {
                    redirectedUrl = redirectedUrl.substring(index + 2);
                }
            }
            connection.disconnect();
            if (redirectedUrl != null) {
                System.out.println("https redirecting registry url " + canonicalUrl + "->" + redirectedUrl);
                return redirectedUrl;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        /* http can be hacked with a man in the middle attack.
        try {
            //http
            URL url = new URL("http://" + canonicalUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setInstanceFollowRedirects(true);
            int status = connection.getResponseCode();
            String redirectedUrl = null;
            if (status == HttpURLConnection.HTTP_MOVED_PERM || status == HttpURLConnection.HTTP_MOVED_TEMP) {
                redirectedUrl = connection.getHeaderField("Location");
                int index = redirectedUrl.indexOf("//");
                if (index != -1) {
                    redirectedUrl = redirectedUrl.substring(index + 2);
                }
            }
            connection.disconnect();
            if (redirectedUrl != null) {
                System.out.println("http redirecting registry url " + canonicalUrl + "->" + redirectedUrl);
                return redirectedUrl;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }*/
        //default
        return canonicalUrl;
    }

    /*
    private boolean redirect(String location) {
        boolean wasRedirected = false;

        if (location) {
            new URL(location).openConnection().with {
                con
                        -> // We'll do redirects ourselves
                        con.instanceFollowRedirects = false // Get the response code, and the location to jump to (in case of a redirect)
                        location = con.getHeaderField("Location")
                if (!wasRedirected && location) {
                    wasRedirected = true
                }
                // Read the HTML and close the inputstream
                //pageContent = con.inputStream.withReader {it.text }

            }
        }
        return wasRedirected;
    }*/
    public void reconnect() throws Exception {
        reconnect(0);
    }

    private void reconnect(int count) throws Exception {
        if (count >= 2) {
            throw new IllegalStateException("Cannot connnect to registry");
        }
        try {
            //first close
            out.close();
            in.close();
            socket.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            //reconnecting to registry
            System.out.println("reconnecting to registry at " + registryIp + ":" + registryPort);
            //if (!redirect(ip)) {
            String ip = registryIp;
            if (DomainCheck.getExternalId() != null) {
                System.out.println("comparing " + ip + " with " + DomainCheck.getExternalId());
                if (ip.trim().equalsIgnoreCase(DomainCheck.getExternalId())) {
                    ip = "localhost";
                }
            }
            this.socket = new Socket(getRedirectUrl(ip), registryPort);
            //this.socket.connect(new InetSocketAddress(registryIp, registryPort), 5000);
            this.out = new DataOutputStream(
                    socket.getOutputStream());
            this.in = new DataInputStream(socket.getInputStream());
            //} else {
            //    throw new IllegalStateException("this is a redirect url " + ip + ": port");
            //}
            if (!this.socket.isClosed()) {
                boolean ok = registerpublickey(2);
                if (ok) {
                    System.out.println("succeded to reconnect to registry at " + registryIp + ":" + registryPort);
                    return;
                } else {
                    throw new IllegalStateException("Cannot connnect to registry");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("failed to reconnect to registry at " + registryIp + ":" + registryPort);
        throw new IllegalStateException("Cannot connnect to registry");
    }

    private void setKey2SecurityImpl(Object key2SecurityImpl) {
        this.key2SecurityImpl = key2SecurityImpl;
    }

    @Override
    protected void finalize() throws Throwable {
        in.close();
        out.close();
        socket.close();
    }

    private String sendCmd(boolean encrypt, DataOutputStream out, DataInputStream in, String cmd) throws Exception {
        return sendCmd(0, encrypt, out, in, cmd);
    }

    private String sendCmd(int count, boolean encrypt, DataOutputStream out, DataInputStream in, String cmd) throws Exception {
        if (INFO) {
            System.out.println("Writing to server: " + Registry.PROTOCOL + cmd);
        }

        if (encrypt) {
            //DO NOT CHANGE THIS - see license.txt 
            out.writeUTF(Registry.PROTOCOL + RegistrySecurity.textEncrypt(key2SecurityImpl, this, cmd));
        } else {
            //DO NOT CHANGE THIS - see license.txt 
            out.writeUTF(Registry.PROTOCOL + "encrypted=false" + cmd);
        }
        if (DEBUG) {
            System.out.println("reading input...");
        }
        String line = null;
        try {
            line = in.readUTF();
            if (line != null) {
                if (line.startsWith("encrypted=false")) {
                    line = line.substring(15);
                    if (line.contains("v") && line.contains("stacktrace")) {
                        throw new IllegalStateException(line);
                    }
                } else {
                    line = RegistrySecurity.textDecrypt(key2SecurityImpl, this, line);
                }
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (line == null && count == 0) {
            System.out.println("received empty response from server");
            //the registry is down, give it 5 minutes to get back up
            try {
                // Thread.sleep(1000 * 60 * 5);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            reconnect(count++);
            return sendCmd(2, encrypt, out, in, cmd);
        }

        if (INFO) {
            System.out.println("line response from server: " + line);
        }
        if (DEBUG) {
            System.out.println("done with client");
        }
        return line;
    }

    public static final ClientRegistry getRegistryInstance(String domainNameOfClient, String ipOrDomainnameOfRegistry, int portofRegistry, boolean useExternalID, boolean singleton) throws Exception {
        if (domainNameOfClient == null) {
            domainNameOfClient = "localhost";
            //throw new IllegalArgumentException("Invalid paramenters ");
        }
        if (!singleton) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            ClientRegistry aNewRegistry = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry);
            aNewRegistry.useExternalID = useExternalID;
            aNewRegistry.updateDefaultDomainNameOnClient();//in case of invalid domainname
            aNewRegistry.registerpublickey();
            return aNewRegistry;
        } else if (registrySingleton == null) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            registrySingleton = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry);
            registrySingleton.useExternalID = useExternalID;
            registrySingleton.updateDefaultDomainNameOnClient();//in case of invalid domainname
            registrySingleton.registerpublickey();
        }
        return registrySingleton;
    }

    public void updateDefaultDomainNameOnClient() throws Exception {
        //in the case of dynamic ip address
        if (useExternalID) {
            //String oldExternalId = DomainCheck.getExternalId();
            defaultDomainNameOfClient = DomainCheck.updateDefaultDomainNameOnClient(defaultDomainNameOfClient);
            //String externalId = DomainCheck.getExternalId();
            //if (oldExternalId != null && externalId != null && !oldExternalId.equals(externalId)) {
            //the external Id has changed get a new SecureKey from server
            //registerpublickey();
            //}
        }
    }

    private boolean registerpublickey() {
        return registerpublickey(0);
    }

    /*
    if this method returns a value the clientDomainName is overridden
     */
    private boolean registerpublickey(int count) {
        try {
            StringBuilder builder = new StringBuilder();
            builder.append("securityplugin");
            builder.append(ICommand.EQUAL_SEPERATOR);
            if (key2SecurityImpl == null) {
                builder.append(RegistrySecurity.DEFAULT_SECURITY_IMPL.getClass().getName());
            } else {
                builder.append(key2SecurityImpl.toString());
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterpublickeyCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(defaultDomainNameOfClient);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("publickey");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(RegistrySecurity.toBase64(key2SecurityImpl, RegistrySecurity.getKeyPair(key2SecurityImpl, this).getPublic()));
            String secretKeyAsEncryptedBase64 = sendCmd(count, false, out, in, builder.toString());
            try {
                if (count == 0 && key2SecurityImpl == null) {
                    IRegistrySecurity s = (IRegistrySecurity) Class.forName(secretKeyAsEncryptedBase64).newInstance();
                    setKey2SecurityImpl(s.getClass().getName());
                    //do one more call to new security plugin
                    System.out.println("changing security plugin to " + secretKeyAsEncryptedBase64);
                    registerpublickey(1);
                }
            } catch (Exception ex) {
                //ignore
            }
            if (secretKeyAsEncryptedBase64 != null) {
                if (secretKeyAsEncryptedBase64.startsWith("encrypted=false")) {
                    throw new SecurityException(secretKeyAsEncryptedBase64.substring(15));
                } else if (secretKeyAsEncryptedBase64.startsWith("status" + ICommand.EQUAL_SEPERATOR + "error")) {
                    throw new SecurityException(secretKeyAsEncryptedBase64);
                }

                if (DEBUG) {
                    System.out.println("secretKey received from registry, base64=" + secretKeyAsEncryptedBase64);
                }
                PrivateKey privateKey = RegistrySecurity.getKeyPair(key2SecurityImpl, this).getPrivate();
                byte[] secretKeyAsEncrypted = RegistrySecurity.fromBase64(key2SecurityImpl, secretKeyAsEncryptedBase64); //String secretKeyAsEncryptedBase64);
                byte[] seretKeyAsBytes = RegistrySecurity.privateKeyDecrypt(key2SecurityImpl, privateKey, secretKeyAsEncrypted);
                SecretKey secretKey = RegistrySecurity.toSecretKey(key2SecurityImpl, seretKeyAsBytes);//AESUtil.fromBytes(seretKeyAsDecrypted);
                RegistrySecurity.setSecretKey(key2SecurityImpl, this, secretKey);
                if (DEBUG) {
                    System.out.println("secretKey received from registry " + secretKey);
                }
                return true;
            }
            System.out.println("cannot register public key at " + registryIp + ":" + registryPort);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public ClientRegistryAddress registerSocket(String serviceName, String ip, String port, String publicRSAKeyAsBase64) {
        return registerSocket(null, serviceName, null, ip, port, publicRSAKeyAsBase64, null);
    }

    public ClientRegistryAddress registerSocket(String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        return registerSocket(0, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
    }

    private ClientRegistryAddress registerSocket(int count, String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        try {
            if (serviceName == null || ip == null || port == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.socket.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("ip");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(ip);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("port");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(port);
            if (publicRSAKeyAsBase64 != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("public_key");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(publicRSAKeyAsBase64);
            }
            if (securityImpl != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("security_impl");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(securityImpl);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                //try again the registry might have been restarted
                System.out.println("registerSocket error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerSocket(1, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
            } else {
                System.out.println("registerSocket error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ClientRegistryAddress registerAttributes(String serviceName, Map<String, String> attributes) {
        return registerAttributes(null, serviceName, null, attributes);
    }

    public ClientRegistryAddress registerAttributes(String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        return registerAttributes(0, domainName, serviceName, registrationId, attributes);
    }

    private ClientRegistryAddress registerAttributes(int count, String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        try {
            if (serviceName == null || attributes == null || attributes.isEmpty()) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.map.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            try {
                for (Iterator<String> i = attributes.keySet().iterator(); i.hasNext();) {
                    String attributeName = i.next();
                    String attributeValue = i.next();
                    builder.append(ICommand.ATTR_SEPERATOR);
                    builder.append(attributeName);
                    builder.append(ICommand.EQUAL_SEPERATOR);
                    builder.append(attributeValue);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("registerAttributes error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerAttributes(1, domainName, serviceName, registrationId, attributes);
            } else {
                System.out.println("registerAttributes error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ClientRegistryAddress registerJDBC(String serviceName, String driver, String url, String userName, String password) {
        return registerJDBC(null, serviceName, null, driver, url, userName, password);
    }

    public ClientRegistryAddress registerJDBC(String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        return registerJDBC(0, domainName, serviceName, registrationId, driver, url, userName, password);
    }

    private ClientRegistryAddress registerJDBC(int count, String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        try {
            if (serviceName == null || driver == null || url == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_RegisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.jdbc.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("driver");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(driver);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("url");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(url);
            if (userName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("username");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(userName);
            }
            if (password != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("password");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(password);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("registerJDBC error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerJDBC(1, domainName, serviceName, registrationId, driver, url, userName, password);
            } else {
                System.out.println("registerJDBC error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean UnRegister(TYPE type, String serviceName) {
        return UnRegister(type, null, serviceName);
    }

    public boolean UnRegister(TYPE type, String domainName, String serviceName) {
        return UnRegister(0, type, domainName, serviceName);

    }

    private boolean UnRegister(int count, TYPE type, String domainName, String serviceName) {
        try {
            if (type == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_UnregisterCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainName");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return true;
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("UnRegister error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return UnRegister(1, type, domainName, serviceName);
            }
            if (DEBUG) {
                System.out.println(response);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public List<AbstractRegisration> lookup(TYPE type, String lookupDomainName, String serviceName) {
        return lookup(type, null, lookupDomainName, serviceName);
    }

    public List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName);
    }

    /*
    @param int fetchSize
    Max fetch size is controlled by com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB.maxFetchSize
    currently its 100
     */
    public List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, int offset, int fetchSize) {
        Map attributes = new HashMap();
        attributes.put("offset", offset);
        attributes.put("fetchsize", fetchSize);
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName, attributes);
    }

    public List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, Map<String, String> attributes) {
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName, attributes);
    }

    private List<AbstractRegisration> lookup(int count, TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        return lookup(count, type, domainNameOfClient, lookupDomainName, serviceName, new HashMap());
    }

    private List<AbstractRegisration> lookup(int count, TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName, Map<String, String> attributes) {
        //TODO avoid loop - implement domainTrace
        List<AbstractRegisration> registrationList = new LinkedList<>();
        try {
            domainNameOfClient = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainNameOfClient);
            if (lookupDomainName == null) {
                lookupDomainName = domainNameOfClient;
            }
            lookupDomainName = DomainCheck.getLookupDomainName(lookupDomainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_LookupCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            if (domainNameOfClient != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("domainName");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(domainNameOfClient);
            }
            if (lookupDomainName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("lookupDomainName");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(lookupDomainName);
            }
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            if (attributes != null) {
                for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
                    String key = (String) i.next();
                    String value = (String) attributes.get(key);
                    if (key != null && value != null) {
                        builder.append(ICommand.ATTR_SEPERATOR);
                        builder.append(key.toLowerCase());
                        builder.append(ICommand.EQUAL_SEPERATOR);
                        builder.append(value);
                    }
                }
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("lookupType");
            builder.append(ICommand.EQUAL_SEPERATOR);
            if (lookupDomainName != null && serviceName != null) {
                builder.append("lookupByDomainAndService");
            } else if (lookupDomainName != null) {
                builder.append("lookupByDomain");
            } else if (serviceName != null) {
                builder.append("lookupByService");
            } else {
                builder.append("lookupAll");
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("lookup error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return lookup(1, type, domainNameOfClient, lookupDomainName, serviceName);
            } else if (response != null) {
                StringTokenizer tok = new StringTokenizer(response, ICommand.REG_SEPERATOR);
                //boolean firstRun = true;
                while (tok.hasMoreTokens()) {
                    String registationAsString = tok.nextToken();
                    StringTokenizer tok2 = new StringTokenizer(registationAsString, ICommand.ATTR_SEPERATOR);
                    Map<String, String> registrationAsMap = new HashMap();
                    while (tok2.hasMoreTokens()) {
                        StringTokenizer tok3 = new StringTokenizer(tok2.nextToken(), ICommand.EQUAL_SEPERATOR);
                        String name = null;
                        if (tok3.hasMoreTokens()) {
                            name = tok3.nextToken();
                        }
                        String value = null;
                        if (tok3.hasMoreTokens()) {
                            value = tok3.nextToken();
                        }
                        if (DEBUG) {
                            System.out.println("Adding value to map " + name.toLowerCase() + "," + value);
                        }
                        if (name != null && value != null) {
                            registrationAsMap.put(name.toLowerCase(), value);
                        }
                    }
                    AbstractRegisration registration = null;
                    String typeAsString = registrationAsMap.get("type");
                    if (typeAsString == null) {
                        if (registrationAsMap.get("ip") != null && registrationAsMap.get("port") != null) {
                            typeAsString = TYPE.socket.toString();
                        } else if (registrationAsMap.get("driver") != null && registrationAsMap.get("url") != null) {
                            typeAsString = TYPE.jdbc.toString();
                        } else {
                            typeAsString = TYPE.map.toString();
                        }
                    }
                    if (DEBUG) {
                        System.out.println("type " + typeAsString);
                    }
                    if (typeAsString.equalsIgnoreCase(TYPE.socket.toString())) {
                        registration = new SocketRegistration();
                        ((SocketRegistration) registration).setIp(registrationAsMap.get("ip"));
                        ((SocketRegistration) registration).setPort(registrationAsMap.get("port"));
                    } else if (typeAsString.equalsIgnoreCase(TYPE.jdbc.toString())) {
                        registration = new JDBCRegistration();
                        ((JDBCRegistration) registration).setDriver(registrationAsMap.get("driver"));
                        ((JDBCRegistration) registration).setUrl(registrationAsMap.get("url"));
                        ((JDBCRegistration) registration).setUserName(registrationAsMap.get("username"));
                        ((JDBCRegistration) registration).setPassword(registrationAsMap.get("password"));
                    } else {
                        registration = new MapRegistration();
                    }
                    registration.addAttributes(registrationAsMap);
                    registration.setDomainName(registrationAsMap.get("domainname"));
                    registration.setServicenName(registrationAsMap.get("servicename"));
                    registration.setType(TYPE.valueOf(typeAsString));
                    registration.setClientDomainName(domainNameOfClient);
                    registrationList.add(registration);
                }
            }
        } catch (Exception ex) {
            //ignore
            ex.printStackTrace();
        }
        return registrationList;
    }

    public boolean receiveBulkRegistrations(String domainnames) {
        return receiveBulkRegistrations(0, domainnames);
    }

    private boolean receiveBulkRegistrations(int count, String domainnames) {
        try {
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.com_maikenwinterberg_socketregistry_server_ReceiveBulkRegistrationCmd.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("registry");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(registryIp).append(":").append(registryPort);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainName");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(defaultDomainNameOfClient);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainnames");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainnames);
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("lookup error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return receiveBulkRegistrations(1, domainnames);
            } else if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return true;
            }
            System.out.println("error sending infor to parent " + response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    @Override
    public String toString() {
        return registryIp + ":" + registryPort;
    }
}
