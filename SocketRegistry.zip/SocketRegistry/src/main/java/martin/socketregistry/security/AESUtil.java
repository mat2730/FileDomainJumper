/*
 * Martin Alexander Thomsen den 2 Juli 2024
 */
package martin.socketregistry.security;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * 
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * copy from: https://www.baeldung.com/java-aes-encryption-decryption
 * tilfølelser: simpleEncrypt, simpleDecrypt, getProjectKey og
 * getProjectParivameterSpec
 *
 * fix: When I use the code from baeldung over a socket connection I need to add
 * chars-in the beginning og teh text
 */
class AESUtil {

    //fix: the encrypting do not work properly over a socket connetion. Therefore, I insert a dummy string.
    public static final String DUMMY_STRING = "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXxXXXXXXXXXXXXXXXXXXXXX;;;";
    public static final boolean DEBUG = false;
    private static Map<Object, SecretKey> PROJECT_KEYS = new HashMap();
    private static IvParameterSpec projectParivameterSpec;

    public static String encrypt(String algorithm, String input, SecretKey key,
            IvParameterSpec iv) throws Exception {

        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] cipherText = cipher.doFinal(input.getBytes());
        return Base64.getEncoder()
                .encodeToString(cipherText);
    }

    public static byte[] encrypt(String algorithm, byte[] input, SecretKey key,
            IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] cipherText = cipher.doFinal(input);
        return Base64.getEncoder().encode(cipherText);
    }

    private static String decrypt(String algorithm, String cipherText, SecretKey key,
            IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] plainText = cipher.doFinal(Base64.getDecoder()
                .decode(cipherText));
        return new String(plainText);
    }

    private static byte[] decrypt(String algorithm, byte[] cipherText, SecretKey key,
            IvParameterSpec iv) throws Exception {
        Cipher cipher = Cipher.getInstance(algorithm);
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] bytes = cipher.doFinal(Base64.getDecoder()
                .decode(cipherText));
        return bytes;
    }

    public static IvParameterSpec generateIv() {
        byte[] iv = new byte[16];
        new SecureRandom().nextBytes(iv);
        return new IvParameterSpec(iv);
    }

    public static SecretKey generateKey(int n) throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(n);
        SecretKey key = keyGenerator.generateKey();
        return key;
    }

    public static SecretKey getKeyFromPassword(String password, String salt)
            throws Exception {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt.getBytes(), 65536, 256);
        SecretKey secret = new SecretKeySpec(factory.generateSecret(spec)
                .getEncoded(), "AES");
        return secret;
    }

    public static String simpleEncrypt(Object objectKey, String input) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        //fix: the encrypting do not work properly over a socket connetion. Therefore, I insert a dummy string.
        if (DUMMY_STRING != null) {
            input = DUMMY_STRING + input;
        }
        String cipherText = encrypt(algorithm, input, key, ivParameterSpec);
        return cipherText;
    }

    public static byte[] simpleDecrypt(Object objectKey, byte[] cipherText) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        byte[] plainText = decrypt(algorithm, cipherText, key, ivParameterSpec);
        if (DUMMY_STRING != null) {
            plainText = Arrays.copyOfRange(plainText, 16, plainText.length);
        }

        /*
        if (AESUtil.DUMMY_STRING != null) {
            try {
                //the firt on is a dummy
                int index = plainText.indexOf(";;;");
                if (index != -1) {
                    plainText = plainText.substring(index + 3);
                }
            } catch (Exception ex) {
            }
        }*/
        return plainText;
    }

    public static byte[] simpleEncrypt(Object objectKey, byte[] input) throws Exception {
        if (DUMMY_STRING != null) {
            byte[] DUMMY_ARRAY = new byte[16];
            byte[] result = new byte[DUMMY_ARRAY.length + input.length];
            System.arraycopy(DUMMY_ARRAY, 0, result, 0, DUMMY_ARRAY.length);
            System.arraycopy(input, 0, result, DUMMY_ARRAY.length, input.length);
            input = result;
        }
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        //fix: the encrypting do not work properly over a socket connetion. Therefore, I insert a dummy string.
        byte[] cipherText = encrypt(algorithm, input, key, ivParameterSpec);
        return cipherText;
    }

    public static String simpleDecrypt(Object objectKey, String cipherText) throws Exception {
        SecretKey key = getProjectKey(objectKey);
        IvParameterSpec ivParameterSpec = getProjectParivameterSpec();
        String algorithm = "AES/CBC/PKCS5Padding";
        String plainText = decrypt(algorithm, cipherText, key, ivParameterSpec);
        if (AESUtil.DUMMY_STRING != null) {
            try {
                //the firt on is a dummy
                int index = plainText.indexOf(";;;");
                if (index != -1) {
                    plainText = plainText.substring(index + 3);
                }
            } catch (Exception ex) {
            }
        }
        return plainText;
    }

    public static SecretKey getProjectKey(Object keyObject) throws Exception {
        //File keyFile = new File("conf/key.obj");
        SecretKey projectKey = PROJECT_KEYS.get(keyObject);
        /* dont save key to disk - security risk
        if (projectKey == null) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(keyFile))) {
                projectKey = (SecretKey) ois.readObject();
                PROJECT_KEYS.put(projectName, projectKey);
            } catch (Exception ex) {
            }
        }*/
        if (projectKey == null) {
            projectKey = generateKey(128);
            PROJECT_KEYS.put(keyObject, projectKey);
            //if (DEBUG) {
            System.out.println("generating SecretKey: " + projectKey+ ", keyObject="+keyObject + ", keyObject.hashCode="+keyObject.hashCode());
            //}
            /*    
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(keyFile))) {
                oos.writeObject(projectKey);
            } catch (Exception ex) {
            }*/
        }
        return projectKey;
    }

    public static void setProjectKey(Object keyObject, SecretKey secretKey) {
        PROJECT_KEYS.put(keyObject, secretKey);
    }

    public static IvParameterSpec getProjectParivameterSpec() throws Exception {
        File keyFile = new File("conf/iv.obj");
        if (projectParivameterSpec == null) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(keyFile))) {
                projectParivameterSpec = (IvParameterSpec) ois.readObject();
            } catch (Exception ex) {
            }
        }
        if (projectParivameterSpec == null) {
            projectParivameterSpec = AESUtil.generateIv();
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(keyFile))) {
                oos.writeObject(projectParivameterSpec);
            } catch (Exception ex) {
            }
        }
        return projectParivameterSpec;
    }

    public static String toBase64(SecretKey key) {
        String base64 = Base64.getMimeEncoder().encodeToString(key.getEncoded());
        return base64;
    }

    public static SecretKey fromBase64(String base64) throws Exception {
        byte[] encodedKey = Base64.getMimeDecoder().decode(base64);
        SecretKey originalKey = new SecretKeySpec(encodedKey, 0, encodedKey.length, "AES");
        return originalKey;
    }

    public static SecretKey fromBytes(byte[] bytes) throws Exception {
        SecretKey originalKey = new SecretKeySpec(bytes, 0, bytes.length, "AES");
        return originalKey;
    }

    //test
    public static void main(String arg[]) throws Exception {
        String cipherText = AESUtil.simpleEncrypt("P1", "cmd=register;domainName=maikenwinterberg.com;serviceName=MariaDB1;type=jdbc;driver=org.mariadb.jdbc.Driver;url=jdbc:mariadb://localhost:3306/project1;username=dbusername;password=xx");
        String plainText = AESUtil.simpleDecrypt("P1", cipherText);
        String base64 = toBase64(PROJECT_KEYS.get("P1"));

        System.out.println(cipherText);
        System.out.println(plainText);
        PROJECT_KEYS.put("P1", fromBase64(base64));
        cipherText = AESUtil.simpleEncrypt("P1", "cmd=register;domainName=maikenwinterberg.com;serviceName=MariaDB1;type=jdbc;driver=org.mariadb.jdbc.Driver;url=jdbc:mariadb://localhost:3306/project1;username=dbusername;password=xx");
        plainText = AESUtil.simpleDecrypt("P1", cipherText);
        System.out.println(cipherText);
        System.out.println(plainText);

    }
}
