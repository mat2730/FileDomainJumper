/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package martin.socketregistry.persistense;

import java.util.Map;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IRegistryDB {
    
    public String register(String socketClientIP, Map<String, String> attributes) throws Exception;

    public String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception;

    public String lookup(String socketClientIP, Map<String, String> attributes) throws Exception;
}
