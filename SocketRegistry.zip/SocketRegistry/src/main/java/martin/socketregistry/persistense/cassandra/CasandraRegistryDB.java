/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package martin.socketregistry.persistense.cassandra;

import java.util.Map;
import martin.socketregistry.persistense.IRegistryDB;

/**
 *
 * @author Martin Alexander Thomsen
 */
//TODO implement this method
public class CasandraRegistryDB implements IRegistryDB{
    
    @Override
    public String register(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String lookup(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
