/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package martin.socketregistry.persistense;

import martin.socketregistry.persistense.hashmap.RegistryHashMapDB;
import martin.socketregistry.server.Registry;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PersistenceFactory {

    public static IRegistryDB getRegistryDB() {
        try {
            String className = Registry.getProperty("registry_db_class");
            if (className != null) {
                IRegistryDB registryDB = (IRegistryDB) Class.forName(className).newInstance();
                return registryDB;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return new RegistryHashMapDB();
    }
}
