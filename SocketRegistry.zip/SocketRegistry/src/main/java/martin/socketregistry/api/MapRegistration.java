/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package martin.socketregistry.api;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 */
public class MapRegistration extends AbstractRegisration{
    
}
