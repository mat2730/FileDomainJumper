/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package martin.socketregistry.api;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.security.PrivateKey;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import martin.socketregistry.security.RegistrySecurity;
import martin.socketregistry.server.DomainCheck;
import martin.socketregistry.server.ICommand;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ClientRegistry {

    private final static boolean DEBUG = false;
    private final static boolean INFO = false;
    private static ClientRegistry registrySingleton;

    private final String registryIp;
    private final int registryPort;
    private final Socket socket;
    private final DataOutputStream out;
    private final DataInputStream in;
    private String defaultDomainNameOfClient;
    private boolean doDomainCheckOnClient;

    enum CMD {
        register, lookup, unregister, registerpublickey;
    }

    public enum TYPE {
        jdbc, socket, map;
    }

    private ClientRegistry(String defaultDomainNameOfClient, String ip, int port) throws Exception {
        this.registryIp = ip;
        this.registryPort = port;
        this.socket = new Socket(ip, port);
        this.out = new DataOutputStream(
                socket.getOutputStream());
        this.in = new DataInputStream(
                socket.getInputStream());
        this.defaultDomainNameOfClient = defaultDomainNameOfClient;
    }

    @Override
    protected void finalize() throws Throwable {
        in.close();
        out.close();
        socket.close();
    }

    private String sendCmd(boolean encrypt, DataOutputStream out, DataInputStream in, String cmd) throws Exception {
        if (INFO) {
            System.out.println("Writing to server: " + cmd);
        }
        if (encrypt) {
            out.writeUTF(RegistrySecurity.textEncrypt(null, this, cmd));
        } else {
            out.writeUTF("encrypted=false" + cmd);
        }
        if (DEBUG) {
            System.out.println("reading input...");
        }
        String line = null;
        try {
            line = in.readUTF();
            if (line.startsWith("encrypted=false")) {
                line = line.substring(15);
            } else {
                line = RegistrySecurity.textDecrypt(null, this, line);
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (INFO) {
            System.out.println("Response from server: " + line);
        }
        if (DEBUG) {
            System.out.println("done with client");
        }
        return line;
    }

    public static final ClientRegistry getRegistryInstance(String domainNameOfClient, String ipOrDomainnameOfRegistry, int portofRegistry, boolean doDomainCheckOnClient, boolean singleton) throws Exception {
        if (domainNameOfClient == null) {
            domainNameOfClient = "localhost";
            //throw new IllegalArgumentException("Invalid paramenters ");
        }
        if (!singleton) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            ClientRegistry aNewRegistry = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry);
            aNewRegistry.doDomainCheckOnClient = doDomainCheckOnClient;
            aNewRegistry.updateDefaultDomainNameOnClient();//in case of invalid domainname
            aNewRegistry.registerpublickey();
            return aNewRegistry;
        } else if (registrySingleton == null) {
            //domainNameOfClient = DomainCheck.getDefaultDomainNameOnClient(domainNameOfClient);
            registrySingleton = new ClientRegistry(domainNameOfClient, ipOrDomainnameOfRegistry, portofRegistry);
            registrySingleton.doDomainCheckOnClient = doDomainCheckOnClient;
            registrySingleton.updateDefaultDomainNameOnClient();//in case of invalid domainname
            registrySingleton.registerpublickey();
        }
        return registrySingleton;
    }

    public void updateDefaultDomainNameOnClient() throws Exception {
        //in the case of dynamic ip address
        if (doDomainCheckOnClient) {
            String oldExternalId = DomainCheck.getExternalId();
            defaultDomainNameOfClient = DomainCheck.updateDefaultDomainNameOnClient(defaultDomainNameOfClient);
            String externalId = DomainCheck.getExternalId();
            if (oldExternalId != null && externalId != null && !oldExternalId.equals(externalId)) {
                //the external Id has changed get a new SecureKey from server
                registerpublickey();
            }
        }
    }

    /*
    if this method returns a value the clientDomainName is overridden
     */
    private boolean registerpublickey() {
        try {
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.registerpublickey.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(defaultDomainNameOfClient);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("publickey");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(RegistrySecurity.toBase64(null, RegistrySecurity.getKeyPair(null, this).getPublic()));
            String secretKeyAsEncryptedBase64 = sendCmd(false, out, in, builder.toString());
            if (secretKeyAsEncryptedBase64 != null) {
                if (secretKeyAsEncryptedBase64.startsWith("encrypted=false")) {
                    throw new SecurityException(secretKeyAsEncryptedBase64.substring(15));
                } else if (secretKeyAsEncryptedBase64.startsWith("status===error")) {
                    throw new SecurityException(secretKeyAsEncryptedBase64);
                }

                if (DEBUG) {
                    System.out.println("secretKey received from registry, base64=" + secretKeyAsEncryptedBase64);
                }
                PrivateKey privateKey = RegistrySecurity.getKeyPair(null, this).getPrivate();
                byte[] secretKeyAsEncrypted = RegistrySecurity.fromBase64(null, secretKeyAsEncryptedBase64); //String secretKeyAsEncryptedBase64);
                byte[] seretKeyAsBytes = RegistrySecurity.privateKeyDecrypt(null, privateKey, secretKeyAsEncrypted);
                SecretKey secretKey = RegistrySecurity.toSecretKey(null, seretKeyAsBytes);//AESUtil.fromBytes(seretKeyAsDecrypted);
                RegistrySecurity.setSecretKey(null, this, secretKey);
                if (DEBUG) {
                    System.out.println("secretKey received from registry " + secretKey);
                }
                return true;
            }
            System.out.println("cannot register public key " + secretKeyAsEncryptedBase64);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public ClientRegistryAddress registerSocket(String serviceName, String ip, String port, String publicRSAKeyAsBase64) {
        return registerSocket(null, serviceName, null, ip, port, publicRSAKeyAsBase64, null);
    }

    public ClientRegistryAddress registerSocket(String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        return registerSocket(0, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
    }

    public ClientRegistryAddress registerSocket(int count, String domainName, String serviceName, String registrationId, String ip, String port, String publicRSAKeyAsBase64, String securityImpl) {
        try {
            if (serviceName == null || ip == null || port == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.register.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.socket.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("ip");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(ip);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("port");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(port);
            if (publicRSAKeyAsBase64 != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("public_key");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(publicRSAKeyAsBase64);
            }
            if (securityImpl != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("security_impl");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(securityImpl);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                //try again the registry might have been restarted
                System.out.println("registerSocket error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerSocket(1, domainName, serviceName, registrationId, ip, port, publicRSAKeyAsBase64, securityImpl);
            } else {
                System.out.println("registerSocket error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ClientRegistryAddress registerAttributes(String serviceName, Map<String, String> attributes) {
        return registerAttributes(null, serviceName, null, attributes);
    }

    public ClientRegistryAddress registerAttributes(String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        return registerAttributes(0, domainName, serviceName, registrationId, attributes);
    }

    public ClientRegistryAddress registerAttributes(int count, String domainName, String serviceName, String registrationId, Map<String, String> attributes) {
        try {
            if (serviceName == null || attributes == null || attributes.isEmpty()) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.register.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.map.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            try {
                for (Iterator<String> i = attributes.keySet().iterator(); i.hasNext();) {
                    String attributeName = i.next();
                    String attributeValue = i.next();
                    builder.append(ICommand.ATTR_SEPERATOR);
                    builder.append(attributeName);
                    builder.append(ICommand.EQUAL_SEPERATOR);
                    builder.append(attributeValue);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("registerAttributes error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerAttributes(1, domainName, serviceName, registrationId, attributes);
            } else {
                System.out.println("registerAttributes error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ClientRegistryAddress registerJDBC(String serviceName, String driver, String url, String userName, String password) {
        return registerJDBC(null, serviceName, null, driver, url, userName, password);
    }

    public ClientRegistryAddress registerJDBC(String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        return registerJDBC(0, domainName, serviceName, registrationId, driver, url, userName, password);
    }

    public ClientRegistryAddress registerJDBC(int count, String domainName, String serviceName, String registrationId, String driver, String url, String userName, String password) {
        try {
            if (serviceName == null || driver == null || url == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.register.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(TYPE.jdbc.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainname");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("servicename");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(serviceName);
            if (registrationId != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("registrationId");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(registrationId);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("driver");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(driver);
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("url");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(url);
            if (userName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("username");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(userName);
            }
            if (password != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("password");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(password);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return new ClientRegistryAddress(registryIp, registryPort, registrationId, TYPE.socket.toString(), domainName, serviceName);
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("registerJDBC error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return registerJDBC(1, domainName, serviceName, registrationId, driver, url, userName, password);
            } else {
                System.out.println("registerJDBC error " + response);
            }
            return null;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public boolean UnRegister(TYPE type, String serviceName) {
        return UnRegister(type, null, serviceName);
    }

    public boolean UnRegister(TYPE type, String domainName, String serviceName) {
        return UnRegister(0, type, domainName, serviceName);

    }

    public boolean UnRegister(int count, TYPE type, String domainName, String serviceName) {
        try {
            if (type == null) {
                throw new IllegalArgumentException("Invalid paramenters ");
            }
            domainName = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.unregister.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("domainName");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(domainName);
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.toLowerCase().contains(ICommand.STATUS_OK)) {
                return true;
            } else if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("UnRegister error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return UnRegister(1, type, domainName, serviceName);
            }
            if (DEBUG) {
                System.out.println(response);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public List<AbstractRegisration> lookup(TYPE type, String lookupDomainName, String serviceName) {
        return lookup(type, null, lookupDomainName, serviceName);
    }

    public List<AbstractRegisration> lookup(TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        return lookup(0, type, domainNameOfClient, lookupDomainName, serviceName);
    }

    public List<AbstractRegisration> lookup(int count, TYPE type, String domainNameOfClient, String lookupDomainName, String serviceName) {
        List<AbstractRegisration> registrationList = new LinkedList<>();
        try {
            domainNameOfClient = DomainCheck.getDomainNameOnClient(defaultDomainNameOfClient, domainNameOfClient);
            if (lookupDomainName == null) {
                lookupDomainName = domainNameOfClient;
            }
            lookupDomainName = DomainCheck.getLookupDomainName(lookupDomainName);
            StringBuilder builder = new StringBuilder();
            builder.append("cmd");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(CMD.lookup.toString());
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("type");
            builder.append(ICommand.EQUAL_SEPERATOR);
            builder.append(type.toString());
            if (domainNameOfClient != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("domainName");
                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(domainNameOfClient);
            }
            if (lookupDomainName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("lookupDomainName");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(lookupDomainName);
            }
            if (serviceName != null) {
                builder.append(ICommand.ATTR_SEPERATOR);
                builder.append("servicename");

                builder.append(ICommand.EQUAL_SEPERATOR);
                builder.append(serviceName);
            }
            builder.append(ICommand.ATTR_SEPERATOR);
            builder.append("lookupType");
            builder.append(ICommand.EQUAL_SEPERATOR);
            if (lookupDomainName != null && serviceName != null) {
                builder.append("lookupByDomainAndService");
            } else if (lookupDomainName != null) {
                builder.append("lookupByDomain");
            } else if (serviceName != null) {
                builder.append("lookupByService");
            } else {
                builder.append("lookupAll");
            }
            String response = sendCmd(true, out, in, builder.toString());
            if (response != null && response.contains(ICommand.NO_SECURE_KEY_FOUND_ERROR) && count == 0) {
                System.out.println("lookup error from server:" + response + "\nTrying one more time");
                registerpublickey();
                return lookup(1, type, domainNameOfClient, lookupDomainName, serviceName);
            } else if (response != null) {
                StringTokenizer tok = new StringTokenizer(response, ICommand.REG_SEPERATOR);
                //boolean firstRun = true;
                while (tok.hasMoreTokens()) {
                    String registationAsString = tok.nextToken();
                    StringTokenizer tok2 = new StringTokenizer(registationAsString, ICommand.ATTR_SEPERATOR);
                    Map<String, String> registrationAsMap = new HashMap();
                    while (tok2.hasMoreTokens()) {
                        StringTokenizer tok3 = new StringTokenizer(tok2.nextToken(), ICommand.EQUAL_SEPERATOR);
                        String name = null;
                        if (tok3.hasMoreTokens()) {
                            name = tok3.nextToken();
                        }
                        String value = null;
                        if (tok3.hasMoreTokens()) {
                            value = tok3.nextToken();
                        }
                        if (DEBUG) {
                            System.out.println("Adding value to map " + name.toLowerCase() + "," + value);
                        }
                        if (name != null && value != null) {
                            registrationAsMap.put(name.toLowerCase(), value);
                        }
                    }
                    AbstractRegisration registration = null;
                    String typeAsString = registrationAsMap.get("type");
                    if (typeAsString == null) {
                        if (registrationAsMap.get("ip") != null && registrationAsMap.get("port") != null) {
                            typeAsString = TYPE.socket.toString();
                        } else if (registrationAsMap.get("driver") != null && registrationAsMap.get("url") != null) {
                            typeAsString = TYPE.jdbc.toString();
                        } else {
                            typeAsString = TYPE.map.toString();
                        }
                    }
                    if (DEBUG) {
                        System.out.println("type " + typeAsString);
                    }
                    if (typeAsString.equalsIgnoreCase(TYPE.socket.toString())) {
                        registration = new SocketRegistration();
                        ((SocketRegistration) registration).setIp(registrationAsMap.get("ip"));
                        ((SocketRegistration) registration).setPort(registrationAsMap.get("port"));
                    } else if (typeAsString.equalsIgnoreCase(TYPE.jdbc.toString())) {
                        registration = new JDBCRegistration();
                        ((JDBCRegistration) registration).setDriver(registrationAsMap.get("driver"));
                        ((JDBCRegistration) registration).setUrl(registrationAsMap.get("url"));
                        ((JDBCRegistration) registration).setUserName(registrationAsMap.get("username"));
                        ((JDBCRegistration) registration).setPassword(registrationAsMap.get("password"));
                    } else {
                        registration = new MapRegistration();
                    }
                    registration.addAttributes(registrationAsMap);
                    registration.setDomainName(registrationAsMap.get("domainname"));
                    registration.setServicenName(registrationAsMap.get("servicename"));
                    registration.setType(TYPE.valueOf(typeAsString));
                    registration.setClientDomainName(domainNameOfClient);
                    registrationList.add(registration);
                }
            }
        } catch (Exception ex) {
            //ignore
            ex.printStackTrace();
        }
        return registrationList;
    }

    @Override
    public String toString() {
        return "ClientRegistry{" + "registryIp=" + registryIp + ", registryPort=" + registryPort + ", defaultDomainNameOfClient=" + defaultDomainNameOfClient + '}';
    }
}
