/*
 * Martin Alexander Thomsen den 4 Juli 2024
 */
package martin.socketregistry.server;

import java.security.PublicKey;
import java.util.Map;
import javax.crypto.SecretKey;
import martin.socketregistry.security.RegistrySecurity;

/**
 * @author Martin Alexander Thomsen
 */
public class RegisterpublickeyCmd implements ICommand {

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        if (domainName == null) {
            return "error=domain is missing";
        }
        String base64PublicKey = (String) attributes.get("publickey");
        if (base64PublicKey == null) {
            return "error=publickey is missing";
        }
        PublicKey publicKey = RegistrySecurity.fromBase642SPublicKey(null, base64PublicKey);// RSAUtil.fromBase64(base64PublicKey);
        //generate new SecretKey if not exists
        SecretKey secretKey = RegistrySecurity.getSecretKey(null, clientSocketIP);
        //String secretKeyAsBase64 = AESUtil.toBase64(secretKey);
        //encrypt secret key
        //String secretKeyAsEncrypted = RSAUtil.encrypt(publicKey, secretKeyAsBase64);
        String secretKeyAsEncryptedBase64 = RegistrySecurity.toBase64(null, RegistrySecurity.publicKeyEncryptSecretKey(null, publicKey, secretKey));//,// RSAUtil.encrypt(publicKey, secretKey.getEncoded());
        //return "public_key"+ICommand.EQUAL_SEPERATOR+secretKeyAsEncryptedBase64+ICommand.ATTR_SEPERATOR+"registrysecurityimpl"+ICommand.EQUAL_SEPERATOR+impl;
        return secretKeyAsEncryptedBase64;
    }
}
