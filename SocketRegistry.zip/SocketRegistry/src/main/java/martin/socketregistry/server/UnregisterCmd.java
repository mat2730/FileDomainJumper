/*
 * Martin Alexander Thomsen den 1 Juli 2024
 */
package martin.socketregistry.server;

import java.util.Map;
import martin.socketregistry.persistense.PersistenceFactory;

/**
 * @author Martin Alexander Thomsen
 */
public class UnregisterCmd implements ICommand {

    public static final String DOMAIN_KEY = "domain.";
    public static final String SERVICE_KEY = "service.";

    @Override
    public String execute(String clientSocketIP, Map attributes) throws Exception {
        return PersistenceFactory.getRegistryDB().unRegister(clientSocketIP, attributes);
    }
}
