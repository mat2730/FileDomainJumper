/*
 * Martin Alexander Thomsen den 20 Juli 2024
 */
package com.maikenwinterberg.registryofregistry;

import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryOfRegistryAPI {

    public static String getRegistries(String domainName) throws Exception {
        //TODO implement this
        return null;
    }

    public static int register(String registry, List<String> domainNames) throws Exception {
        //TODO implement this
        return 0;
    }

    public static int unRegister(String registry, List<String> domainNames) throws Exception {
        //TODO implement this
        return 0;
    }

}
