/*
 * Martin Alexander Thomsen den 20 Juli 2024
 */
package com.maikenwinterberg.registryofregistry;

import java.net.ServerSocket;
import java.util.Properties;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryOfRegistry extends Thread {

    private static final Properties PROPERTIES = new Properties();
    private static ServerSocket SERVER_SOCKET;

    public static String getProperty(String name) {
        return (String) PROPERTIES.get(name);
    }

    public void start(int port) throws Exception {
        //TODO implement this
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            SERVER_SOCKET.close();
        } finally {
            super.finalize();
        }
    }

    public static void main(String[] args) throws Exception {
        int port = 6668;
        try {
            port = Integer.parseInt(args[0]);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        RegistryOfRegistry server = new RegistryOfRegistry();
        server.start(port);
    }
}
