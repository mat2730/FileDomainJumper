java --class-path target/classes:lib/SocketRegistry-1.0-SNAPSHOT.jar com/maikenwinterberg/filedomainjumper/ClientFileDomainJumper > log/fileSender.log
