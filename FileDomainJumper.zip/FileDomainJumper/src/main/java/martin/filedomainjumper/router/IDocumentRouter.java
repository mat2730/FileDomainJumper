/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package martin.filedomainjumper.router;

import java.io.File;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IDocumentRouter {
    public List<String> getDomainNamesOfRecievers(int index, File file);
}
