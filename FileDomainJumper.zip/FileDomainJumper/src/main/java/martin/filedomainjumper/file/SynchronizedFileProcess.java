/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package martin.filedomainjumper.file;

import java.io.File;
import java.util.List;
import martin.filedomainjumper.FileDomainJumper;
import static martin.filedomainjumper.file.IFileProces.DEST.inBox;

/**
 * @author Martin Alexander Thomsen
 */
public class SynchronizedFileProcess implements IFileProces {

    @Override
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File file, IFileProces.DEST destination) throws Exception {
        path = getPath(path);
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //for all okDomains
                    //register file 
                    return null;
                }
                case inBox -> {
                    //same as DomainAndTimeFileProcess 
                    //TODO share code
                    String domainName = null;
                    try {
                        domainName = okDomains.get(0);
                    } catch (Exception ex) {
                    }
                    if (domainName == null) {
                        domainName = "unknown_sender";
                    }
                    String defaulInboxFolder = FileDomainJumper.getProperty("defaultInboxFolder");
                    String inboxFolder = FileDomainJumper.getProperty(configurationIndex + ".registration.inboxFolder");
                    if (inboxFolder == null || inboxFolder.trim().isEmpty()) {
                        inboxFolder = defaulInboxFolder;
                    }
                    File inboxFolderFile = new File(inboxFolder + "/" + domainName + path);
                    inboxFolderFile.mkdirs();
                    File newFile = new File(inboxFolder + "/" + domainName + path + "/" + file.getName());
                    System.out.println("File received: File will be created in folder " + newFile.getAbsolutePath());
                    return newFile;
                }
                default -> {
                }
            }

        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    //TODO share code with DomainAndTimeFileProess
    private String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        int i = path.indexOf("/");
        if (i != -1) {
            //remove first path
            path = path.substring(i);
        }
        path = path.replaceAll(" ", "_");
        return path;
    }

    @Override
    public boolean doProcessFile(int configurationIndex, String receiverDomainName, File file) throws Exception {
        //TODO implement this
        //check if registrated (key = receiverDomainName,fullFileName, fileSize and fileDate). if exists in DB then return false otherwise return true
        return true;
    }
}
