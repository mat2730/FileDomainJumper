/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package martin.filedomainjumper.file;

import java.io.File;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IFileProces {
    public static enum DEST {
        outBox, inBox, doneWithBox;
    }

    //delete a file or move it into the sentBox, errorBox or inBox
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File fileFromInbox, DEST destination) throws Exception;
    public boolean doProcessFile(int configurationIndex,String receiverDomainName, File file) throws Exception;
}
