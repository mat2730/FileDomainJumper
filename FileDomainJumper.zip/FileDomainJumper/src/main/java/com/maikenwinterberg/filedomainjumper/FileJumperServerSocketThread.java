/*
 * Martin Alexander Thomsen den 7 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.security.PrivateKey;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import com.maikenwinterberg.filedomainjumper.file.IFileProces;
import com.maikenwinterberg.filedomainjumper.file.ProcessFile;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileJumperServerSocketThread extends Thread {

    private static final boolean DEBUG = true;
    private static String EXTERNAL_ID;

    private final Socket clientSocket;
    private final FileDomainJumper fileDomainJumper;
    private final static ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(5);

    FileJumperServerSocketThread(Socket clientSocket, FileDomainJumper fileDomainJumper) {
        String doCheckAsString = FileDomainJumper.getProperty("useExternalID");
        boolean doCheck = true;
        try {
            doCheck = Boolean.parseBoolean(doCheckAsString);
        } catch (Exception ex) {
        }
        System.out.println("useExternalID" + doCheck);
        if (doCheck && EXTERNAL_ID == null) {
            try {
                System.out.println("looking up externalID");
                URL whatismyip = new URL("http://checkip.amazonaws.com");
                BufferedReader in = new BufferedReader(new InputStreamReader(
                        whatismyip.openStream()));
                EXTERNAL_ID = in.readLine(); //you get the IP as a String
                System.out.println("externalID=" + EXTERNAL_ID);

            } catch (Exception ex) {
                //amazonws is down or do not work -no check possible
            }
        }
        this.clientSocket = clientSocket;
        this.fileDomainJumper = fileDomainJumper;
    }

    @Override
    public void run() {
        String ipOfClient = clientSocket.getRemoteSocketAddress().toString();
        StringTokenizer tok = new StringTokenizer(ipOfClient, "/:");
        ipOfClient = tok.nextToken();
        if (ipOfClient != null && ipOfClient.equals("127.0.0.1")) {
            ipOfClient = EXTERNAL_ID;
        }
        //TODO make domainCheck
        DataOutputStream out = null;
        DataInputStream in = null;
        if (DEBUG) {
            System.out.println(this.hashCode() + ": socket accepted of ip " + ipOfClient);
        }
        try {
            out = new DataOutputStream(clientSocket.getOutputStream());
            in = new DataInputStream(clientSocket.getInputStream());
            int numberOfFilesReceived = 0;
            int index = 0;
            while (true) {
                if (clientSocket.isClosed()) {
                    break;
                }
                try {
                    System.out.println(this.hashCode() + ": Protocol begin of client " + ipOfClient);
                    String utf;
                    //read synchronous key 
                    if (index == 0) {
                        //no security
                        utf = in.readUTF();
                        if (utf == null) {
                            break;
                        }
                        System.out.println(this.hashCode() + ": receiving SecretKey " + utf);
                        if (!utf.startsWith(Registry.PROTOCOL)) {
                            throw new SecurityException("Invalid protocol " + utf);
                        } else {
                            utf = utf.substring(Registry.PROTOCOL.length());
                        }
                        if (utf.startsWith("encrypted=false")) {
                            throw new IllegalStateException("This channel must be secure");
                        }
                        System.out.println(this.hashCode() + ": getRSAKeyPar " + fileDomainJumper);
                        PrivateKey privateKey = RegistrySecurity.getKeyPair(FileDomainJumper.getSecurityImpl(), fileDomainJumper).getPrivate();// RSAUtil.getRSAKeyPar(fileDomainJumper).getPrivate();
                        System.out.println(this.hashCode() + ": decrypt " + utf);
                        byte[] AESSecureKey = RegistrySecurity.privateKeyDecrypt(FileDomainJumper.getSecurityImpl(), privateKey, RegistrySecurity.fromBase64(FileDomainJumper.getSecurityImpl(), utf));//((//RSAUtil.decrypt(privateKey, utf);
                        System.out.println(this.hashCode() + ": fromBase64 ");
                        SecretKey secretKey = RegistrySecurity.toSecretKey(FileDomainJumper.getSecurityImpl(), AESSecureKey);// AESUtil.fromBytes(AESSecureKey);
                        System.out.println(this.hashCode() + ": secretKey " + secretKey);
                        RegistrySecurity.setSecretKey(FileDomainJumper.getSecurityImpl(), ipOfClient, secretKey);// AESUtil.setProjectKey(ipOfClient, secretKey);
                        System.out.println(this.hashCode() + ": received secretkey from client");
                    }
                    //read clientDomainName, registationId and filename
                    if (clientSocket.isClosed()) {
                        break;
                    }
                    System.out.println(this.hashCode() + ": reading attribute of file...");
                    String encryptedAttributes = in.readUTF();
                    if (encryptedAttributes == null) {
                        throw new IllegalStateException("cannot read attributes of file");
                    }
                    if (!encryptedAttributes.startsWith(Registry.PROTOCOL)) {
                        throw new SecurityException("Invalid protocol " + encryptedAttributes);
                    } else {
                        encryptedAttributes = encryptedAttributes.substring(Registry.PROTOCOL.length());
                    }
                    System.out.println(this.hashCode() + ": receiving encryptedAttributes of file: " + encryptedAttributes);
                    String attributes = RegistrySecurity.textDecrypt(FileDomainJumper.getSecurityImpl(), ipOfClient, encryptedAttributes); // AESUtil.simpleDecrypt(ipOfClient, encryptedAttributes);
                    System.out.println(this.hashCode() + ": receiving attribute of file: " + attributes);
                    if (attributes == null) {
                        throw new IllegalStateException("cannot read attributes of file");
                    }
                    StringTokenizer tok2 = new StringTokenizer(attributes, ICommand.ATTR_SEPERATOR);
                    String fileName = null;
                    String clientDomainName = null;
                    String registrationId = null;
                    String path = "";
                    int filelength = 0;
                    while (tok2.hasMoreTokens()) {
                        try {
                            StringTokenizer tok3 = new StringTokenizer(tok2.nextToken(), ICommand.EQUAL_SEPERATOR);
                            String attributeName = tok3.nextToken();
                            String attributeValue = tok3.nextToken();
                            if (attributeName.equalsIgnoreCase("registrationId")) {
                                registrationId = attributeValue;
                            } else if (attributeName.equalsIgnoreCase("fileName")) {
                                fileName = URLDecoder.decode(attributeValue, "utf-8");
                            } else if (attributeName.equalsIgnoreCase("clientDomainName")) {
                                clientDomainName = attributeValue;
                            } else if (attributeName.equalsIgnoreCase("filelength")) {
                                filelength = Integer.parseInt(attributeValue);
                            } else if (attributeName.equalsIgnoreCase("path")) {
                                path = attributeValue;
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                    //domain test
                    boolean acceptIpAsDomainName = true;
                    try {
                        if (FileDomainJumper.getProperty("acceptIpAsDomainName").equalsIgnoreCase("false")) {
                            acceptIpAsDomainName = false;
                        }
                    } catch (Exception ex) {
                    }
                    System.out.println(this.hashCode() + ": validating domainname: " + clientDomainName);
                    DomainCheck.validateDomainNameOnServer("conf/validDomains.cfg", "conf/inValidDomains.cfg", !acceptIpAsDomainName, ipOfClient, clientDomainName);
                    System.out.println("domain ok");
                    //max byte test
                    //int numberOfBytes = in.available();
                    String maxNumberOfBytesAsString = FileDomainJumper.getProperty(registrationId + ".registration.maxNumberOfBytes");
                    int encodedDataSize = in.readInt();
                    int sizeFromAvailable = in.available();
                    if (sizeFromAvailable != encodedDataSize) {
                        //throw new SecurityException("Mismatch beetween sent: "+sizeFromAvailable+" and encoded.size on client: " + encodedDataSize);
                    }
                    int maxNumberOfBytes = 0;
                    try {
                        maxNumberOfBytes = Integer.parseInt(maxNumberOfBytesAsString);
                    } catch (Exception ex) {
                        //ignore
                    }
                    if (maxNumberOfBytes > 0) {
                        //no test if zero
                        if (maxNumberOfBytes < encodedDataSize) {
                            throw new SecurityException(ipOfClient + " has reached the max number of bytes of " + maxNumberOfBytes + ", available number of bytes is " + encodedDataSize);
                        }
                    } else {
                        if (DEBUG) {
                            System.out.println("no test of max number of bytes. reading " + encodedDataSize);
                        }
                    }
                    if (DEBUG) {
                        System.out.println("reading file...");
                    }
                    byte[] encodedFileData = null;
                    if (encodedDataSize > 0) {
                        encodedFileData = new byte[encodedDataSize];
                        in.readFully(encodedFileData, 0, encodedDataSize);
                    }
                    if (encodedFileData == null || encodedFileData.length == 0) {
                        throw new IllegalStateException("could not read file " + attributes);
                    }
                    System.out.println("received data: " + encodedFileData.length);
                    //save file
                    byte[] fileData = RegistrySecurity.byteDecrypt(FileDomainJumper.getSecurityImpl(), ipOfClient, encodedFileData);// AESUtil.simpleDecrypt(ipOfClient, encodedFileData);
                    System.out.println("file data decrypted " + fileData.length);
                    if (filelength != fileData.length) {
                        throw new SecurityException("file size: " + fileData.length + " differes from orginal size: " + filelength);
                    }
                    List<String> okList = new LinkedList();
                    okList.add(clientDomainName);
                    File newFile = ProcessFile.processFile(Integer.parseInt(registrationId), okList, null, path, new File(fileName), IFileProces.DEST.inBox);
                    BufferedOutputStream buf = new BufferedOutputStream(new FileOutputStream(newFile));
                    buf.write(fileData);
                    buf.flush();
                    if (newFile.getName().endsWith(".zip")) {
                        executor.submit(() -> {
                            new ZipExtractorThread(newFile.getParentFile(), newFile).run();
                        });
                    }
                    //write result
                    String cmd = "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "numberOfFilesReceived" + ICommand.EQUAL_SEPERATOR + numberOfFilesReceived;
                    System.out.println(this.hashCode() + ": writing command " + cmd + " of client: " + ipOfClient);
                    out.writeUTF(RegistrySecurity.textEncrypt(FileDomainJumper.getSecurityImpl(), ipOfClient, cmd));//AESUtil.simpleEncrypt(ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "numberOfFilesReceived" + ICommand.EQUAL_SEPERATOR + numberOfFilesReceived));
                    System.out.println(this.hashCode() + ": End of protocol of ip " + ipOfClient);
                } catch (Throwable ex) {
                    if (clientSocket.isClosed()) {
                        break;
                    }
                    ex.printStackTrace();
                    try {
                        //write error
                        StringWriter sw = new StringWriter();
                        PrintWriter pw = new PrintWriter(sw);
                        ex.printStackTrace(pw);
                        String sStackTrace = sw.toString();
                        String cmd = "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace;
                        out.writeUTF(RegistrySecurity.textEncrypt(FileDomainJumper.getSecurityImpl(), ipOfClient, cmd));// AESUtil.simpleEncrypt(ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace));
                    } catch (Exception exe) {
                        exe.printStackTrace();
                    } finally {
                        break;
                    }
                } finally {
                    //RegistrySecurity.removeSecretKey(FileDomainJumper.getSecurityImpl(), ipOfClient);
                }
                index++;
            }
        } catch (Exception exe) {
            if (DEBUG) {
                exe.printStackTrace();
            }
        }

        try {
            if (in != null) {
                in.close();
            }
            out.close();
            clientSocket.close();
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (DEBUG) {
            System.out.println(this.hashCode() + ": done with client request");
        }
    }
}
