/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DocumentRouterFactory {

    private final static Map<String, IDocumentRouter> ROUTERS = new HashMap();

    public static IDocumentRouter getRouter(int configIndex, File file) {
        String className = ClientFileDomainJumper.getProperty(configIndex + ".routingclass");
        System.out.println("looking for router in indedx " + configIndex + " found class "+className);
        if (className != null && !className.trim().isEmpty()) {
            try {
                //look in folder config
                IDocumentRouter documentRouter = ROUTERS.get(className);
                if (documentRouter == null) {
                    documentRouter = (IDocumentRouter) Class.forName(className).newInstance();
                    ROUTERS.put(className, documentRouter);
                    System.out.println("using router " + documentRouter + " for file " + file.getAbsolutePath() + ", config index is " + configIndex);
                    return documentRouter;
                } else {
                    return documentRouter;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        try {
            //look in default config
            className = ClientFileDomainJumper.getProperty("defaultRoutingClass");
            System.out.println("looking for router in defaultRoutingClass found class "+className);
        if (className != null || !className.trim().isEmpty()) {
                IDocumentRouter documentRouter = ROUTERS.get(className);
                if (documentRouter == null) {
                    documentRouter = (IDocumentRouter) Class.forName(className).newInstance();
                    ROUTERS.put(className, documentRouter);
                    System.out.println("using default router " + documentRouter + " for file " + file.getAbsolutePath() + ", config index is " + configIndex);
                    return documentRouter;
                } else {
                    return documentRouter;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.out.println("No router found for file " + file.getAbsolutePath() + ", config index is " + configIndex);
        return null;
    }
}
