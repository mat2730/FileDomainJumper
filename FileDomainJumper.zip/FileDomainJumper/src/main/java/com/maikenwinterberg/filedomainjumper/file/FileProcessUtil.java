/*
 * Martin Alexander Thomsen den 22 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileProcessUtil {

    public static String removeFirstPartIfEqual(String firstPart, String fileName) {
        int index = fileName.toLowerCase().indexOf(firstPart.toLowerCase());
        if (index != -1) {
            return "/" + fileName.substring(index + firstPart.length());
        }

        return fileName;
    }

    public static void deleteEmptyDir(File directory) {
        for (File childFile : directory.listFiles()) {
            if (childFile.isDirectory()) {
                deleteEmptyDir(childFile);
            }
        }
        if (directory.isDirectory() && directory.list().length == 0) {
            directory.delete();
            System.out.println("deleting folder " + directory.getAbsolutePath() + ", status " + directory.delete());
        }
    }

    public static String addIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + numberOfTries++ + "." + extension;
    }

    public static String removeIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + extension;
    }

    public static boolean copyFile(File fromFile, File toFile) {
        try {
            InputStream in = new BufferedInputStream(
                    new FileInputStream(fromFile));
            OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(toFile));

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        int i = path.indexOf("/");
        if (i != -1) {
            //remove first path
            path = path.substring(i);
        }
        path = path.replaceAll(" ", "_");
        return path;
    }

}
