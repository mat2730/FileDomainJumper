/*
 * Martin Alexander Thomsen den 13 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.File;
import java.util.List;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JumperTask {

    private final int outboxIndex;
    private final String path;
    private final File file;
    //private final File outboxFile;
    private final String domainNameOfClient; //used for verification 
    private final List<ClientRegistry> lookupRegistries;
    private final String serviceName;

    public JumperTask(int outboxIndex, String path, File file, String domainNameOfClient, List<ClientRegistry> lookupRegistries, String serviceName) {
        this.path = path;
        this.file = file;
        this.domainNameOfClient = domainNameOfClient;
        //this.outboxFile = outboxFile;
        this.lookupRegistries = lookupRegistries;
        this.serviceName = serviceName;
        this.outboxIndex = outboxIndex;
    }

    public String getDomainNameOfClient() {
        return this.domainNameOfClient;
    }

    public int getOutboxIndex() {
        return this.outboxIndex;
    }

    public String getPath() {
        if (path == null || path.trim().isEmpty()) {
            return ".";
        }
        return path;
    }

    public File getFile() {
        return file;
    }

    public List<ClientRegistry> getLookupRegistries() {
        return lookupRegistries;
    }

    public String getServiceName() {
        return serviceName;
    }

}
