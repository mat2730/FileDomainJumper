java --class-path ./target/classes:./lib/SocketRegistry-1.0-SNAPSHOT.jar martin/filedomainjumper/FileDomainJumper > log/fileReceiver.log
