/*
 * Martin Alexander Thomsen den 16 Juli 2024
 */
package com.maikenwinterberg.zipauto;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ZipAutoExtractorThread extends Thread {

    private final File file;
    private final File inboxDir;

    public ZipAutoExtractorThread(File inboxDir, File file) {
        this.file = file;
        this.inboxDir = inboxDir;
        System.out.println("extraction to " + inboxDir.getAbsolutePath());
    }

    @Override
    public void run() {
        try {
            System.out.println("unzipping " + file.getName() + "...");
            boolean ok = false;
            if (file.getName().endsWith(".zip")) {
                try (ZipFile zipFile = new ZipFile(file)) {
                    Enumeration<? extends ZipEntry> zipEntries = zipFile.entries();
                    while (zipEntries.hasMoreElements()) {
                        ZipEntry zipEntry = zipEntries.nextElement();
                        System.out.println("Name of zip entry" + zipEntry.getName());
                        File toFile = new File(inboxDir.getAbsolutePath() + "/" + zipEntry.getName());
                        toFile.getParentFile().mkdirs();
                        System.out.println("zip entry found " + toFile.getAbsolutePath());
                        OutputStream out = new BufferedOutputStream(
                                new FileOutputStream(toFile));
                        try (InputStream in = new BufferedInputStream(zipFile.getInputStream(zipEntry))) {
                            // Read data from InputStream
                            byte[] buffer = new byte[1024];
                            int lengthRead;
                            while ((lengthRead = in.read(buffer)) > 0) {
                                out.write(buffer, 0, lengthRead);
                                out.flush();
                            }
                            if (toFile.exists()) {
                                ok = true;
                            }
                        }
                        out.close();
                    }
                }
            }
            if (ok) {
                file.delete();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
