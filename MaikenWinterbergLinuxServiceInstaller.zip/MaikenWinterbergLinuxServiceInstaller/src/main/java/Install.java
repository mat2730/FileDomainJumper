
import com.maikenwinterberg.linuxserviceinstaller.LinuxServiceInstaller;



/*
 * Martin Alexander Thomsen den 14 Juli 2024
 */
/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Install {

    public static void main(String arg[]) throws Exception {
        LinuxServiceInstaller.main(arg);
    }
}
