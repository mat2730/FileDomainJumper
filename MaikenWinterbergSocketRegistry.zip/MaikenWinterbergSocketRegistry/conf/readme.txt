The iv.obj 
    is used for encryption over the socket connection. The client and the server must have the same set of files (with the same content) 
    for the connection to work. if removed a new file is being created. make sure to copy the new file to all the clients if deleted.

The startup.cfg 
    can be filled with cmmands that will loaded when the server starts up.

validdomains.cfg 
    contains all domains that can connect to the registry. If empty all domains have access.

registry.properties contains how the system works
    domaincheck:
        if domaincheck=true then domain check is on 
        if domaincheck=false then domain check is off
