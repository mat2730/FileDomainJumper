echo installing service...
sudo systemctl stop MaikenWinterbergRegistry.service
sudo cp MaikenWinterbergRegistry.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start MaikenWinterbergRegistry.service
sudo systemctl enable MaikenWinterbergRegistry.service
echo done installing service
#sleep 10s