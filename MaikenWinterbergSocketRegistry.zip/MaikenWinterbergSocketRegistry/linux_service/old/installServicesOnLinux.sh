#before running this file you need to edit the registry.service file
sudo systemctl stop fileReceiver.service
sudo systemctl stop fileSender.service
sudo cp fileReceiver.service /etc/systemd/system
sudo cp fileSender.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start fileReceiver.service
sudo systemctl start fileSender.service
#sudo systemctl status fileReceiver.service
#sudo systemctl status fileSender.service
sudo systemctl enable fileReceiver.service
sudo systemctl enable fileSender.service
echo done
sleep 5d
