echo installing registry service
java --class-path ./classes Install MaikenWinterbergRegistry ../bin startRegistry.sh conf
echo done installing registry service
#ls -a
#sleep 10s
