echo unInstalling service...
sudo systemctl stop MaikenWinterbergRegistry.service
sudo rm /etc/systemd/system/MaikenWinterbergRegistry.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s