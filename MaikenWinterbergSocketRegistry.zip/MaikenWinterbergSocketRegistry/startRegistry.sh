java --class-path target/classes:./lib/h2-2.2.224.jar com/maikenwinterberg/socketregistry/server/Registry 6666 > log/MaikenWinterbergRegistryLog.txt
# > /dev/null
