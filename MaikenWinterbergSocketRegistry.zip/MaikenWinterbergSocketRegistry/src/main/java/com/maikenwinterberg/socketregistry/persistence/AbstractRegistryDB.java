/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package com.maikenwinterberg.socketregistry.persistence;

import java.util.Iterator;
import java.util.Map;
import com.maikenwinterberg.socketregistry.server.ICommand;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public abstract class AbstractRegistryDB implements IRegistryDB {

    private static final boolean DEBUG = false;

    protected String getCommandAsString(Map attributes) {
        if (attributes == null) {
            if (DEBUG) {
                System.out.println("no command found");
            }
            return "error=no command found";
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (Iterator i = attributes.keySet().iterator(); i.hasNext();) {
            String ckey = (String) i.next();
            String cvalue = (String) attributes.get(ckey);
            stringBuilder.append(ckey).append(ICommand.EQUAL_SEPERATOR).append(cvalue);
            if (DEBUG) {
                System.out.println("building response. key" + ICommand.EQUAL_SEPERATOR + ckey + " value" + ICommand.EQUAL_SEPERATOR + cvalue);
            }
            if (i.hasNext()) {
                stringBuilder.append(ICommand.ATTR_SEPERATOR);
            }
        }
        if (DEBUG) {
            System.out.println("returning: " + stringBuilder.toString());
        }
        return stringBuilder.toString();
    }
}
