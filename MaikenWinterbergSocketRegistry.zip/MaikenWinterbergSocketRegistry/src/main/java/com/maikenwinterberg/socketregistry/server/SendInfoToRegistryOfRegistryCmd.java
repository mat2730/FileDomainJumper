/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SendInfoToRegistryOfRegistryCmd {
    //TODO validate agains administrativ domainname (that is configured)
    //call up registryOfRegistry service(S) and send info about which domainnames are in the registry
}
