/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package com.maikenwinterberg.socketregistry.persistence;

import com.maikenwinterberg.socketregistry.persistence.hashmap.RegistryHashMapDB;
import com.maikenwinterberg.socketregistry.server.Registry;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PersistenceFactory {

    public static IRegistryDB getRegistryDB() throws Exception {
        try {
            String className = Registry.getProperty("registry_db_class");
            if (className != null) {
                IRegistryDB registryDB = (IRegistryDB) Class.forName(className).newInstance();
                return registryDB;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("Running in memory mode");
        }
        return new RegistryHashMapDB();
    }
}
