/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryCommands {

    private final static boolean DEBUG = false;

    private final Map<String, String> attributes = new HashMap();

    public void addAttribute(String attributeName, String value) {
        attributes.put(attributeName, value);
    }

    public String execute(String IpOfClient) throws Exception {
        String cmd = (String) attributes.get("cmd");
        attributes.remove("cmd");
        if (cmd != null) {
            //a fully qualified classname as a command makes it easy to extends the commands that the registry can execute
            String className = cmd.replaceAll("_", ".");
            Object obj = Class.forName(className).newInstance();
            if (DEBUG) {
                System.out.println("commandObject: " + obj + ", is command: " + (obj instanceof ICommand));
            }
            if (obj != null && obj instanceof ICommand) {
                return ((ICommand) obj).execute(IpOfClient, attributes);
            }
        } else {
            throw new IllegalArgumentException("No command found");
        }
        throw new IllegalArgumentException("Invalid command: " + cmd);
    }
}
