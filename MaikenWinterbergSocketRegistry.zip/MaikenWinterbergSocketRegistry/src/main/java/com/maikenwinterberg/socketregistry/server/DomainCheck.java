/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DomainCheck {

    private static String EXTERNAL_ID = null;
    private static final Map<String, Properties> PROPERTIES = new HashMap();

    public static void updateExternalID() {
        try {
            //TODO add multiple implementations
            System.out.println("looking up externalID");
            URL whatismyip = new URL("http://checkip.amazonaws.com");
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    whatismyip.openStream()));
            EXTERNAL_ID = in.readLine(); //you get the IP as a String
            System.out.println("externalID=" + EXTERNAL_ID);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static String getExternalId() {
        return EXTERNAL_ID;
    }

    private static Properties getProperties(String fileName) {
        Properties p = PROPERTIES.get(fileName);
        if (p == null) {
            p = new Properties();
        }
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#") || line.trim().isEmpty()) {
                    continue;
                }
                p.put(line.toLowerCase(), "");
            }
        } catch (Exception ex) {
            System.out.println("cannot find property file " + fileName);
        }
        return p;
    }

    public static String updateDefaultDomainNameOnClient(String clientDomainName) throws Exception {
        updateExternalID();
        return getDefaultDomainNameOnClient2(clientDomainName);
    }

    public static String getDefaultDomainNameOnClient2(String clientDomainName) throws Exception {
        InetAddress inetAddress = null;
        try {
            inetAddress = InetAddress.getByName(clientDomainName);
        } catch (Exception ex) {
            //invalid dominName use externalID instead
            return EXTERNAL_ID;
        }
        String hostAddress = inetAddress.getHostAddress();
        if (!EXTERNAL_ID.equalsIgnoreCase(hostAddress)) {
            //invalid domainName use externalId instead
            return EXTERNAL_ID;
        }
        return clientDomainName;
    }

    public static String getDomainNameOnClient(String defaultDomainNameOfClient, String domainName) {
        if (domainName == null || domainName.trim().isEmpty()) {
            return defaultDomainNameOfClient;
        }
        if (domainName.equalsIgnoreCase("localhost") || domainName.equals("127.0.0.1")) {
            return defaultDomainNameOfClient;
        }
        return domainName;
    }

    public static String getLookupDomainName(String lookupDomainName) {
        if (lookupDomainName == null || lookupDomainName.equalsIgnoreCase("localhost") || lookupDomainName.equals("127.0.0.1")) {
            lookupDomainName = EXTERNAL_ID;
        }
        return lookupDomainName;
    }

    public static boolean isAnIPv4(String domainName) {
        if (domainName == null) {
            return false;
        }
        int index1 = 0;
        int index2 = domainName.indexOf(".");
        int count = 0;
        while (true) {
            if (index1 == -1 || index2 == -1) {
                return false;
            }
            try {
                String nr = domainName.substring(index1, index2);
                System.out.println(nr);
                Integer.valueOf(nr);
                count++;
                if (count == 3) {
                    break;
                }
                index1 = index2 + 1;
                index2 = domainName.indexOf(".", index1);
            } catch (NumberFormatException ex) {
                return false;
            }
        }
        try {
            String nr = domainName.substring(index2 + 1);
            if (nr.contains(".")) {
                return false;
            }
            System.out.println(nr);
            Integer.valueOf(nr);
            return true;
        } catch (NumberFormatException ex) {
        }
        return false;
    }

    public static void validateDomainNameOnServer(String validPropFileName, String inValidPropFileName, boolean doNotAcceptIpAsDomainName, String socketClientIP, String domainName) throws Exception {
        if (socketClientIP == null) {
            //this is a command from statup;
            return;
        }
        if (domainName == null) {
            throw new SecurityException("No client domsocketClientIPainname found");
        }
        if (!domainName.endsWith("localhost")) {
            System.out.println("verifying domain " + domainName);
        }
        if (domainName.equalsIgnoreCase("maikenwinterberg.com") || domainName.equalsIgnoreCase("documentnetwork.com")) {
            //preapproved. needed for the default behavior for the PROTOCOL to work (see license conditions)
            return;
        }
        //validate client domain name agains properties
        Properties validDomains = getProperties(validPropFileName);
        Properties notValidDomains = getProperties(inValidPropFileName);
        if (!validDomains.isEmpty() && validDomains.get(domainName) == null) {
            throw new SecurityException("the domain " + domainName + " is not present in property file: " + validPropFileName);
        }
        if (notValidDomains.get(domainName) != null) {
            throw new SecurityException("the domain " + domainName + " is present in property file: " + inValidPropFileName);
        }
        //test if domain name match socketClientIp
        InetAddress inetAddress = InetAddress.getByName(domainName);
        String hostAddress = inetAddress.getHostAddress();

        if (hostAddress.equals(domainName) && doNotAcceptIpAsDomainName) {
            throw new SecurityException("the domainname " + domainName + " is an IP address. Only valid domainnames are accepted.");
        }
        if (!validDomains.isEmpty() && validDomains.get(hostAddress) == null) {
            throw new SecurityException("the domain ip " + hostAddress + " of domain " + domainName + "is not present in property file: " + validPropFileName);
        }
        if (notValidDomains.get(hostAddress) != null) {
            throw new SecurityException("the domain ip " + hostAddress + " of domain " + domainName + " is present in property file: " + inValidPropFileName);
        }

        if (!socketClientIP.equalsIgnoreCase(hostAddress)) {
            throw new IllegalStateException("Invalid domainname " + domainName + ". You must come from ip: " + hostAddress + ", your ip is " + socketClientIP);
        }
    }

    public static void main(String arg[]) {
        System.out.println("is an IP " + isAnIPv4("1.22.1.5"));
        System.out.println("is an IP " + isAnIPv4("1.22.1.2.6"));
        System.out.println("is an IP " + isAnIPv4("1.22.f.7"));
        System.out.println("is an IP " + isAnIPv4("test"));
    }
}
