/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.util.Map;
import com.maikenwinterberg.socketregistry.persistense.PersistenceFactory;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LookupCmd implements ICommand {

    private static final boolean DEBUG = false;

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String returnString = null;
        try {
            returnString = PersistenceFactory.getRegistryDB().lookup(clientSocketIP, attributes);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        /* force to use domainname 
        if (returnString == null || returnString.isEmpty()) {
            String lookupDomainName = (String) attributes.get("lookupdomainname");
            if (lookupDomainName != null) {
                InetAddress inetAddress = null;
                try {
                    //from domainname to ipaddress
                    inetAddress = InetAddress.getByName(lookupDomainName);
                    if (!inetAddress.toString().equals(lookupDomainName)) {
                        //try with ipaddress
                        attributes.put("lookupdomainname", inetAddress.toString());
                        returnString = PersistenceFactory.getRegistryDB().lookup(clientSocketIP, attributes);
                    }
                } catch (Exception ex) {
                    //invalid dominName use externalID instead
                    ex.printStackTrace();
                }
            }
        }*/
        return returnString;
    }
}
