/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.server.daddy.WhoIsMyDaddy;
import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.persistence.AbstractRegistryDB;
import java.util.Map;
import com.maikenwinterberg.socketregistry.persistence.PersistenceFactory;
import java.net.InetAddress;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt You can freely make your own commands
 */
public class LookupCmd implements ICommand {

    private static final boolean DEBUG = false;

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        String lookupDomainName = (String) attributes.get("lookupdomainname");

        if (serviceName != null && serviceName.equalsIgnoreCase("whoIsMyDaddy")) {
            return WhoIsMyDaddy.getDaddies(clientSocketIP, attributes);
        }

        if (lookupDomainName == null) {
            //check that you come from localhost or that you are special.
            boolean approved = false;
            try {
                String domainName = (String) attributes.get(ICommand.DOMAIN_NAME_PARAM);
                if (domainName != null) {
                    //see license.txt 
                    if (domainName.equalsIgnoreCase("documentnetwork.com") || domainName.equalsIgnoreCase("maikenwinterberg.com")) {
                        approved = true;
                    } else {
                        if (DomainCheck.getExternalId() == null) {
                            DomainCheck.updateExternalID();
                        }
                        InetAddress inetAddress = InetAddress.getByName(domainName);
                        if (inetAddress.toString().equals(DomainCheck.getExternalId())) {
                            approved = true;
                        }
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (!approved) {
                throw new SecurityException("I you want to query all domains you must come from ip: " + DomainCheck.getExternalId());
            }
        }
        //DB call
        String returnString = null;
        try {
            returnString = PersistenceFactory.getRegistryDB().lookup(clientSocketIP, attributes);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //call parent
        if (returnString == null || returnString.isEmpty()) {
            //call parents registries
            //TODO avoid loop - implement domainTrace
            String parentRegistries = Registry.getParentRegistries();
            if (parentRegistries != null) {
                StringTokenizer tok = new StringTokenizer(parentRegistries, ";");
                while (tok.hasMoreTokens()) {
                    try {
                        String registry = tok.nextToken();
                        StringTokenizer tok2 = new StringTokenizer(registry, ":");
                        String ip = tok2.nextToken();
                        int port;
                        try {
                            port = Integer.parseInt(tok2.nextToken());
                        } catch (Exception ex) {
                            port = 6668;
                        }
                        //TODO check that parent registry has not been called allready
                        String domainNameOfRegistry = Registry.getProperty("domainNameOfRegistry");
                        ClientRegistry parentRegistry = ClientRegistry.getRegistryInstance(domainNameOfRegistry, ip, port, false, false);
                        //TODO add domainTrace in attributes
                        List<AbstractRegisration> regList = parentRegistry.lookup(ClientRegistry.TYPE.valueOf(cmdType), domainNameOfRegistry, lookupDomainName, serviceName, attributes);
                        StringBuilder builder = new StringBuilder();
                        for (Iterator<AbstractRegisration> i = regList.iterator(); i.hasNext();) {
                            AbstractRegisration reg = i.next();
                            builder.append(AbstractRegistryDB.getCommandAsString(reg.getAttributes()));
                            if (i.hasNext()) {
                                builder.append(ICommand.REG_SEPERATOR);
                            }
                        }
                        if (!builder.toString().isEmpty()) {
                            return builder.toString();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        }
        /* force to use domainname 
        if (returnString == null || returnString.isEmpty()) {
            String lookupDomainName = (String) attributes.get("lookupdomainname");
            if (lookupDomainName != null) {
                InetAddress inetAddress = null;
                try {
                    //from domainname to ipaddress
                    inetAddress = InetAddress.getByName(lookupDomainName);
                    if (!inetAddress.toString().equals(lookupDomainName)) {
                        //try with ipaddress
                        attributes.put("lookupdomainname", inetAddress.toString());
                        returnString = PersistenceFactory.getRegistryDB().lookup(clientSocketIP, attributes);
                    }
                } catch (Exception ex) {
                    //invalid dominName use externalID instead
                    ex.printStackTrace();
                }
            }
        }*/
        return returnString;
    }
}
