/*
 * Martin Alexander Thomsen den 2 Juli 2024
 */
package com.maikenwinterberg.socketregistry.security;

import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Map;
import javax.crypto.SecretKey;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IRegistrySecurity {
    public void registerPublicKey(String clientSocketIp, Map<String, String> attributes) throws Exception;

    public void setSecretKey(Object key2SecretKey, SecretKey secretKey) throws Exception;

    public SecretKey getSecretKey(Object key2SecretKey) throws Exception;

    public String textEncrypt(Object key2SecretKey, String text) throws Exception;

    public String textDecrypt(Object key2SecretKey, String text) throws Exception;

    public byte[] byteEncrypt(Object key2SecretKey, byte[] bytes) throws Exception;

    public byte[] byteDecrypt(Object key2SecretKey, byte[] bytes) throws Exception;

    public SecretKey toSecretKey(byte[] seretKeyAsBytes) throws Exception;

    public KeyPair getKeyPair(Object key) throws Exception;
    
    public byte[] privateKeyDecrypt(PrivateKey privateKey, byte[] data) throws Exception;

    public byte[] publicKeyEncrypt(PublicKey publicKey, byte[] data) throws Exception;

    public byte[] publicKeyEncryptSecretKey(PublicKey publicKey, SecretKey secretKey) throws Exception;

    public String toBase64(PublicKey key) throws Exception;

    public String toBase64(byte[] bytes) throws Exception;

    public byte[] fromBase64(String base64) throws Exception;

    public PublicKey fromBase642SPublicKey(String base64PublicKey) throws Exception;
}
