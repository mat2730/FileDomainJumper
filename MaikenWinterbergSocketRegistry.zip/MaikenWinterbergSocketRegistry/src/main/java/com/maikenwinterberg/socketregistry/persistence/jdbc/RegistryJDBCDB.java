/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package com.maikenwinterberg.socketregistry.persistence.jdbc;

import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Map;
import com.maikenwinterberg.socketregistry.persistence.AbstractRegistryDB;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.util.HashMap;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * @SEE doc/fetchMedHarris.pdf
 */
public class RegistryJDBCDB extends AbstractRegistryDB {
    public static final int MAXFETCHSIZE = 100;
    private static final Map CACHE = new HashMap();
    private static final Map PUBLIC_KEY = new HashMap();
    private static final boolean INFO = true;

    private static Connection connection;

    public RegistryJDBCDB() throws Exception {
        this(Registry.getProperty("driver"), Registry.getProperty("url"), Registry.getProperty("username"), Registry.getProperty("password"));
    }

    public RegistryJDBCDB(String driver, String url, String username, String password) throws Exception {
        if (connection == null || connection.isClosed()) {
            if (driver == null || driver.isEmpty()) {
                driver = "org.h2.Driver";
            }
            if (url == null || url.isEmpty()) {
                //url = "jdbc:h2:file:~/registrydb";
                url = "jdbc:h2:file:./registrydb";
            }
            if (username == null || username.isEmpty()) {
                username = "sa";
            }
            if (password == null) {
                password = "";
            }
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
            PreparedStatement st = connection.prepareStatement("create table IF NOT EXISTS registry(type varchar(10), domainname varchar(255), servicename varchar(255), attributes varchar(4048), public_key varchar(4048), createdat datetime default CURRENT_TIMESTAMP, updatedat datetime default CURRENT_TIMESTAMP, PRIMARY KEY(type,domainname,servicename));");
            st.executeUpdate();
        }
    }

    @Override
    public String register(String socketClientIP, Map<String, String> attributes) throws Exception {
        long timestamp = System.currentTimeMillis();
        attributes.put("registration_timestamp", "" + timestamp);
        attributes.put("socket_client_ip", socketClientIP);
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("select * from registry where type=? and domainname=? and servicename=?");
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, cmdType);
        st.setString(2, domainName);
        st.setString(3, serviceName);
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        ResultSet r = st.executeQuery();
        if (r.next()) {
            //update
            sqlBuf = new StringBuilder();
            sqlBuf.append("update registry set updatedat=CURRENT_TIMESTAMP, attributes=?");
            String base64PublicKey = (String) attributes.get("publickey");
            if (base64PublicKey != null) {
                attributes.remove("publickey");
                sqlBuf.append(" and public_key=?");
            }
            sqlBuf.append(" where type=? and domainname=? and servicename=?");

            if (INFO) {
                System.out.println(sqlBuf.toString());
            }
            st = connection.prepareStatement(sqlBuf.toString());
            int index = 1;
            st.setString(index++, getCommandAsString(attributes));
            if (base64PublicKey != null) {
                st.setString(index++, base64PublicKey);
            }
            st.setString(index++, cmdType);
            st.setString(index++, domainName);
            st.setString(index++, serviceName);
            st.executeUpdate();
            String cmd = getCommandAsString(attributes);
            System.out.println("updating cache " + cmdType + "." + domainName + "." + serviceName + "=" + cmd);
            CACHE.put(cmdType + "." + domainName + "." + serviceName, cmd);
            PUBLIC_KEY.put(cmdType + "." + domainName + "." + serviceName, base64PublicKey);
        } else {
            //insert
            String base64PublicKey = (String) attributes.get("publickey");
            sqlBuf = new StringBuilder();
            sqlBuf.append("insert into registry(type,domainname,servicename,attributes,public_key) values(?,?,?,?,?)");
            if (base64PublicKey != null) {
                attributes.remove("publickey");
            }

            if (INFO) {
                System.out.println(sqlBuf.toString());
            }
            st = connection.prepareStatement(sqlBuf.toString());
            int index = 1;
            String cmd = getCommandAsString(attributes);
            st.setString(index++, cmdType);
            st.setString(index++, domainName);
            st.setString(index++, serviceName);
            st.setString(index++, cmd);
            st.setString(index++, base64PublicKey);
            st.executeUpdate();
            System.out.println("adding to cache " + cmdType + "." + domainName + "." + serviceName + "=" + cmd);
            CACHE.put(cmdType + "." + domainName + "." + serviceName, cmd);
            PUBLIC_KEY.put(cmdType + "." + domainName + "." + serviceName, base64PublicKey);
        }
        return ICommand.STATUS_OK + ICommand.ATTR_SEPERATOR + "timestamp" + ICommand.EQUAL_SEPERATOR + timestamp;
    }

    @Override
    public String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        if (cmdType == null || domainName == null) {
            return "error=missing parameters. cmd" + ICommand.EQUAL_SEPERATOR + cmdType + ",domainname" + ICommand.EQUAL_SEPERATOR + domainName;
        }
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("delete from registry where type=? and domainname=?");
        if (serviceName != null) {
            sqlBuf.append(" and servicename=?");
        }

        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        int index = 1;
        st.setString(index++, cmdType);
        st.setString(index++, domainName);
        if (serviceName != null) {
            st.setString(index++, serviceName);
        }
        st.executeUpdate();
        System.out.println("removing from cache " + cmdType + "." + domainName + "." + serviceName);
        CACHE.remove(cmdType + "." + domainName + "." + serviceName);
        PUBLIC_KEY.remove(cmdType + "." + domainName + "." + serviceName);
        return ICommand.STATUS_OK;
    }

    @Override
    public String lookup(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        String lookupDomainName = (String) attributes.get("lookupdomainname");
        if (serviceName != null && lookupDomainName != null) {
            String cmd = (String) CACHE.get(cmdType + "." + lookupDomainName + "." + serviceName);
            System.out.println("looking in cache " + cmdType + "." + lookupDomainName + "." + serviceName);
            if (cmd != null) {
                String key = (String) PUBLIC_KEY.get(cmdType + "." + lookupDomainName + "." + serviceName);
                StringBuilder buf = new StringBuilder();
                appendCmd(buf, cmd, key);
                System.out.print("found in cache " + buf.toString());
                return buf.toString();
            }
        }
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("select * from registry where type=?");
        if (lookupDomainName != null) {
            sqlBuf.append(" and domainname=?");
        }
        if (serviceName != null) {
            sqlBuf.append(" and servicename=?");
        }
        String offset = attributes.get("offset");
        int offsetAsInt = 0;
        try {
            offsetAsInt = Integer.parseInt(offset);
        } catch (Exception ex) {
            offsetAsInt = 0;
        }
        if (offsetAsInt != 0) {
            sqlBuf.append(" OFFSET ");
            sqlBuf.append(offsetAsInt);
            sqlBuf.append(" ROWS");
        }
        if (INFO) {
            System.out.println("lookup: " + sqlBuf.toString());
        }
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        int index = 1;
        st.setString(index++, cmdType);
        if (lookupDomainName != null) {
            st.setString(index++, lookupDomainName);
        }
        if (serviceName != null) {
            st.setString(index++, serviceName);
        }
        ResultSet r = st.executeQuery();
        sqlBuf = new StringBuilder();

        String fetchsize = attributes.get("fetchsize");
        int fetchsizeInt = 0;
        try {
            fetchsizeInt = Integer.parseInt(fetchsize);
        } catch (Exception ex) {
            fetchsizeInt = 10;
        }
        if (fetchsizeInt > MAXFETCHSIZE) {
            fetchsizeInt = MAXFETCHSIZE;
        }
        int i = 0;
        while (r.next()) {
            if (i >= fetchsizeInt) {
                break;
            }
            //String rtype = r.getString("type");
            //String rdomainName = r.getString("domainname");
            //String rserviceName = r.getString("servicename");
            String rattributes = r.getString("attributes");
            String rpublicKey = r.getString("public_key");
            appendCmd(sqlBuf, rattributes, rpublicKey);
            i++;
        }
        return sqlBuf.toString();
    }

    private void appendCmd(StringBuilder sqlBuf, String rattributes, String rpublicKey) {
        if (rattributes != null) {
            if (!sqlBuf.isEmpty()) {
                sqlBuf.append(ICommand.REG_SEPERATOR);
            }
            sqlBuf.append(rattributes);
            if (rpublicKey != null) {
                sqlBuf.append(ICommand.ATTR_SEPERATOR);
                sqlBuf.append("public_key" + ICommand.EQUAL_SEPERATOR);
                sqlBuf.append(rpublicKey);
            }
        }
    }

    //test
    public static void main(String arg[]) throws Exception {
        Class.forName("org.h2.Driver");
        Connection conn = DriverManager.getConnection("jdbc:h2:file:~/registrydb", "sa", "");
        PreparedStatement st = conn.prepareStatement("create table IF NOT EXISTS registry(type varchar(10), domainname varchar(255), servicename varchar(255), attributes varchar(4048), public_key varchar(4048), PRIMARY KEY(type,domainname,servicename));");
        st.executeUpdate();
    }
}
