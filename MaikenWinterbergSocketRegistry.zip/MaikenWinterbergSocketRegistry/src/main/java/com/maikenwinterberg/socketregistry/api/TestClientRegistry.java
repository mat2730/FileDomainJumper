/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class TestClientRegistry {

    public static void main(String arg[]) throws Exception {
        String sourceDomainnName = "localhost";
        String registryDomainName = "documentnetwork.com";// "maikenwinterberg.com";
        String doDomainCheck = "true";
        int port = 6666;
        try {
            sourceDomainnName = arg[0];
        } catch (Exception ex) {
        }
        try {
            String ipAndPort = arg[1];
            StringTokenizer tok = new StringTokenizer(ipAndPort, ":");
            try {
                registryDomainName = tok.nextToken();
            } catch (Exception ex) {
            }
            try {
                port = Integer.parseInt(tok.nextToken());
            } catch (Exception ex) {
            }
        } catch (Exception ex) {
        }
        ClientRegistry registry = null;
        System.out.println("creating registry.");
        registry = ClientRegistry.getRegistryInstance(sourceDomainnName, registryDomainName, port, true, true);
        System.out.println("Registry " +registry);
        System.out.println("starting with command.");
        System.out.println(registry.registerSocket("maikenwinterberg.com", "testSocket4!", "1", "localhost", "6666", null, null));
        System.out.println("unregister.jdbc");
        registry.UnRegister(ClientRegistry.TYPE.jdbc, null);
        System.out.println("unregister.socket");
        registry.UnRegister(ClientRegistry.TYPE.socket, null);
        System.out.println(registry.registerSocket("testSocket1!", "localhost.", "6666", null));
        System.out.println("");
        System.out.println(registry.registerSocket("testSocket2!", "localhost.", "6666", null));
        System.out.println("");
        System.out.println(registry.registerSocket("testSocket3!", "localhost.", "6666", null));
        System.out.println("");
        System.out.println(registry.registerJDBC("MariaDB1", "org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost:3306/project1", "userName1", "password1!"));
        System.out.println("");
        System.out.println(registry.registerJDBC("MariaDB2", "org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost:3306/project2", "userName1", "password1!"));
        System.out.println("");
        System.out.println(registry.registerJDBC("MariaDB3", "org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost:3306/project3", "userName1", "password1!"));
        System.out.println("");
        System.out.println(registry.registerJDBC("MariaDB1", "org.mariadb.jdbc.Driver", "jdbc:mariadb://localhost:3306/project4", "userName1", "password1!"));
        System.out.println("jdbc.localhost");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.jdbc, "localhost", null));
        System.out.println("socket.localhost");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.socket, "localhost", null));
        System.out.println("jdbc.maikenwinterberg.com");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.jdbc, "maikenwinterberg.com", null));
        System.out.println("jdbc.MariaDB1.localhost");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.jdbc, "localhost", "MariaDB1"));
        System.out.println("jdbc.MariaDB1.maikenwinterberg.com");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.jdbc, "maikenwinterberg.com", "MariaDB1"));
        System.out.println("jdbc.maikenwinterberg");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.jdbc, "maikenwinterberg.com", "localhost", null));
        System.out.println("socket.testSocket1.maikenwinterberg.com");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.socket, "maikenwinterberg.com", "testSocket1"));
        System.out.println("unregister.socket");
        registry.UnRegister(ClientRegistry.TYPE.socket, null);
        System.out.println("socket.localhost");
        printRegistreringer(registry.lookup(ClientRegistry.TYPE.socket, "localhost", null));

    }

    private static void printRegistreringer(List<AbstractRegisration> registreringer) {
        for (Iterator i = registreringer.iterator(); i.hasNext();) {
            AbstractRegisration r = (AbstractRegisration) i.next();
            System.out.println(r);
        }
    }
}
