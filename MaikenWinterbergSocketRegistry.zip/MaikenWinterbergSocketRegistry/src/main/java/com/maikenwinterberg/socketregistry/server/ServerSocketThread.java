/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.Socket;
import java.util.StringTokenizer;
import javax.crypto.SecretKey;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ServerSocketThread extends Thread {

    private final static boolean DEBUG = false;
    private final static boolean INFO = false;
    private final Socket clientSocket;

    ServerSocketThread(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    public void run() {
        String ipOfClient = clientSocket.getRemoteSocketAddress().toString();
        StringTokenizer tok = new StringTokenizer(ipOfClient, "/:");
        ipOfClient = tok.nextToken();
        if (ipOfClient != null && ipOfClient.equals("127.0.0.1")) {
            /*
            boolean useExternalId = Boolean.parseBoolean(Registry.getProperty("userExternaID"));
            if (useExternalId && DomainCheck.getExternalId() == null) {
                DomainCheck.updateExternalID();
            }*/
            ipOfClient = DomainCheck.getExternalId();
        }

        DataOutputStream out = null;
        DataInputStream in = null;
        if (DEBUG) {
            System.out.println(this.hashCode() + ": socket accepted of ip " + ipOfClient);
        }
        try {
            out = new DataOutputStream(clientSocket.getOutputStream());
            while (true) {
                boolean encrypted = true;
                try {
                    in = new DataInputStream(clientSocket.getInputStream());
                    if (DEBUG) {
                        System.out.println(this.hashCode() + ": reading from client...");
                    }
                    String utf;
                    try {
                        utf = in.readUTF();
                        if (utf == null) {
                            break;
                        }
                        if (DEBUG) {
                            System.out.println(this.hashCode() + ": receiving " + utf);
                        }
                        if (!utf.startsWith(Registry.PROTOCOL)) {
                            throw new SecurityException("Invalid protocol " + utf);
                        } else {
                            utf = utf.substring(Registry.PROTOCOL.length());
                        }
                        if (utf.startsWith("encrypted=false")) {
                            utf = utf.substring(15);
                            encrypted = false;
                        } else {
                            //has secret key check
                            SecretKey secretKey = RegistrySecurity.getSecretKey(Registry.class.getName(), ipOfClient);
                            if (secretKey == null) {
                                throw new SecurityException(ICommand.NO_SECURE_KEY_FOUND_ERROR + ipOfClient);
                            }
                            utf = RegistrySecurity.textDecrypt(Registry.class.getName(), ipOfClient, utf);// AESUtil.simpleDecrypt(ipOfClient, utf);
                        }
                    } catch (SecurityException sek) {
                        throw sek;
                    } catch (Exception ex) {
                        if (DEBUG) {
                            //ex.printStackTrace();
                        }
                        utf = null;
                    }
                    if (utf == null) {
                        break;
                    }
                    String response = executeCommand(encrypted, ipOfClient, utf);
                    if (encrypted) {
                        //out.writeUTF(AESUtil.simpleEncrypt(ipOfClient, response));
                        out.writeUTF(RegistrySecurity.textEncrypt(Registry.class.getName(), ipOfClient, response));
                    } else {
                        out.writeUTF("encrypted=false" + response);
                    }
                } catch (Exception ex) {
                    if (DEBUG) {
                        ex.printStackTrace();
                    }
                    try {
                        //write error
                        StringWriter sw = new StringWriter();
                        PrintWriter pw = new PrintWriter(sw);
                        ex.printStackTrace(pw);
                        String sStackTrace = sw.toString();
                        /* dont encrypt errros
                        if (encrypted) {
                            //out.writeUTF(AESUtil.simpleEncrypt(ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace));
                            out.writeUTF(RegistrySecurity.textEncrypt(Registry.class.getName(), ipOfClient, "status" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace));
                        }                    } else {
                            out.writeUTF("encrypted=falsestatus" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace);
                        }*/
                        out.writeUTF("encrypted=falsestatus" + ICommand.EQUAL_SEPERATOR + "error" + ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR + ex.getMessage() + ICommand.ATTR_SEPERATOR + "stacktrace" + ICommand.EQUAL_SEPERATOR + "\n" + sStackTrace);

                    } catch (Exception exe) {
                        exe.printStackTrace();
                    }
                }
            }
        } catch (Exception exe) {
            if (DEBUG) {
                exe.printStackTrace();
            }
        }
        try {
            if (in != null) {
                in.close();
            }
            out.close();
            clientSocket.close();
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        if (DEBUG) {
            System.out.println(this.hashCode() + ": done with client request");
        }
    }

    public static String executeCommand(boolean encrypted, String socketClientIP, String utf) throws Exception {
        RegistryCommands commands = new RegistryCommands();
        StringTokenizer tok = new StringTokenizer(utf, ICommand.ATTR_SEPERATOR);
        String domainName = null;
        String cmd = null;
        while (tok.hasMoreTokens()) {
            String token = tok.nextToken();
            StringTokenizer tok2 = new StringTokenizer(token, "=");
            String attributeName = null;
            String value = null;
            try {
                attributeName = tok2.nextToken().trim().toLowerCase();
                value = tok2.nextToken();
            } catch (Exception ex) {
            }
            if (value == null) {
                continue;
            }
            if (attributeName != null && !attributeName.trim().equalsIgnoreCase("")) {
                if (attributeName.equalsIgnoreCase("domainname")) {
                    domainName = value;
                } else if (attributeName.equalsIgnoreCase("cmd")) {
                    cmd = value;
                }
                if (DEBUG) {
                    System.out.println("adding attribute " + attributeName + " = " + value);
                }
                commands.addAttribute(attributeName, value);
            }
        }
        if (cmd == null) {
            throw new IllegalArgumentException("No command found in " + utf);
        }
        if (socketClientIP != null) {
            if (!encrypted && !cmd.replaceAll("_", ".").equals(RegisterpublickeyCmd.class.getName())) {
                throw new SecurityException("this command must be encrypted " + cmd + " from ip " + socketClientIP);
            }
        } else {
            System.out.println("ExecuteCommand: " + utf + " from conf/startup.cfg");
        }

        boolean acceptIpAsDomainName = true;
        try {
            if (Registry.getProperty("acceptIpAsDomainName").equalsIgnoreCase("false")) {
                acceptIpAsDomainName = false;
            }
        } catch (Exception ex) {
        }
        //domainName = DomainCheck.getDomainNameOnServer("conf/validDomains.cfg", "conf/inValidDomains.cfg", !acceptIpAsDomainName, socketClientIP, domainName);
        DomainCheck.validateDomainNameOnServer("conf/validDomains.cfg", "conf/inValidDomains.cfg", !acceptIpAsDomainName, socketClientIP, domainName);
        //override
        //commands.addAttribute("domainName", domainName);
        String response = commands.execute(socketClientIP);
        return response;
    }
}
