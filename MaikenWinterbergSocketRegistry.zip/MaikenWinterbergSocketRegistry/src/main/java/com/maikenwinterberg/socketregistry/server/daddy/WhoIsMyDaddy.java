/*
 * Martin Alexander Thomsen den 23 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server.daddy;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt
 *
 * TODO: whoIsMyDaddy - registry - ALWAYS UP -> reload properties needed -
 * DomainCheck - daddy must always be approved - Reload porperties -if change:
 * check all children if they have a new daddy -if so call newDaddyCmd on child
 * registry 4 lookups 1 full domainname 2 subdomain 2 3 subdomain 1 4 random DAD
 * when found daddy gem i DADDY TABLE daddyTable (childDomain, daddies) #one of
 * my chairs broke today (23 July 2024)
 */
public class WhoIsMyDaddy {

    public static String getDaddies(String clientSocketIP, Map<String, String> attributes) throws Exception {
        //TODO implement this as DB
        /*
        File parent = new File("./log");
        File child = new File(parent.getAbsoluteFile() + "/whoIsYourDaddy.log");
        parent.mkdirs();
        FileWriter fw = new FileWriter(child, true);
        BufferedWriter bw = new BufferedWriter(fw);
        bw.write(clientSocketIP);
        bw.write(":");
        try {
            bw.write(attributes.get("port"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        bw.newLine();
        bw.close();
        System.out.println("logging: " + child.exists() + ", " + clientSocketIP);
        */
        return null;
    }
}
