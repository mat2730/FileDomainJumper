/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.GetDomainnamesOfRegistry;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt You can freely make your own command
 * 
 * @SEE doc/fetchMedHarris.pdf
 */
public class SendInfoToParentRegistriesCmd implements ICommand {

    //TODO validate agains administrativ domainname (that is configured)
    //call up registryOfRegistry service(S) and send info about which domainnames are in the registry
    //TODO make service that call the SendInfoToREgistryOfRegistryCmd
    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String domainNameOfRegistry = Registry.getProperty("domainNameOfRegistry");
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        //the domain that make the exeution
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);

        String parentRegistries = Registry.getProperty("parentRegistries");
        if (parentRegistries == null) {
            System.out.println("no param: parentRegistries found in configuration. No info sent to parent");
            return "error=missing parameters. cmd" + ICommand.EQUAL_SEPERATOR + cmdType + ",domainname" + ICommand.EQUAL_SEPERATOR + domainName;
        }
        if (domainNameOfRegistry == null) {
            throw new IllegalArgumentException("please update your configuration (conf/fileDomainJumper.properties) defaultDomainNameOfClient is missing");
        }
        //get all domains that have a fileReciever of this registry
        String fetchloopAsString = Registry.getProperty("fetchloop");
        boolean fetchloop = false;
        try {
            fetchloop = Boolean.parseBoolean(fetchloopAsString);
        } catch (Exception ex) {
            //ignore
        }
        List<String> domainNames = GetDomainnamesOfRegistry.getDomainNamesOfRecievers(domainNameOfRegistry, domainNameOfRegistry + "." + Registry.getPort(), ClientRegistry.TYPE.socket.name(), domainName, "fileReceiver", fetchloop);
        StringBuilder builder = new StringBuilder();
        for (Iterator i = domainNames.iterator(); i.hasNext();) {
            builder.append(i.next());
            if (i.hasNext()) {
                builder.append(";");
            }
        }
        StringTokenizer tok = new StringTokenizer(parentRegistries, ";");
        while (tok.hasMoreTokens()) {
            try {
                String registry = tok.nextToken();
                StringTokenizer tok2 = new StringTokenizer(registry, ":");
                String ip = tok2.nextToken();
                int portInt = 6666;
                try {
                    String port = tok2.nextToken();
                    portInt = Integer.parseInt(port);
                } catch (Exception ex) {
                    //ignore
                }
                ClientRegistry cr = ClientRegistry.getRegistryInstance(domainNameOfRegistry, ip, portInt, false, false);
                boolean status = cr.receiveBulkRegistrations(builder.toString());
                if (status) {
                    return "status" + ICommand.EQUAL_SEPERATOR + "ok";
                } else {
                    return "error" + ICommand.EQUAL_SEPERATOR + "sending info to parent registry " + registry;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return "error" + ICommand.EQUAL_SEPERATOR + "sending info to parent registry";
    }
}
