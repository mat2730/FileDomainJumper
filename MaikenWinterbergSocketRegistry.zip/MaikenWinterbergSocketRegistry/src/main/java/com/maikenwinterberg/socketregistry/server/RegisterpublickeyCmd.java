/*
 * Martin Alexander Thomsen den 4 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.security.PublicKey;
import java.util.Map;
import javax.crypto.SecretKey;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;

/**
 * @author Martin Alexander Thomsen
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegisterpublickeyCmd implements ICommand {

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        if (domainName == null) {
            return "status"+ICommand.EQUAL_SEPERATOR+"error";
        }
        String p = attributes.get("securityplugin");
        if (p == null) {
            throw new SecurityException("securityplugin is missing");
        }
        // TODO set securyimpl on startup in Registry.java.
        if (p.equals(RegistrySecurity.DEFAULT_SECURITY_IMPL.getClass().getName())) {
            //ok
        } else {
            //return the current security impl
            return RegistrySecurity.DEFAULT_SECURITY_IMPL.getClass().getName();
        }
        String base64PublicKey = (String) attributes.get("publickey");
        if (base64PublicKey == null) {
            return "error=publickey is missing";
        }
        PublicKey publicKey = RegistrySecurity.fromBase642SPublicKey(Registry.class.getName(), base64PublicKey);// RSAUtil.fromBase64(base64PublicKey);
        SecretKey secretKey = RegistrySecurity.getSecretKey(Registry.class.getName(), clientSocketIP);
        String secretKeyAsEncryptedBase64 = RegistrySecurity.toBase64(Registry.class.getName(), RegistrySecurity.publicKeyEncryptSecretKey(null, publicKey, secretKey));//,// RSAUtil.encrypt(publicKey, secretKey.getEncoded());
        return secretKeyAsEncryptedBase64;
    }
}
