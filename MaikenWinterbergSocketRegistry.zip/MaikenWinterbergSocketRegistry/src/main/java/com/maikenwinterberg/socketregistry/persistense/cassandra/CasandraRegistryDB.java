/*
 * Martin Alexander Thomsen den 5 Juli 2024
 */
package com.maikenwinterberg.socketregistry.persistense.cassandra;

import java.util.Map;
import com.maikenwinterberg.socketregistry.persistense.IRegistryDB;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
//TODO implement this method
public class CasandraRegistryDB implements IRegistryDB{
    
    @Override
    public String register(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String lookup(String socketClientIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
