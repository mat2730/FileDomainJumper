/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me(Martin Alexander
 * Thomsen) see license.txt
 */
public class Registry {

    //DO NOT CHANGE THIS - see license.txt 
    public final static String PROTOCOL = "protocol" + ICommand.EQUAL_SEPERATOR + "maikenwinterberg.com,documentnetwork.com" + ICommand.ATTR_SEPERATOR;

    private static final boolean DEBUG = false;
    private static final Properties PROPERTIES = new Properties();

    private static ServerSocket SERVER_SOCKET;
    private static int port;
    private static String parentRegistries;

    public static String getProperty(String name) {
        return (String) PROPERTIES.get(name);
    }

    public static String getParentRegistries() {
        return parentRegistries;
    }

    public static int getPort() {
        return port;
    }

    private void initParent() {
        //WE WANT ONE NETWORK, THEREFORE, DO NOT CHANGE THIS WITHOUT AGGREMENT WITH ME - SE LICENSE.txt
        String domainNameOfRegistry = PROPERTIES.getProperty("domainNameOfRegistry");
        if (domainNameOfRegistry == null || domainNameOfRegistry.equalsIgnoreCase("localhost")) {
            DomainCheck.updateExternalID();
            domainNameOfRegistry = DomainCheck.getExternalId();
        }
        System.out.println("domainname of registry" + domainNameOfRegistry);
        Random ran = new Random();
        boolean b = ran.nextBoolean();
        String d1, d2;
        if (b) {
            d1 = "maikenwinterberg.com";
            d2 = "documentnetwork.com";
        } else {
            d1 = "documentnetwork.com";
            d2 = "maikenwinterberg.com";
        }
        Map attributes = new HashMap();
        attributes.put("port", ""+getPort());
        try {
            ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(domainNameOfRegistry, d1, 6666, false, false);
            List<AbstractRegisration> rl = clientRegistry.lookup(ClientRegistry.TYPE.map, domainNameOfRegistry, domainNameOfRegistry, "whoIsMyDaddy", attributes);
            if (rl != null && !rl.isEmpty()) {
                parentRegistries = (String) rl.get(0).getAttributes().get("parentRegistries");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("cannot get the whoIsMyDaddy attribute from " + d1);
        }
        try {
            if (parentRegistries == null) {
                ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(domainNameOfRegistry, d2, 6666, false, false);
                List<AbstractRegisration> rl = clientRegistry.lookup(ClientRegistry.TYPE.map, domainNameOfRegistry, domainNameOfRegistry, "whoIsMyDaddy", attributes);
                if (rl != null && !rl.isEmpty()) {
                    parentRegistries = (String) rl.get(0).getAttributes().get("parentRegistries");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            System.out.println("cannot get the whoIsMyDaddy attribute from " + d2);
        }
    }

    public void start() throws Exception {
        System.out.println("starting registry...");
        //load properties first
        //load config
        try {
            PROPERTIES.load(new FileInputStream("conf/registry.properties"));
            String securityimpl = PROPERTIES.getProperty("securityimpl");
            if (securityimpl != null) {
                try {
                    RegistrySecurity.DEFAULT_SECURITY_IMPL = (IRegistrySecurity) Class.forName(securityimpl).newInstance();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            File registryFile = new File("conf/startup.cfg");
            if (DEBUG) {
                System.out.println("DEBUG: " + registryFile.getAbsolutePath());
            }
            try (BufferedReader br = new BufferedReader(new FileReader(registryFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    try {
                        if (line.startsWith("#") || line.trim().isEmpty()) {
                            //this is a comment continue;
                            continue;
                        }
                        String output = ServerSocketThread.executeCommand(false, null, line);
                        if (DEBUG) {
                            System.out.println(output);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //WE WANT ONE NETWORK, THEREFORE, DO NOT CHANGE THIS WITHOUT AGGREMENT WITH ME - SE LICENSE.txt
        initParent();
        //startup serversocket
        SERVER_SOCKET = new ServerSocket(port);
        System.out.println("Listening...");
        while (true) {
            if (DEBUG) {
                System.out.println("waiting for socket...");
            }
            Socket clientSocket = SERVER_SOCKET.accept();
            if (DEBUG) {
                System.out.println("creating client thread...");
            }
            Thread thread = new ServerSocketThread(clientSocket);
            thread.start();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            SERVER_SOCKET.close();
        } finally {
            super.finalize();
        }
    }

    public static void main(String[] args) throws Exception {
        port = 6666;
        try {
            port = Integer.parseInt(args[0]);
        } catch (Exception ex) {
        }
        Registry server = new Registry();
        server.start();
    }
}
