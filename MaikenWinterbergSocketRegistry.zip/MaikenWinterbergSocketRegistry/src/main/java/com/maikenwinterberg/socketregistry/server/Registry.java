/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.server;

import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Properties;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class Registry {

    //I give my software for free and you can change it the way you want. However, I have one request: That you leave the protocol as is. Martin Alexander Thomsen
    public final static String PROTOCOL = "protocol" + ICommand.EQUAL_SEPERATOR + "maikenwinterberg.com,documentnetwork.com" + ICommand.ATTR_SEPERATOR;

    private static final boolean DEBUG = false;
    private static final Properties PROPERTIES = new Properties();

    private static ServerSocket SERVER_SOCKET;

    public static String getProperty(String name) {
        return (String) PROPERTIES.get(name);
    }

    public void start(int port) throws Exception {
        //load properties first
        //load config
        try {
            PROPERTIES.load(new FileInputStream("conf/registry.properties"));
            String securityimpl = PROPERTIES.getProperty("securityimpl");
            if (securityimpl != null) {
                try {
                    RegistrySecurity.DEFAULT_SECURITY_IMPL = (IRegistrySecurity) Class.forName(securityimpl).newInstance();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
    } catch (Exception ex) {
            ex.printStackTrace();
        }
        try {
            File registryFile = new File("conf/startup.cfg");
            if (DEBUG) {
                System.out.println("DEBUG: " + registryFile.getAbsolutePath());
            }
            try (BufferedReader br = new BufferedReader(new FileReader(registryFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    try {
                        if (line.startsWith("#") || line.trim().isEmpty()) {
                            //this is a comment continue;
                            continue;
                        }
                        String output = ServerSocketThread.executeCommand(false, null, line);
                        if (DEBUG) {
                            System.out.println(output);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        //startup serversocket
        SERVER_SOCKET = new ServerSocket(port);
        System.out.println("Listening...");
        while (true) {
            if (DEBUG) {
                System.out.println("waiting for socket...");
            }
            Socket clientSocket = SERVER_SOCKET.accept();
            if (DEBUG) {
                System.out.println("creating client thread...");
            }
            Thread thread = new ServerSocketThread(clientSocket);
            thread.start();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            SERVER_SOCKET.close();
        } finally {
            super.finalize();
        }
    }

    public static void main(String[] args) throws Exception {
        int port = 6666;
        try {
            port = Integer.parseInt(args[0]);
        } catch (Exception ex) {
        }
        Registry server = new Registry();
        server.start(port);
    }
}
