/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.socketregistry.server;

import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * Changes to this file you must do in coloboration with me(Martin Alexander Thomsen) see license.txt
 * You can freely make your own commands
 */
public class ReceiveBulkRegistrationCmd implements ICommand {

    @Override
    public String execute(String clientSocketIP, Map<String, String> attributes) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
