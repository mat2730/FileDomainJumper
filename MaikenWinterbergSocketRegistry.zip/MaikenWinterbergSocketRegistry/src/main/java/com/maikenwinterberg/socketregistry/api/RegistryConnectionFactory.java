/*
 * Martin Alexander Thomsen den 2 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import com.maikenwinterberg.socketregistry.server.DomainCheck;
import com.maikenwinterberg.registryofregistry.*;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryConnectionFactory {

    //private static final boolean DEBUG = false;
    //  private static final Map<String, SocketRegistration> SOCKER = new HashMap();

    /*
     * @return returns first workable connection otherwise null
     */
 /*
    public synchronized static JDBCRegistration getFirstValidDBCRegistration(String hostOfRegistry, int portOfRegistry, String ownDomainName, boolean doDomainCheck, String lookupDomainName, String serviceName) throws Exception {
        try {
            ClientRegistry registry = ClientRegistry.getInstance(ownDomainName, hostOfRegistry, portOfRegistry, doDomainCheck, );
            List registrations = registry.lookup(ClientRegistry.TYPE.jdbc, lookupDomainName, serviceName);
            for (Iterator i = registrations.iterator(); i.hasNext();) {
                try {
                    JDBCRegistration r = (JDBCRegistration) i.next();
                    Class.forName(r.getDriver()).newInstance();
                    Connection conn = DriverManager.getConnection(r.getDriver(), r.getUserName(), r.getPassword());
                    if (!conn.isClosed()) {
                        r.setConnection(conn);
                        return r;
                    }
                } catch (Exception ex) {
                }
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }
        return null;
    }*/
    public synchronized static SocketRegistration getFirstValidSocketRegistration(List<ClientRegistry> registryList, String domainNameOfClient, String lookupDomainName, String serviceName) throws Exception {
        //TODO use threads and mix result connect to newst registration
        for (Iterator<ClientRegistry> i = registryList.iterator(); i.hasNext();) {
            try {
                ClientRegistry cr = i.next();
                //in the case of dynamic ip
                //cr.updateDefaultDomainNameOnClient();
                //in the case of restart of the registry
                //cr.reconnect();
                SocketRegistration r = getValidSocketRegistration(cr, lookupDomainName, serviceName);
                if (r != null) {
                    //todo connect to latest registration
                    return r;
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                //ignore
            }
        }
        //registryofregistry
        String registries = RegistryOfRegistryAPI.getRegistries(lookupDomainName);
        StringTokenizer tok = new StringTokenizer(registries, ";");
        while (tok.hasMoreTokens()) {
            try {
                String registry = tok.nextToken();
                StringTokenizer tok2 = new StringTokenizer(registry, ":");
                String ip = tok2.nextToken();
                int port;
                try {
                    port = Integer.parseInt(tok2.nextToken());
                } catch (Exception ex) {
                    port = 6668;
                }
                ClientRegistry globalRegistry = ClientRegistry.getRegistryInstance(domainNameOfClient, ip, port, false, false);
                SocketRegistration r = getValidSocketRegistration(globalRegistry, lookupDomainName, serviceName);
                if (r != null) {
                    //todo connect to latest registration
                    return r;
                }

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return null;
    }

    public synchronized static SocketRegistration getValidSocketRegistration(ClientRegistry registry, String lookupDomainName, String serviceName) throws Exception {
        try {
            List registrations = registry.lookup(ClientRegistry.TYPE.socket, lookupDomainName, serviceName);
            for (Iterator i = registrations.iterator(); i.hasNext();) {
                try {
                    Object reg = i.next();
                    if (reg instanceof SocketRegistration) {
                        SocketRegistration r = (SocketRegistration) reg;
                        String ip = r.getIp();
                        if (DomainCheck.getExternalId() != null) {
                            System.out.println("comparing " + ip + " with " + DomainCheck.getExternalId());
                            if (ip.trim().equalsIgnoreCase(DomainCheck.getExternalId())) {
                                ip = "localhost";
                            }
                        }
                        System.out.println("connection to " + ip + ":" + r.getPort() + "...");
                        Socket socket = new Socket(ip, r.getPort());
                        if (!socket.isConnected()) {
                            System.out.println("no connection to " + ip + ":" + r.getPort());
                            continue;
                        }
                        System.out.println("connected to " + ip + ":" + r.getPort());
                        r.setSocket(socket);
                        return r;
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    //TODO getJMS
}
