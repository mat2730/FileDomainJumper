/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.socketregistry.api;

import com.maikenwinterberg.socketregistry.persistence.jdbc.RegistryJDBCDB;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 *
 * Changes to this file you must do in coloboration with me (Martin Alexander
 * Thomsen) see license.txt
 *
 * @SEE doc/fetchMedHarris.pdf
 */
public class GetDomainnamesOfRegistry {

    private static final Map<String, ClientRegistry> REGISTRIES = new HashMap();

    public static List<String> getDomainNamesOfRecievers(String defaultDomainName, String registries, String type, String lookupDomainName, String serviceName, boolean fetchloop) {
        ClientRegistry.TYPE ctype = ClientRegistry.TYPE.socket;
        try {
            ctype = ClientRegistry.TYPE.valueOf(type);
        } catch (Exception ex) {
            //ignore
        }
        boolean useExternalId = false;
        if (defaultDomainName.equals("localhost")) {
            useExternalId = true;
        }
        List<ClientRegistry> list = new LinkedList();
        List<String> domainnames = new LinkedList();

        StringTokenizer tok = new StringTokenizer(registries, ";");
        while (tok.hasMoreTokens()) {
            try {
                String registry = tok.nextToken();
                StringTokenizer tok2 = new StringTokenizer(registry, ":");
                String ip = tok2.nextToken();
                int portInt = 6666;
                try {
                    String port = tok2.nextToken();
                    portInt = Integer.parseInt(port);
                } catch (Exception ex) {
                    //ignore
                }
                ClientRegistry cr = REGISTRIES.get(registry);
                if (cr == null) {
                    cr = ClientRegistry.getRegistryInstance(defaultDomainName, ip, portInt, useExternalId, false);
                    REGISTRIES.put(cr.toString(), cr);
                } else {
                    //in the case of restart of the registry
                    cr.reconnect();
                }
                appendDomainNames(domainnames, cr, defaultDomainName, lookupDomainName, serviceName, fetchloop);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return domainnames;
    }

    private static void appendDomainNames(List domainnames, ClientRegistry cr, String defaultDomainName, String lookupDomainName, String serviceName, boolean fetchloop) throws Exception {
        //fetchloop requires a DB that supports OFFSET. H2 DB does not
        int offset = 0;
        int fetchSize = RegistryJDBCDB.MAXFETCHSIZE;
        if (!fetchloop) {
            List<AbstractRegisration> regList = cr.lookup(ClientRegistry.TYPE.socket, defaultDomainName, lookupDomainName, serviceName, offset, fetchSize);
            for (Iterator<AbstractRegisration> i2 = regList.iterator(); i2.hasNext();) {
                AbstractRegisration reg = i2.next();
                domainnames.add(reg.getDomainName());
            }
        } else {
            while (fetchloop) {
                List<AbstractRegisration> regList = cr.lookup(ClientRegistry.TYPE.socket, defaultDomainName, lookupDomainName, serviceName, offset, fetchSize);
                if (regList.isEmpty()) {
                    break;
                }
                for (Iterator<AbstractRegisration> i2 = regList.iterator(); i2.hasNext();) {
                    AbstractRegisration reg = i2.next();
                    domainnames.add(reg.getDomainName());
                }
                offset += fetchSize;
            }
        }
    }
}
