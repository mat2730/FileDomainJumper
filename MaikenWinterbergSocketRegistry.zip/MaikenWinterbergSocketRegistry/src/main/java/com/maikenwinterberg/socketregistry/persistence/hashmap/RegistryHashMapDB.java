/*
 * Martin Alexander Thomsen den 30 Juni 2024
 */
package com.maikenwinterberg.socketregistry.persistence.hashmap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import com.maikenwinterberg.socketregistry.persistence.AbstractRegistryDB;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.RegisterCmd;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class RegistryHashMapDB extends AbstractRegistryDB {

    private static final Map REGISTRATIONS_OF_TYPE_MAP = new HashMap();
    private static final boolean DEBUG = false;
    public static final String DOMAIN_KEY = "domain.";
    public static final String SERVICE_KEY = "service.";

    private static Map getRegistryMap(String type) {
        Map m = (Map) REGISTRATIONS_OF_TYPE_MAP.get(type.toLowerCase());
        if (m == null) {
            m = new HashMap();
            REGISTRATIONS_OF_TYPE_MAP.put(type.toLowerCase(), m);
        }
        return m;
    }

    @Override
    public String register(String socketClientIP, Map<String, String> attributes) throws Exception {
        attributes.put("socket_client_ip", socketClientIP);
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        long timestamp = System.currentTimeMillis();
        attributes.put("registration_timestamp", "" + timestamp);
        Map registryMap = getRegistryMap(cmdType);
        String key = domainName.toLowerCase() + "." + serviceName.toLowerCase();
        Map doomainCommands = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
        if (doomainCommands == null) {
            doomainCommands = new TreeMap();
            registryMap.put(DOMAIN_KEY + domainName.toLowerCase(), doomainCommands);
        }
        doomainCommands.put(key, attributes);
        Map serviceCommands = (Map) registryMap.get(SERVICE_KEY + serviceName.toLowerCase());
        if (serviceCommands == null) {
            serviceCommands = new TreeMap();
            registryMap.put(SERVICE_KEY + serviceName.toLowerCase(), serviceCommands);
        }
        serviceCommands.put(key, attributes);
        registryMap.put(key, attributes);

        return "status" + ICommand.EQUAL_SEPERATOR + "ok" + ICommand.ATTR_SEPERATOR + "timestamp" + ICommand.EQUAL_SEPERATOR + timestamp;
    }

    @Override
    public String unRegister(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);

        Map registryMap = getRegistryMap(cmdType);
        String status;
        String errorMessage = null;
        if (serviceName != null) {
            boolean ok = unregister(registryMap, domainName, serviceName);
            if (ok) {
                status = "ok";
            } else {
                status = "error";
            }
        } else {
            status = "error";
            errorMessage="Servicename is missing";
            //delete all service of domain
            /* cannot traverse TreeMap - BUG
            Map domainMap = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
            if (domainMap != null) {
                for (Iterator i = domainMap.values().iterator(); i.hasNext();) {
                    Map values = (Map) i.next();
                    serviceName = (String)values.get("servicename");
                    unregister(registryMap, domainName, serviceName);
                }
            }*/
        }
        StringBuilder builder = new StringBuilder();
        builder.append("status" + ICommand.EQUAL_SEPERATOR).append(status).append(ICommand.ATTR_SEPERATOR + "timestamp" + ICommand.EQUAL_SEPERATOR).append(System.currentTimeMillis());
        if (errorMessage != null) {
            builder.append(ICommand.ATTR_SEPERATOR + "errormessage" + ICommand.EQUAL_SEPERATOR).append(errorMessage);
        }
        return builder.toString();
    }

    private boolean unregister(Map registryMap, String domainName, String serviceName) {
        String key = domainName.toLowerCase() + "." + serviceName.toLowerCase();
        Object obj2Remove = registryMap.get(key);
        if (obj2Remove == null) {
            return false;
        }
        Map domainMap = (Map) registryMap.get(DOMAIN_KEY + domainName.toLowerCase());
        if (domainMap != null) {
            domainMap.remove(key, obj2Remove);
        }
        Map serviceMap = (Map) registryMap.get(SERVICE_KEY + serviceName.toLowerCase());
        if (serviceMap != null) {
            serviceMap.remove(key, obj2Remove);
        }
        registryMap.remove(key);
        return true;
    }

    @Override
    public String lookup(String socketClientIP, Map<String, String> attributes) throws Exception {
        String cmdType = attributes.get(ICommand.TYPE_PARAM);
        String domainName = attributes.get(ICommand.DOMAIN_NAME_PARAM);
        String serviceName = attributes.get(ICommand.SERVICE_NAME_PARAM);
        String lookupType = (String) attributes.get(ICommand.LOOKUP_TYPE_PARAM);

        if (cmdType == null) {
            cmdType = "default";
        }
        Map registryMap = getRegistryMap(cmdType);
        if (DEBUG) {
            System.out.println("lookup: " + cmdType + " registryMap " + registryMap.getClass().getName());
        }
        String lookupDomainName = (String) attributes.get("lookupdomainname");
        if (lookupDomainName == null) {
            lookupDomainName = domainName;
        }
        String key = null;
        switch (lookupType) {
            case ICommand.LOOKUP_ALL -> {
                key = null;
                break;
            }
            case ICommand.LOOKUP_BY_DOMAIN -> {
                key = RegisterCmd.DOMAIN_KEY + lookupDomainName.toLowerCase();
                break;
            }
            case ICommand.LOOKUP_BY_SERVICE -> {
                key = RegisterCmd.SERVICE_KEY + serviceName.toLowerCase();
                break;
            }
            case ICommand.LOOKUP_BY_DOMAIN_AND_SERVICE -> {
                Map lookupCommand = (Map) registryMap.get(lookupDomainName.toLowerCase() + "." + serviceName.toLowerCase());
                return getCommandAsString(lookupCommand);
            }
        }
        if (DEBUG) {
            System.out.println("lookuptype " + lookupType + ", key " + key);
        }
        List rcommands;
        if (key != null) {
            Map map = (Map) registryMap.get(key);
            if (map != null) {
                rcommands = new LinkedList(map.values());
            } else {
                rcommands = new LinkedList();
            }
        } else {
            rcommands = new LinkedList();
            for (Iterator i = registryMap.keySet().iterator(); i.hasNext();) {
                key = (String) i.next();
                Object obj = registryMap.get(key);
                if (obj instanceof HashMap) {
                    if (DEBUG) {
                        System.out.println("adding to commandMap " + key);
                    }
                    rcommands.add(obj);
                }
            }
        }
        StringBuilder stringBuilder = new StringBuilder();
        if (DEBUG) {
            System.out.println("size of commandMap " + rcommands.size());
        }
        for (Iterator i = rcommands.iterator(); i.hasNext();) {
            Map command = (Map) i.next();
            String commandAsString = getCommandAsString(command);
            stringBuilder.append(commandAsString);
            if (i.hasNext()) {
                stringBuilder.append(ICommand.REG_SEPERATOR);
            }
        }
        return stringBuilder.toString();

    }
}
