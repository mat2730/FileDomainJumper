/*
 * Martin Alexander Thomsen den 23 Juli 2024
 */
import com.maikenwinterberg.socketregistry.server.Registry;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class startRegistry {

    public static void main(String arg[]) throws Exception {
        Registry.main(arg);
    }
}
