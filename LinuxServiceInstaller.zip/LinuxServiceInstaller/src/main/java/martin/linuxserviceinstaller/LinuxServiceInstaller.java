/*
 * Martin Alexander Thomsen den 14 Juli 2024
 */
package martin.linuxserviceinstaller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.Console;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.attribute.PosixFilePermission;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class LinuxServiceInstaller {

    public static String replaceAll(Map<String, String> attribute, String text) {
        int i = text.indexOf("${");
        int currentIndex = 0;
        StringBuilder builder = new StringBuilder();
        while (i != -1) {
            String part = text.substring(currentIndex, i);
            builder.append(part);
            currentIndex = text.indexOf("}", i);
            String attributeName = text.substring(i + 2, currentIndex);
            currentIndex++;
            String value = (String) attribute.get(attributeName);
            builder.append(value);
            i = text.indexOf("${", i + 1);
        }
        builder.append(text.substring(currentIndex, text.length()));
        return builder.toString();
    }

    public static String load(String path2Template) throws Exception {
        File templateServiceFile = new File(path2Template);
        StringBuilder builder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new FileReader(templateServiceFile))) {
            String line;
            while ((line = br.readLine()) != null) {
                builder.append(line).append("\n");
            }
        }
        return builder.toString().trim();
    }

    public static File save(String fileName, String text2Save) throws Exception {
        File f = new File(fileName);
        FileOutputStream fos = new FileOutputStream(f);
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        bos.write(text2Save.getBytes("utf-8"));
        bos.close();
        Set<PosixFilePermission> perms = new HashSet<>();
        perms.add(PosixFilePermission.GROUP_EXECUTE);
        perms.add(PosixFilePermission.GROUP_READ);
        perms.add(PosixFilePermission.GROUP_WRITE);
        perms.add(PosixFilePermission.OTHERS_EXECUTE);
        perms.add(PosixFilePermission.OTHERS_READ);
        perms.add(PosixFilePermission.OTHERS_WRITE);
        perms.add(PosixFilePermission.OWNER_READ);
        perms.add(PosixFilePermission.OWNER_WRITE);
        perms.add(PosixFilePermission.OWNER_EXECUTE);
        Files.setPosixFilePermissions(f.toPath(), perms);
        return f;
    }

    public static File createScript(String serviceName, Map attributes, String workingDirectory, String configName, String shFileName) throws Exception {
        String template = load(configName);
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return null;
        }
        template = replaceAll(attributes, template);
        //change permisions of sh file
        File f = save(new File(shFileName).getName(), template);
        return f;
    }

    public static boolean runWithPrivileges(String password, String cmd) throws Exception {

        try {
            String[] command = {"/bin/bash", "-c", "echo \"" + password + "\"| sudo -S " + cmd};
            //System.out.println("command " + Arrays.toString(command));
            Process pb = new ProcessBuilder(command).start();
            int exitValue = pb.waitFor();

            InputStream is = pb.getInputStream();
            BufferedInputStream bis = new BufferedInputStream(is);
            int a = bis.available();
            if (a > 0) {
                byte[] bytes = new byte[a];
                bis.read(bytes);
                String output = new String(bytes, "utf-8").trim();
                System.out.println(output);
            }
            if (exitValue == 0) {
                System.out.println("Successfully installed the service");
                return true;
            } else {
                System.out.println("Failed to install the service. Try to run the reInstall${ServiceName}.sh command");
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return false;
    }

    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        //get parameters
        String serviceName = null;
        try {
            serviceName = args[0];
        } catch (Exception ex) {
            //serviceName = "service";
            System.out.println("Please enter the name of the service");
            serviceName = scanner.nextLine();
        }
        String homeFolder = null;
        try {
            homeFolder = args[1];
        } catch (Exception ex) {
            //homeFolder = ".";
            System.out.println("Please enter the name of the home folder");
            homeFolder = scanner.nextLine();
        }
        String startupScript = null;
        try {
            startupScript = args[2];
        } catch (Exception ex) {
            //startupScript = serviceName + "Startup.sh";
            System.out.println("Please enter the name of the startup command");
            startupScript = scanner.nextLine();
        }
        String configFolder = null;
        try {
            configFolder = args[3];
        } catch (Exception ex) {
            configFolder = "conf";
            //System.out.println("Please enter the name of the configuration folder");
            //serviceName = scanner.nextLine();
        }
        //init attributes
        InputStream is = Runtime.getRuntime().exec("whoami").getInputStream();
        int a = is.available();
        byte[] bytes = new byte[a];
        is.read(bytes);
        String user = new String(bytes, "utf-8").trim();
        //System.out.println("Please enter username");
        //String user = scanner.nextLine();
        Console console = System.console();
        String password = String.valueOf(console.readPassword("Please enter password:"));
        String workingDirectory = new File(homeFolder).getCanonicalPath();
        String shScript = workingDirectory + "/" + startupScript;
        Map<String, String> attributes = new HashMap();
        attributes.put("serviceName", serviceName);
        attributes.put("user", user);
        attributes.put("workingDirectory", workingDirectory);
        attributes.put("shScript", shScript);
        //build service.service file
        String template = load(configFolder + "/template.service");
        if (template == null) {
            System.out.println("No templage.service found in conf");
            return;
        }
        template = replaceAll(attributes, template);
        save(serviceName + ".service", template);
        //build sh files
        File f = createScript(serviceName, attributes, workingDirectory, configFolder + "/installServiceTemplate.sh", workingDirectory + "/reInstall" + serviceName.substring(0, 1).toUpperCase() + serviceName.substring(1) + ".sh");
        createScript(serviceName, attributes, workingDirectory, configFolder + "/unInstallServiceTemplate.sh", workingDirectory + "/unInstall" + serviceName.substring(0, 1).toUpperCase() + serviceName.substring(1) + ".sh");
        createScript(serviceName, attributes, workingDirectory, configFolder + "/statusServiceTemplate.sh", workingDirectory + "/status" + serviceName.substring(0, 1).toUpperCase() + serviceName.substring(1) + ".sh");
        //execute sh file
        String cmd = "echo \"" + password + "\" | sudo " + f.getAbsolutePath();
        runWithPrivileges(password, cmd);
        System.out.println("done");
    }
}
