java --class-path ../LinuxServiceInstaller/target/LinuxServiceInstaller-1.0-SNAPSHOT.jar martin.linuxserviceinstaller.LinuxServiceInstaller
