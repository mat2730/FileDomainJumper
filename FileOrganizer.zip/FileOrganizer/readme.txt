The FileOrganizer will organize your documents into folders by date. it will try to find a date inside the file.

This program requires that Java is installed on your computer. 
Java hcan be download at: https://www.oracle.com/java/technologies/downloads/

Put files into the bin/defaultImageSource and execute bin/moveFiles.sh or bin/copyFiles.sh. 
Then files are bening moved or copied into the bin/defaultImageDestination folder.
