/*
 * Martin Alexander Thomsen den 21 Juni 2024
 */
package martin.fileorganizer;

import com.drew.imaging.ImageMetadataReader;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author ron
 */
public class FileOrganizer {

    private static boolean DEBUG = false;

    private static void copyFile(String year, String month, String day, File destinationFolder, File sourceFile) throws Exception {
        if (DEBUG) {
            System.out.println("\tcopy file to " + destinationFolder.getAbsolutePath());
        }
        File newDestFolderName = new File(destinationFolder.getAbsolutePath() + "/" + year + "/" + month + "/" + day);
        newDestFolderName.mkdirs();
        File newFile = new File(newDestFolderName, sourceFile.getName());
        if (sourceFile.getAbsolutePath().equals(newFile.getAbsolutePath())) {
            //dont copy. they are the same name.
            return;
        }
        newFile.setLastModified(sourceFile.lastModified());
        if (DEBUG) {
            System.out.println("\t" + newFile.toString());
        }
        BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(newFile));
        BufferedInputStream bis = new BufferedInputStream(new FileInputStream(sourceFile));
        int available = bis.available();
        while (available > 0) {
            bos.write(bis.readAllBytes());
            available = bis.available();
        }
        bos.close();
        bis.close();
        //update createdAt
        BasicFileAttributeView sourceAttributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
        FileTime sourceCreationTime = sourceAttributes.readAttributes().creationTime();
        BasicFileAttributeView destAttributes = Files.getFileAttributeView(Paths.get(newFile.getAbsolutePath()), BasicFileAttributeView.class);
        destAttributes.setTimes(sourceCreationTime, sourceCreationTime, sourceCreationTime);
    }

    private static void moveFile(String year, String month, String day, File destinationFolder, File sourceFile) throws Exception {
        if (DEBUG) {
            System.out.println("\tmove file to " + destinationFolder.getAbsolutePath());
        }
        //opret destfolder if not exists
        File newDestFolderName = new File(destinationFolder.getAbsolutePath() + "/" + year + "/" + month + "/" + day);
        newDestFolderName.mkdirs();
        File newFile = new File(newDestFolderName, sourceFile.getName());
        if (!sourceFile.getAbsolutePath().equals(newFile.getAbsolutePath())) {
            sourceFile.renameTo(newFile);
        }
    }

    private static void traverseFiles(File destFolder, File baseSourceFolder, File sourceFolder, char command, boolean withFolderTimeReset) {
        try {
	    File[] sourceFiles = sourceFolder.listFiles();
	    for (int i = 0; i < sourceFiles.length; i++) {
	        File sourceFile = sourceFiles[i];
	        if (!sourceFile.isDirectory()) {
	    	    doFile(destFolder, sourceFile, command, withFolderTimeReset);
		} else {
		    traverseFiles(destFolder, baseSourceFolder, sourceFile, command, withFolderTimeReset);
		}
            }
        }
        catch(Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
        }        
        if (command == 'M') {
            while (sourceFolder != null && baseSourceFolder.compareTo(sourceFolder) != 0) {
                if (sourceFolder == null || sourceFolder.listFiles() == null || baseSourceFolder == sourceFolder) {
            	    break;
            	}
            	if (sourceFolder.listFiles().length==0) {
            	    sourceFolder.delete();
            	    if (DEBUG) {
            	        System.out.println("\tDeleting folder: " + sourceFolder.getAbsolutePath());
            	    }
            	}
            	else if (DEBUG) {
            	    System.out.println("\tSize of folder: " + sourceFolder.getAbsolutePath() + " = " + sourceFolder.listFiles().length);
            	}
            	sourceFolder = sourceFolder.getParentFile();
            }
        }
    }

    private static void doFile(File destFolder, File sourceFile, char command, boolean withFolderTimeReset) {
        try {
            if (DEBUG && sourceFile != null) {
                System.out.println("file = " + sourceFile.getAbsolutePath());
            }
            Date date = null;
            if (withFolderTimeReset) {
                //get time from parentLocations
                try {
                    String day = sourceFile.getParentFile().getName();
                    String month = sourceFile.getParentFile().getParentFile().getName();
                    String year = sourceFile.getParentFile().getParentFile().getParentFile().getName();
                    SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
                    SimpleDateFormat df2 = new SimpleDateFormat("HH:mm:ss");
                    SimpleDateFormat df3 = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
                    String folderDateAsString = year + month + day;
                    df.parse(folderDateAsString); //test
                    BasicFileAttributeView attributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
                    Date creationDate = new Date(attributes.readAttributes().creationTime().toMillis());
                    String creationDateAsString = df.format(creationDate);
                    if (!folderDateAsString.equalsIgnoreCase(creationDateAsString)) {
                        //update date of file
                        String createTime_hhmmss = df2.format(creationDate);
                        Date newDate = df3.parse(folderDateAsString + " " + createTime_hhmmss);
                        FileTime FolderTime = FileTime.fromMillis(newDate.getTime());
			attributes.setTimes(FolderTime, FolderTime, FolderTime);
			try {
			    //update with drew
			    Metadata md = ImageMetadataReader.readMetadata(sourceFile);
                    	    ExifSubIFDDirectory directory = md.getFirstDirectoryOfType(ExifSubIFDDirectory.class);
                    	    if (directory != null) {
                       		directory.setDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL, newDate);
                       		date = newDate;
                     	    }
                       	    else {
                       		date = newDate;
                       	    }
                       	    if (DEBUG && date != null) {
	                        System.out.println("\tGetting Time from filepath");
	               	    }
			}
			catch(Exception exec) {
			    //ignore
			}
                        if (DEBUG) {
                            System.out.println("Updating time of File: " + sourceFile.getAbsolutePath() + ", to " + newDate + " from " + creationDate);
                        }
                    }
                } catch (Exception ex) {
                    //ignore
                    date = null;
                }
            }

            if (date == null) {
                try {
                    Metadata md = ImageMetadataReader.readMetadata(sourceFile);
                    ExifSubIFDDirectory directory = md.getFirstDirectoryOfType(ExifSubIFDDirectory.class);
                    if (directory != null) {
                        date = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                        if (DEBUG && date != null) {
                            System.out.println("\tGetting Time from drew");
                        }
                    }
                } catch (Exception exe) {
                    //ignore
                }
            }
            if (date == null) {
                try {
                    BasicFileAttributeView attributes = Files.getFileAttributeView(Paths.get(sourceFile.getAbsolutePath()), BasicFileAttributeView.class);
                    date = new Date(attributes.readAttributes().creationTime().toMillis());
                    if (DEBUG) {
                        System.out.println("\tGetting Time from nio");
                    }
                } catch (Exception exec) {
                    //ignore
                }
            }
            if (date == null) {
                try {
                    date = new Date(sourceFile.lastModified());
                    if (DEBUG) {
                        System.out.println("\tGetting Time from lastModified");
                    }
                } catch (Exception ioe) {
                }
            }
            if (date == null) {
                System.out.println("\n An error with the Date in file: " + sourceFile.getAbsolutePath());
                return;
            }
            SimpleDateFormat dfYear = new SimpleDateFormat("yyyy");
            SimpleDateFormat dfMonth = new SimpleDateFormat("MM");
            SimpleDateFormat dfDay = new SimpleDateFormat("dd");
            if (command == 'M') {
                moveFile(dfYear.format(date), dfMonth.format(date), dfDay.format(date), destFolder, sourceFile);
            } else if (command == 'C') {
                copyFile(dfYear.format(date), dfMonth.format(date), dfDay.format(date), destFolder, sourceFile);
            } else {
            	System.err.println("Unknown command: " + command+ " of file: " + sourceFile.getAbsolutePath());
            }
        } catch (Exception ex) {
            if (DEBUG) {
                ex.printStackTrace();
            }
            if (sourceFile != null) {
            	System.err.println("File not supported: " + sourceFile.getAbsolutePath());
            }
        }
    }

    public static void main(String[] args) {
        int index = 0;
        String cmd1 = null;
        try {
            cmd1 = args[index++];
        } catch (Exception ex) {
            //ignore
        }
        File destFolder = null;
        File sourceFolder = null;
        char command = 'M';
        boolean withFolderTimeReset = false;
        while (cmd1 != null) {
            switch (cmd1.toLowerCase()) {
                case "-d":
                    String value = null;
                    try {
                        value = args[index++];
                    } catch (Exception ex) {
                        //ignore
                    }
                    if (value != null) {
                        destFolder = new File(value);
                    }
                    break;
                case "-s":
                    value = null;
                    try {
                        value = args[index++];
                    } catch (Exception ex) {
                        //ignore
                    }
                    if (value != null) {
                        sourceFolder = new File(value);
                    }
                    break;
                case "-m":
                    command = 'M';
                    break;
                case "-c":
                    command = 'C';
                    break;
                case "-t":
                    withFolderTimeReset = true;
                    break;
                case "-debug":
                    DEBUG = true;
                    break;
            }
            try {
                cmd1 = args[index++];
            } catch (Exception ex) {
                //ignore
                cmd1 = null;
            }
        }
        if (destFolder == null) {
            JFrame frame = new JFrame("File organizer");
            frame.setLocationRelativeTo(null);
            JFileChooser fc = new JFileChooser();
            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            fc.setMultiSelectionEnabled(false);
            JOptionPane.showMessageDialog(null, "Select destination folder");
            frame.setSize(300, 200);
            frame.setVisible(true);
            int retVal = fc.showOpenDialog(frame);
            if (retVal == JFileChooser.APPROVE_OPTION) {
                File f = fc.getSelectedFile();
                if (!f.isDirectory()) {
                    f = f.getParentFile();
                }
                destFolder = f;
            }
            frame.setVisible(false);
        }
        if (sourceFolder == null) {
            JFrame frame = new JFrame("File organizer");
            frame.setLocationRelativeTo(null);
            JFileChooser fc = new JFileChooser();
            fc.setMultiSelectionEnabled(false);
            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            JOptionPane.showMessageDialog(null, "Select source folder");
            frame.setSize(300, 200);
            frame.setVisible(true);
            int retVal = fc.showOpenDialog(frame);
            if (retVal == JFileChooser.APPROVE_OPTION) {
                File f = fc.getSelectedFile();
                if (!f.isDirectory()) {
                    f = f.getParentFile();
                }
                sourceFolder = f;
            }
            frame.setVisible(false);
        }
        if (destFolder == null) {
            destFolder = new File("../defaultBilledeDestination");
        }
        if (sourceFolder == null) {
            sourceFolder = new File("../defaultBilledeSource");
        }
        if (DEBUG) {
            System.out.println(sourceFolder + " -> " + destFolder + ", Command= " + command + ", withFolderTimeReset="+withFolderTimeReset);
        }
        traverseFiles(destFolder, sourceFolder, sourceFolder, command, withFolderTimeReset);
        if (DEBUG) {
            System.out.println("DONE");
        }
    }
}
