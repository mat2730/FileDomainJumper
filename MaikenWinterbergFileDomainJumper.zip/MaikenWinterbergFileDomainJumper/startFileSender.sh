java --class-path target/classes:./lib/MaikenWinterbergSocketRegistry-1.0-SNAPSHOT.jar:./lib/h2-2.2.224.jar com/maikenwinterberg/filedomainjumper/ClientFileDomainJumper > log/fileSender.log
