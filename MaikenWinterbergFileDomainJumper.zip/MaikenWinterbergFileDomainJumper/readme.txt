The FileDomainJumper is a tool for securly sending and receiving document between domains

This program requires:
    - That Java is installed on your computer. Java can be download at: https://www.oracle.com/java/technologies/downloads/
    - Both the sender and the receiver domain must have a FileDomainJumper installed. Port 6667 must be open.
    - You have a valid domain that points to a static IP address on with you run the FileDomainJumper.
    - you must replace: "localhost" with your domainname everywhere in the conf/*.properties files. 

Getting started:
1) update configuration
    modify the defaultDomainNameOfClient attribute in the files: "conf/3lientFileDomainJumper.propeties og conf/fileDomainJumper.properties" in order to match the domainname of your system.
2) start the services 
    look into the readme.txt file in folder ./linux_service and the ./windows_service 
3) update the static receiver domain list in file /box/outbox/staticReceiverDomains.cfg - You can try to insert your own domain to see if you can send a document to yourself.
4) send documents by inserting them into the folder: /box/outbox/static/
5) check the log file for debug in log/fileSender and log/fileReceiver

If you wish to change the code or create plugins for the MaikenWinterbergFileDomainJumper can I recommend Netbeans: https://netbeans.apache.org/front/main/index.html
