/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file.persistence;

import java.io.File;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public interface IFileRegistry {
    //check if registrated (key = receiverDomainName,fullFileName, fileSize and fileDate)
    public boolean isRegistrated(int configurationIndex, String domainName, File file) throws Exception;  
    public void registerFile(int configurationIndex, String domainName, File file) throws Exception;
}