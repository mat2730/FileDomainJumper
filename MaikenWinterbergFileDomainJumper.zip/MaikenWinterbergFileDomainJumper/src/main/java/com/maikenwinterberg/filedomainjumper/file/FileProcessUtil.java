/*
 * Martin Alexander Thomsen den 22 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.filedomainjumper.FileDomainJumper;
import com.maikenwinterberg.socketregistry.server.ICommand;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import javax.swing.filechooser.FileSystemView;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileProcessUtil {

    public static String removeFirstPartIfEqual(String firstPart, String fileName) {
        int index = fileName.toLowerCase().indexOf(firstPart.toLowerCase());
        if (index != -1) {
            return "/" + fileName.substring(index + firstPart.length());
        }

        return fileName;
    }

    private static String appendHome(String folder) {
        if (folder.startsWith("/desktop")) {
            FileSystemView view = FileSystemView.getFileSystemView();
            File file = null;
            File dt = new File(view.getHomeDirectory() + "/Skrivebord");
            if (dt.exists()) {
                file = dt;
            } else {
                dt = new File(view.getHomeDirectory() + "/Desktop");
                if (dt.exists()) {
                    file = dt;
                }
            }
            if (file == null) {
                file = view.getHomeDirectory();
            }
            try {
                folder = file.getAbsolutePath() + folder.substring(8);
            } catch (Exception ex) {
                folder = file.getAbsolutePath();
            }
        } else if (folder.startsWith("/home")) {
            FileSystemView view = FileSystemView.getFileSystemView();
            File file = view.getHomeDirectory();
            try {
                folder = file.getAbsolutePath() + folder.substring(5);
            } catch (Exception ex) {
                folder = file.getAbsolutePath();
            }
        }
        return folder;
    }

    public static File getOutbox(int index) {
        String outbox = ClientFileDomainJumper.getProperty(index + ".outbox");
        if (outbox == null) {
            outbox = "/home/box/outbox";
        }
        outbox = appendHome(outbox);
        File dir = new File(outbox);
        dir.mkdirs();
        return dir;
    }

    public static File getErrorBox(int index) {
        String defaultErrorFolder = ClientFileDomainJumper.getProperty("defaultErrorFolder");
        String errorFolder = ClientFileDomainJumper.getProperty(index + ".errorFolder");
        if (errorFolder == null || errorFolder.trim().isEmpty()) {
            errorFolder = "/home/box/errorBox";
        }
        errorFolder = appendHome(errorFolder);
        File folder = new File(defaultErrorFolder);
        folder.mkdirs();
        return folder;
    }

    public static File getDomainNotFoundBox(int index) {
        String defaultDomainNotFoundFolder = ClientFileDomainJumper.getProperty("defaultDomainNotFoundFolder");
        String domainNotFoundFolder = ClientFileDomainJumper.getProperty(index + ".domainNotFoundFolder");
        if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
            domainNotFoundFolder = defaultDomainNotFoundFolder;
        }
        if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
            domainNotFoundFolder = "/home/box/domainNotFound";
        }
        domainNotFoundFolder = appendHome(domainNotFoundFolder);
        File folder = new File(domainNotFoundFolder);
        folder.mkdirs();
        return folder;
    }

    public static void processDomainNotFound(int index, String path, File file) {
        String domainNotFoundFolder = FileProcessUtil.getDomainNotFoundBox(index).getAbsolutePath();
        path = FileProcessUtil.removeFirstPartIfEqual("domainNotFound", path);
        new File(domainNotFoundFolder + path).mkdirs();
        File newFile = new File(domainNotFoundFolder + path + "/" + FileProcessUtil.addIndex(file.getName()));
        file.renameTo(newFile);
        System.out.println("Error: File moved to " + newFile.getAbsolutePath());
    }

    public static File getSentBox(int index) {
        String defaultSentFolder = ClientFileDomainJumper.getProperty("defaultSentFolder");
        String sentFolder = ClientFileDomainJumper.getProperty(index + ".sendFolder");
        if (sentFolder == null || sentFolder.trim().isEmpty()) {
            sentFolder = defaultSentFolder;
        }
        sentFolder = appendHome(sentFolder);
        File sentFolderFile = new File(sentFolder);
        sentFolderFile.mkdirs();
        return sentFolderFile;
    }

    public static File processInbox(String path, int configurationIndex, List<String> okDomains, File file, String preName) throws Exception {
        String domainName = null;
        try {
            domainName = okDomains.get(0);
        } catch (Exception ex) {
        }
        if (domainName == null) {
            domainName = "unknown_sender";
        }
        int index = path.indexOf(domainName);
        if (index != -1) {
            path = path.substring(domainName.length()+1);
        }

        String defaulInboxFolder = FileDomainJumper.getProperty("defaultInboxFolder");
        String inboxFolder = FileDomainJumper.getProperty(configurationIndex + ".registration.inboxFolder");
        if (inboxFolder == null || inboxFolder.trim().isEmpty()) {
            inboxFolder = defaulInboxFolder;
        }
        File inboxFolderFile = new File(inboxFolder + "/" + domainName + path);
        boolean ok = inboxFolderFile.mkdirs();
        System.out.println("inbox directory " + inboxFolderFile.getAbsolutePath() + ", "+ ok);
        File newFile = new File(inboxFolder + "/" + domainName + path + "/" + preName + file.getName());
        System.out.println("File received: File will be created in folder " + newFile.getAbsolutePath());
        return newFile;
    }

    public static void deleteEmptyDir(String nameOfDirNot2Delete, File directory) {
        for (File childFile : directory.listFiles()) {
            if (childFile.isDirectory()) {
                deleteEmptyDir(nameOfDirNot2Delete, childFile);
            }
        }
        if (directory.isDirectory() && directory.list().length == 0) {
            if (!directory.getName().equalsIgnoreCase(nameOfDirNot2Delete)) {
                directory.delete();
                System.out.println("deleting folder " + directory.getAbsolutePath() + ", status " + directory.delete());
            }
        }
    }

    public static String addIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + numberOfTries++ + "." + extension;
    }

    public static String removeIndex(String fileName) {
        //name dot index dot extension
        String name = null;
        int numberOfTries = 1;
        String extension = null;

        int loopCounter = 0;
        int dotIndex = fileName.lastIndexOf(".");
        String firstPart = fileName;
        loop:
        while (dotIndex != -1) {
            String lastPart = firstPart.substring(dotIndex + 1);
            firstPart = firstPart.substring(0, dotIndex);
            name = firstPart;
            switch (loopCounter) {
                case 0 -> {
                    extension = lastPart;
                    break;
                }
                case 1 -> {
                    String numberOfTriesAsString = lastPart;
                    try {
                        numberOfTries = Integer.parseInt(numberOfTriesAsString);
                        numberOfTries++;
                    } catch (Exception ex) {
                        //not an index its a name
                        break loop;
                    }
                    break;
                }
                case 2 -> {
                    break loop;
                }
            }
            dotIndex = firstPart.lastIndexOf(".");
            loopCounter++;
        }
        return name + "." + extension;
    }

    public static boolean copyFile(File fromFile, File toFile) {
        try {
            InputStream in = new BufferedInputStream(
                    new FileInputStream(fromFile));
            OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(toFile));

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (path.startsWith(".")) {
                path = path.substring(1);
            }
            if (path.startsWith(".")) {
                path = path.substring(1);
            }
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        int i = path.indexOf("/");
        if (i != -1) {
            //remove first path
            path = path.substring(i);
        }
        path = path.replaceAll(ICommand.SPACE_SEPERATOR, " ");
        path = path.replaceAll(" ", "_");
        return path;
    }
}
