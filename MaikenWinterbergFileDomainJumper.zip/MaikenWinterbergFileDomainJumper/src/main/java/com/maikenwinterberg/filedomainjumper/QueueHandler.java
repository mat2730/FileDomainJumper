/*
 * Martin Alexander Thomsen den 13 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLDecoder;
import java.security.PublicKey;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.crypto.SecretKey;
import com.maikenwinterberg.filedomainjumper.file.IFileProces;
import com.maikenwinterberg.filedomainjumper.file.ProcessFile;
import com.maikenwinterberg.filedomainjumper.router.DocumentRouterFactory;
import com.maikenwinterberg.filedomainjumper.router.IDocumentRouter;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.RegistryConnectionFactory;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.server.ICommand;
import com.maikenwinterberg.socketregistry.server.Registry;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class QueueHandler {

    private static final boolean DEBUG = false;

    public static void handleTaskInQueue(Map<String, SocketRegistration> registriesByDomain, JumperTask task) throws Exception {
        int outboxIndex = task.getOutboxIndex();
        List<ClientRegistry> lookupRegistries = task.getLookupRegistries();
        String serviceName = task.getServiceName();

        String path = task.getPath();
        path = path.replaceAll(" ", ICommand.SPACE_SEPERATOR);
        if (DEBUG) {
            System.out.println("path of file " + path + " file " + task.getFile().getAbsolutePath());
        }

        File file = task.getFile();

        List<String> okDomains = new LinkedList();
        List<String> notOkDomains = new LinkedList();
        int numberOfFilesSent = 0;
        try {
            IDocumentRouter router = DocumentRouterFactory.getRouter(outboxIndex, file);
            if (router == null) {
                System.out.println("router not configureded of index " + outboxIndex);
                ProcessFile.processFile(outboxIndex, okDomains, notOkDomains, path, file, IFileProces.DEST.outBox);
                return;
            }
            //for all receiver domainnames
            List<String> receiverDomainNames = router.getDomainNamesOfRecievers(outboxIndex, file);
            okDomains.clear();
            notOkDomains.clear();
            for (String receiverDomainName : receiverDomainNames) {
                try {
                    if (DEBUG) {
                        System.out.println("file processer " + ProcessFile.newInstance(outboxIndex, IFileProces.DEST.outBox) + " of file " + file + " to domain " + receiverDomainName);
                    }
                    if (!ProcessFile.doProcessFile(outboxIndex, receiverDomainName, file)) {
                        if (DEBUG) {
                            System.out.println("File transfere of file " + file.getCanonicalPath() + " to domain " + receiverDomainName + " is cancelled");
                        }
                        continue;
                    }
                    SocketRegistration socketRegistration = (SocketRegistration) registriesByDomain.get(receiverDomainName);
                    if (socketRegistration == null) {
                        //System.out.println("looking up connection propperties in registry " + lookupRegistries + " of domain " + receiverDomainName);
                        socketRegistration = RegistryConnectionFactory.getFirstValidSocketRegistration(lookupRegistries, task.getDomainNameOfClient(), receiverDomainName, serviceName);
                        if (socketRegistration != null) {
                            registriesByDomain.put(receiverDomainName, socketRegistration);
                        } else {
                            System.out.println("cannot establish a socket connection to " + receiverDomainName);
                        }
                    } else {
                        //socketRegistration.resetSocket();
                    }
                    if (socketRegistration == null) {
                        notOkDomains.add(receiverDomainName);
                        System.out.println("cannot establis a socket connection to " + receiverDomainName + ". a succesfully installed FileDomainJumper on domain is needed. looked in registries: " + lookupRegistries);
                        continue;
                    }
                    //make call to client and send file
                    DataOutputStream out = socketRegistration.getDataOutputStream();
                    DataInputStream in = socketRegistration.getDataInputStream();
                    String base64PublicKey = (String) socketRegistration.getBase64PublicKey();
                    if (DEBUG) {
                        System.out.println("socket used " + socketRegistration.getCount() + " times");
                    }
                    if (socketRegistration.getCount() == 1 && base64PublicKey != null) {
                        if (DEBUG) {
                            System.out.println("sending secret key to server...");
                        }
                        PublicKey publicKey = RegistrySecurity.fromBase642SPublicKey(socketRegistration.getSecurityImpl(), base64PublicKey);// RSAUtil.fromBase64(base64PublicKey);
                        SecretKey secretKey = RegistrySecurity.getSecretKey(socketRegistration.getSecurityImpl(), ClientFileDomainJumper.class.getName());// AESUtil.getProjectKey(ClientFileDomainJumper.class.getName());
                        byte[] encryptedSecretKey = RegistrySecurity.publicKeyEncryptSecretKey(socketRegistration.getSecurityImpl(), publicKey, secretKey);// RSAUtil.encrypt(publicKey, secretKey.getEncoded());
                        //DO NOT CHANGE THE PROTOCOL - see license.txt 
                        out.writeUTF(Registry.PROTOCOL + RegistrySecurity.toBase64(socketRegistration.getSecurityImpl(), encryptedSecretKey));
                    } else {
                        if (DEBUG) {
                            System.out.println("secret key has all ready been sent to server");
                        }
                    }
                    String attr = "registrationid" + ICommand.EQUAL_SEPERATOR + socketRegistration.getAttributes().get("registrationid") + ICommand.ATTR_SEPERATOR + "clientdomainname" + ICommand.EQUAL_SEPERATOR + socketRegistration.getClientDomainName() + ICommand.ATTR_SEPERATOR + "filename" + ICommand.EQUAL_SEPERATOR + URLDecoder.decode(file.getName(), "utf-8") + ICommand.ATTR_SEPERATOR + "filelength" + ICommand.EQUAL_SEPERATOR + file.length() + ICommand.ATTR_SEPERATOR + "path" + ICommand.EQUAL_SEPERATOR + path;
                    if (DEBUG) {
                        System.out.println("sending attribtue to the server " + attr);
                    }
                    //DO NOT CHANGE THE PROTOCOL - see license.txt 
                    out.writeUTF(Registry.PROTOCOL + RegistrySecurity.textEncrypt(socketRegistration.getSecurityImpl(), ClientFileDomainJumper.class.getName(), attr));//  AESUtil.simpleEncrypt(ClientFileDomainJumper.class.getName(), attr));
                    byte[] byteArray = new byte[(int) file.length()];
                    try (FileInputStream inputStream = new FileInputStream(file)) {
                        inputStream.read(byteArray);
                    }
                    byte[] data2Send = RegistrySecurity.byteEncrypt(socketRegistration.getSecurityImpl(), ClientFileDomainJumper.class.getName(), byteArray);// AESUtil.simpleEncrypt(ClientFileDomainJumper.class.getName(), byteArray);
                    if (DEBUG) {
                        System.out.println("writing file..." + data2Send.length);
                    }
                    out.writeInt(data2Send.length);
                    out.write(data2Send);
                    if (DEBUG) {
                        System.out.println("done with file");
                    }
                    if (DEBUG) {
                        System.out.println("waiting for response from server... ");
                    }
                    String messageFromServer = in.readUTF();
                    if (DEBUG) {
                        System.out.println("raw message from server " + messageFromServer);
                    }
                    if (messageFromServer.startsWith("encrypted=false")) {
                        messageFromServer = messageFromServer.substring(15);
                    } else {
                        messageFromServer = RegistrySecurity.textDecrypt(socketRegistration.getSecurityImpl(), ClientFileDomainJumper.class.getName(), messageFromServer);// AESUtil.simpleDecrypt(ClientFileDomainJumper.class.getName(), messageFromServer);
                    }
                    if (DEBUG) {
                        System.out.println("message from server " + messageFromServer);
                    }
                    if (messageFromServer.contains("status" + ICommand.EQUAL_SEPERATOR + "ok")) {
                        numberOfFilesSent++;
                        okDomains.add(receiverDomainName);
                    } else {
                        notOkDomains.add(receiverDomainName);
                        System.out.println("error from fileserver " + messageFromServer + " of domain " + receiverDomainName);
                    }
                } catch (Throwable ex) {
                    //TODO find out why it is not catching the exception when its thrown from the server
                    ex.printStackTrace();
                    notOkDomains.add(receiverDomainName);
                } finally {
                    //socketRegistration.close();;
                    //bøjet søms
                    /*
                    if (!okDomains.contains(receiverDomainName) && !notOkDomains.contains(receiverDomainName)) {
                        notOkDomains.add(receiverDomainName);
                    }*/
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        ProcessFile.processFile(outboxIndex, okDomains, notOkDomains, path, file, IFileProces.DEST.outBox);
    }
}
