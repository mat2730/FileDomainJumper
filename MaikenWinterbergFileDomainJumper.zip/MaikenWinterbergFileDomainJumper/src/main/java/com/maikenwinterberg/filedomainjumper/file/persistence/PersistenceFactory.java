/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file.persistence;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;

/**
 *
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PersistenceFactory {

    public static IFileRegistry getFileRegistryDB() throws Exception {
        try {
            String className = ClientFileDomainJumper.getProperty("fileRegistryDBClass");
            if (className != null) {
                IFileRegistry registryDB = (IFileRegistry) Class.forName(className).newInstance();
                return registryDB;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return new JDBCFileRegistry();
    }
}
