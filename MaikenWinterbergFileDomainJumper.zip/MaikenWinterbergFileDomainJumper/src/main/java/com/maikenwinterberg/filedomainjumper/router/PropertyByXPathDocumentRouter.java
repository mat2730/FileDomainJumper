/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class PropertyByXPathDocumentRouter implements IDocumentRouter {

    private static final Map<Integer, Properties> PROPERTIES = new HashMap();

    @Override
    public List<String> getDomainNamesOfRecievers(int index, File file) {
        List<String> domains = new LinkedList();
        int xpathIndex = 1;
        Properties properties = PROPERTIES.get(index);
        if (properties == null) {
            properties = new Properties();
            try {
                String propertyName = ClientFileDomainJumper.getProperty(index + ".propertyFileName");
                properties.load(new FileInputStream(propertyName));
                PROPERTIES.put(index, properties);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        while (true) {
            String xpathConfig = ClientFileDomainJumper.getProperty(index + ".xpath." + xpathIndex++);
            if (xpathConfig == null || xpathConfig.trim().isEmpty()) {
                break;
            }
            System.out.println("looking up xpath " + xpathConfig);
            try {
                FileInputStream fileIS = new FileInputStream(file);
                DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = builderFactory.newDocumentBuilder();
                Document xmlDocument = builder.parse(fileIS);
                XPath xPath = XPathFactory.newInstance().newXPath();
                NodeList nodeList = (NodeList) xPath.compile(xpathConfig).evaluate(xmlDocument, XPathConstants.NODESET);
                System.out.println("nodeList: " + nodeList.getLength());
                String propertyKey = null;
                for (int i = 0; i < nodeList.getLength(); i++) {
                    try {
                        Node n = nodeList.item(i);
                        //domainName = n.getNodeValue();
                        propertyKey = n.getTextContent();
                        if (propertyKey == null || propertyKey.trim().isEmpty()) {
                            propertyKey = n.getNodeValue();
                        }
                        if (propertyKey == null || propertyKey.trim().isEmpty()) {
                            continue;
                        }
                        System.out.println("propertyKey " + propertyKey);
                        String domainName = properties.getProperty(propertyKey);
                        if (domainName != null) {
                            domains.add(domainName);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        System.out.println("found " + propertyKey + " at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                System.out.println("found nothing at xpath: " + xpathConfig + ", exception: " + ex.getMessage());
            }
            if (domains.size() > 0) {
                return domains;
            }
        }
        return domains;
    }
}
