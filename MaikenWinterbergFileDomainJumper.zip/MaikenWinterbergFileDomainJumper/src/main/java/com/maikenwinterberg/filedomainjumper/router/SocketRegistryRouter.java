/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SocketRegistryRouter implements IDocumentRouter {

    private static final Map<Integer, List<ClientRegistry>> REGISTRIES = new HashMap();

    @Override
    public List<String> getDomainNamesOfRecievers(int index, File file) {
        String routerDomainName = ClientFileDomainJumper.getProperty(index + ".routerDomainName");
        String registries = ClientFileDomainJumper.getProperty(index + ".registries");
        String type = ClientFileDomainJumper.getProperty(index + ".type");
        String serviceName = ClientFileDomainJumper.getProperty(index + ".serviceName");
        StringTokenizer tok = new StringTokenizer(registries, ";");
        List<ClientRegistry> list = REGISTRIES.get(index);
        boolean useExternalId = false;
        ClientRegistry.TYPE ctype = ClientRegistry.TYPE.socket;
        try {
            ctype = ClientRegistry.TYPE.valueOf(type);
        } catch (Exception ex) {
            //ignore
        }
        if (routerDomainName.equals("localhost")) {
            useExternalId = true;
        }
        if (list == null) {
            list = new LinkedList();
            while (tok.hasMoreTokens()) {
                try {
                    String registry = tok.nextToken();
                    StringTokenizer tok2 = new StringTokenizer(registry, ":");
                    String ip = tok.nextToken();
                    int portInt = 6666;
                    try {
                        String port = tok.nextToken();
                        portInt = Integer.parseInt(port);
                    } catch (Exception ex) {
                        //ignore
                    }
                    ClientRegistry r = ClientRegistry.getRegistryInstance(routerDomainName, ip, portInt, useExternalId, false);
                    list.add(r);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            REGISTRIES.put(index, list);
        }
        List<String> domainnames = new LinkedList();
        for (Iterator<ClientRegistry> i = list.iterator(); i.hasNext();) {
            try {
                ClientRegistry cr = i.next();
                //in the case of dynamic ip
                cr.updateDefaultDomainNameOnClient();
                //in the case of restart of the registry
                cr.reconnect();
                List<AbstractRegisration> regList = cr.lookup(ctype, routerDomainName, null, serviceName);
                for (Iterator<AbstractRegisration> i2 = regList.iterator(); i2.hasNext();) {
                    AbstractRegisration reg = i2.next();
                    domainnames.add(reg.getDomainName());
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return domainnames;
    }
}
