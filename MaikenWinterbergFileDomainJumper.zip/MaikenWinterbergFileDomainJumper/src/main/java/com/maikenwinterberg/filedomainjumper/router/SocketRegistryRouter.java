/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SocketRegistryRouter implements IDocumentRouter {

    private static final long WAIT_TIME = (1000 * 60 * 10);
    private static final Map<Integer, List<ClientRegistry>> REGISTRIES = new HashMap();
    private static long lastRegistrated = System.currentTimeMillis();

    @Override
    public List<String> getDomainNamesOfRecievers(int index, File file) {
        String defaultDomainNameOfClient = ClientFileDomainJumper.getProperty("defaultDomainNameOfClient");
        String domainNameOfClient = ClientFileDomainJumper.getProperty(index + ".domainNameOfClient");
        String registries = ClientFileDomainJumper.getProperty(index + ".registries");
        String type = ClientFileDomainJumper.getProperty(index + ".type");
        String serviceName = ClientFileDomainJumper.getProperty(index + ".serviceName");
        StringTokenizer tok = new StringTokenizer(registries, ";");
        List<ClientRegistry> list = REGISTRIES.get(index);
        ClientRegistry.TYPE ctype = ClientRegistry.TYPE.socket;
        try {
            ctype = ClientRegistry.TYPE.valueOf(type);
        } catch (Exception ex) {
            //ignore
        }
        boolean useExternalId = false;
        if (domainNameOfClient != null && !domainNameOfClient.isEmpty()) {
            defaultDomainNameOfClient = domainNameOfClient;
        }
        if (defaultDomainNameOfClient.equals("localhost")) {
            useExternalId = true;
        }
        if (list == null) {
            list = new LinkedList();
            while (tok.hasMoreTokens()) {
                try {
                    String registry = tok.nextToken();
                    StringTokenizer tok2 = new StringTokenizer(registry, ":");
                    String ip = tok.nextToken();
                    int portInt = 6666;
                    try {
                        String port = tok.nextToken();
                        portInt = Integer.parseInt(port);
                    } catch (Exception ex) {
                        //ignore
                    }
                    ClientRegistry r = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, ip, portInt, useExternalId, false);
                    list.add(r);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
            REGISTRIES.put(index, list);
        }
        List<String> domainnames = new LinkedList();
        for (Iterator<ClientRegistry> i = list.iterator(); i.hasNext();) {
            try {
                ClientRegistry cr = i.next();
                //in the case of dynamic ip
                if (System.currentTimeMillis() - lastRegistrated > WAIT_TIME) {
                    System.out.println("updating socket registry routers");
                    cr.updateDefaultDomainNameOnClient();
                    //in the case of restart of the registry
                    cr.reconnect();
                    lastRegistrated = System.currentTimeMillis();
                }
                List<AbstractRegisration> regList = cr.lookup(ctype, defaultDomainNameOfClient, null, serviceName);
                for (Iterator<AbstractRegisration> i2 = regList.iterator(); i2.hasNext();) {
                    AbstractRegisration reg = i2.next();
                    domainnames.add(reg.getDomainName());
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return domainnames;
    }
}
