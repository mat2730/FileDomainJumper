/*
 * Martin Alexander Thomsen den 17 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.router;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.socketregistry.api.GetDomainnamesOfRegistry;
import java.io.File;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * 
 * @SEE doc/fetchMedHarris.pdf
 */
public class SocketRegistryRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, File file) {
        String defaultDomainNameOfClient = ClientFileDomainJumper.getProperty("defaultDomainNameOfClient");
        String domainNameOfClient = ClientFileDomainJumper.getProperty(index + ".domainNameOfClient");
        String registries = ClientFileDomainJumper.getProperty(index + ".registries");
        String type = ClientFileDomainJumper.getProperty(index + ".type");
        String serviceName = ClientFileDomainJumper.getProperty(index + ".serviceName");
        if (domainNameOfClient != null && !domainNameOfClient.isEmpty()) {
            defaultDomainNameOfClient = domainNameOfClient;
        }
        String fetchloopAsString = ClientFileDomainJumper.getProperty("fetchloop");
        boolean fetchloop = false;
        try {
            fetchloop = Boolean.parseBoolean(fetchloopAsString);
        } catch (Exception ex) {
            //ignore
        }
        return GetDomainnamesOfRegistry.getDomainNamesOfRecievers(defaultDomainNameOfClient, registries, type, null, serviceName, fetchloop);
    }
}
