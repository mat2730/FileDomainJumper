/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.filedomainjumper.FileDomainJumper;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.inBox;
import com.maikenwinterberg.socketregistry.server.ICommand;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class DomainAndTimeFileProces implements IFileProces {

    //public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmssaz");
    public static final DateTimeFormatter ZDT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    @Override
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File file, DEST destination) throws Exception {
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //init config
                    path = getPath(path);
                    System.out.println("proccessing file in outbox " + file.getCanonicalPath() + " of path " + path);
                    
                    String defaultErrorFolder = ClientFileDomainJumper.getProperty("defaultErrorFolder");
                    String errorFolder = ClientFileDomainJumper.getProperty(configurationIndex + ".errorFolder");
                    if (errorFolder == null || errorFolder.trim().isEmpty()) {
                        errorFolder = defaultErrorFolder;
                    }
                    String defaultSentFolder = ClientFileDomainJumper.getProperty("defaultSentFolder");
                    String sentFolder = ClientFileDomainJumper.getProperty(configurationIndex + ".sendFolder");
                    if (sentFolder == null || sentFolder.trim().isEmpty()) {
                        sentFolder = defaultSentFolder;
                    }
                    String defaultDomainNotFoundFolder = ClientFileDomainJumper.getProperty("defaultDomainNotFoundFolder");
                    String domainNotFoundFolder = ClientFileDomainJumper.getProperty(configurationIndex + ".domainNotFoundFolder");
                    if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
                        domainNotFoundFolder = defaultDomainNotFoundFolder;
                    }
                    if (domainNotFoundFolder == null || domainNotFoundFolder.trim().isEmpty()) {
                        domainNotFoundFolder = errorFolder;
                    }
                    //if not domains found
                    if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                        new File(domainNotFoundFolder + path).mkdirs();
                        File newFile = new File(domainNotFoundFolder + path + "/" + file.getName());
                        //TODO only rename first call then copy
                        file.renameTo(newFile);
                        System.out.println("Domain Error: File moved to " + newFile.getAbsolutePath());
                        return null;
                    }
                    //for each domains not ok
                    File firstFile = null;
                    if (notOkDomains != null) {
                        for (String domainName : notOkDomains) {
                            new File(errorFolder + "/" + domainName + path).mkdirs();
                            if (firstFile == null) {
                                firstFile = new File(errorFolder + "/" + domainName + path + "/" + file.getName());
                                //TODO only rename first call then copy
                                file.renameTo(firstFile);
                                System.out.println("File Error: File moved to " + firstFile.getAbsolutePath());
                            } else {
                                File newFile = new File(errorFolder + "/" + domainName + path + "/" + file.getName());
                                boolean ok = copyFile(firstFile, newFile);
                                System.out.println("File Error: File copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                            }
                        }
                    }
                    //ok domains
                    if (okDomains != null) {
                        for (String domainName : okDomains) {
                            new File(sentFolder + "/" + domainName + path).mkdirs();
                            if (firstFile == null) {
                                firstFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                                file.renameTo(firstFile);
                                System.out.println("File sent: file moved to " + firstFile.getAbsolutePath());
                            } else {
                                File newFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                                boolean ok = copyFile(firstFile, newFile);
                                System.out.println("File sent: file copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                            }
                        }
                    }
                    return null;
                }
                case inBox -> {
                    path = getPath(path);
                    System.out.println("proccessing file in inbox " + file.getCanonicalPath() + " of path " + path);
                    
                    String domainName = null;
                    try {
                        domainName = okDomains.get(0);
                    } catch (Exception ex) {
                    }
                    if (domainName == null) {
                        domainName = "unknown_sender";
                    }
                    String defaulInboxFolder = FileDomainJumper.getProperty("defaultInboxFolder");
                    String inboxFolder = FileDomainJumper.getProperty(configurationIndex + ".registration.inboxFolder");
                    if (inboxFolder == null || inboxFolder.trim().isEmpty()) {
                        inboxFolder = defaulInboxFolder;
                    }
                    File inboxFolderFile = new File(inboxFolder + "/" + domainName + path);
                    inboxFolderFile.mkdirs();
                    File newFile = new File(inboxFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                    System.out.println("File received: File will be created in folder " + newFile.getAbsolutePath());
                    return newFile;
                }
                case doneWithBox -> {
                    String outboxFolder = ClientFileDomainJumper.getProperty(configurationIndex + ".outbox");
                    System.out.println("deleting outbox " + outboxFolder + " of index " + configurationIndex);
                    File directory = new File(outboxFolder);
                    for (File childFile : directory.listFiles()) {
                        if (childFile.isDirectory()) {
                            deleteFileOfDir(childFile);
                        }
                    }
                    return null;
                }
                default -> {
                }
            }

        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    private void deleteFileOfDir(File directory) {
        for (File childFile : directory.listFiles()) {
            if (childFile.isDirectory()) {
                deleteFileOfDir(childFile);
            }
        }
        System.out.println("deleting folder " + directory.getAbsolutePath() + ", status " + directory.delete());
    }

    private String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        path = path.replaceAll(ICommand.SPACE_SEPERATOR, " ");
        return path;
    }

    private boolean copyFile(File fromFile, File toFile) {
        try {
            InputStream in = new BufferedInputStream(
                    new FileInputStream(fromFile));
            OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(toFile));

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    protected String getDateString() {
        return ZDT_FORMATTER.format(ZonedDateTime.now());
    }

    @Override
    public boolean doProcessFile(int configurationIndex, String reeiverDomainName, File file) throws Exception {
        return true;
    }
}
