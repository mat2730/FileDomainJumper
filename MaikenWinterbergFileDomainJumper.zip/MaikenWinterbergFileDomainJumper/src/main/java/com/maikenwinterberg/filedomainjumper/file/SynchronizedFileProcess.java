/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import java.io.File;
import java.util.List;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.inBox;
import com.maikenwinterberg.filedomainjumper.file.persistence.PersistenceFactory;
import java.util.Iterator;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class SynchronizedFileProcess implements IFileProces {

    @Override
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File file, IFileProces.DEST destination) throws Exception {
        path = FileProcessUtil.getPath(path);
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //if no domains found
                    if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                        FileProcessUtil.processDomainNotFound(configurationIndex, path, file);
                        return null;
                    }
                    //for all okDomains
                    //register file
                    for (Iterator<String> i = okDomains.iterator(); i.hasNext();) {
                        PersistenceFactory.getFileRegistryDB().registerFile(configurationIndex, i.next(), file);
                    }
                    return null;
                }
                case inBox -> {
                    return FileProcessUtil.processInbox(path, configurationIndex, okDomains, file, "");
                }
                default -> {
                }
            }

        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    @Override
    public boolean doProcessFile(int configurationIndex, String receiverDomainName, File file) throws Exception {
        return !PersistenceFactory.getFileRegistryDB().isRegistrated(configurationIndex, receiverDomainName, file);
    }
}
