/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import java.io.File;
import java.util.List;
import com.maikenwinterberg.filedomainjumper.FileDomainJumper;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.doneWithBox;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.inBox;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.outBox;
import com.maikenwinterberg.filedomainjumper.file.persistence.PersistenceFactory;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class StayPutUntilSentFileProcess implements IFileProces {

    @Override
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File file, DEST destination) throws Exception {
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //init config
                    path = getPath(path);
                    System.out.println("proccessing file in outbox " + file.getCanonicalPath() + " of path " + path);

                    String defaultSentFolder = ClientFileDomainJumper.getProperty("defaultSentFolder");
                    String sentFolder = ClientFileDomainJumper.getProperty(configurationIndex + ".sendFolder");
                    if (sentFolder == null || sentFolder.trim().isEmpty()) {
                        sentFolder = defaultSentFolder;
                    }

                    //for each domains not ok
                    File firstFile = null;
                    //ok domains
                    if (okDomains != null) {
                        for (String domainName : okDomains) {
                            new File(sentFolder + "/" + domainName + path).mkdirs();
                            if (firstFile == null) {
                                firstFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                                file.renameTo(firstFile);
                                System.out.println("File sent: file moved to " + firstFile.getAbsolutePath());
                            } else {
                                File newFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                                boolean ok = copyFile(firstFile, newFile);
                                System.out.println("File sent: file copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                            }
                        }
                    }
                    return null;
                }
                case inBox -> {
                    path = getPath(path);
                    System.out.println("proccessing file in inbox " + file.getCanonicalPath() + " of path " + path);

                    String domainName = null;
                    try {
                        domainName = okDomains.get(0);
                    } catch (Exception ex) {
                    }
                    if (domainName == null) {
                        domainName = "unknown_sender";
                    }
                    String defaulInboxFolder = FileDomainJumper.getProperty("defaultInboxFolder");
                    String inboxFolder = FileDomainJumper.getProperty(configurationIndex + ".registration.inboxFolder");
                    if (inboxFolder == null || inboxFolder.trim().isEmpty()) {
                        inboxFolder = defaulInboxFolder;
                    }
                    File inboxFolderFile = new File(inboxFolder + "/" + domainName + path);
                    inboxFolderFile.mkdirs();
                    File newFile = new File(inboxFolder + "/" + domainName + path + "/" + getDateString() + "_" + file.getName());
                    System.out.println("File received: File will be created in folder " + newFile.getAbsolutePath());
                    return newFile;
                }
            }

        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    private boolean copyFile(File fromFile, File toFile) {
        try {
            InputStream in = new BufferedInputStream(
                    new FileInputStream(fromFile));
            OutputStream out = new BufferedOutputStream(
                    new FileOutputStream(toFile));

            byte[] buffer = new byte[1024];
            int lengthRead;
            while ((lengthRead = in.read(buffer)) > 0) {
                out.write(buffer, 0, lengthRead);
                out.flush();
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    //TODO share code with DomainAndTimeFileProess
    private String getPath(String path) {
        if (path == null || path.trim().equalsIgnoreCase(".") || path.trim().equals("")) {
            path = "";
        } else {
            if (!path.startsWith("/")) {
                path = "/" + path;
            }
            if (path.endsWith("/")) {
                path = path.substring(0, path.length() - 1);
            }
        }
        int i = path.indexOf("/");
        if (i != -1) {
            //remove first path
            path = path.substring(i);
        }
        path = path.replaceAll(" ", "_");
        return path;
    }

    protected String getDateString() {
        return "";
    }

    @Override
    public boolean doProcessFile(int configurationIndex, String receiverDomainName, File file) throws Exception {
        return !PersistenceFactory.getFileRegistryDB().isRegistrated(configurationIndex, receiverDomainName, file);
    }
}
