/*
 * Martin Alexander Thomsen den 21 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import java.io.File;
import java.util.List;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.doneWithBox;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.inBox;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.outBox;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/stayPutUntilSent.pdf
 */
public class StayPutUntilSentFileProcess implements IFileProces {

    private static final Map<String, Long> WAIT_FILE = new HashMap();
    private static final long WAIT_TIME = (1000 * 60 * 60 * 3); //default 3 timer
    private static final boolean DEBUG = false;

    @Override
    public File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File file, DEST destination) throws Exception {
        path = FileProcessUtil.getPath(path);
        if (null != destination) {
            switch (destination) {
                case outBox -> {
                    //init config
                    if (DEBUG) {
                        System.out.println("StayPutUntilSentFileProcess.proccessing file in outbox " + file.getCanonicalPath() + " of path " + path);
                    }

                    String sentFolder = FileProcessUtil.getSentBox(configurationIndex).getAbsolutePath();
                    String domainNotFoundFolder = FileProcessUtil.getDomainNotFoundBox(configurationIndex).getAbsolutePath();
                    String outboxFolder = FileProcessUtil.getOutbox(configurationIndex).getAbsolutePath();
                    if (DEBUG) {
                        System.out.println("StayPutUntilSentFileProcess.outbox: " + outboxFolder);
                    }
                    //if no domains found
                    if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                        FileProcessUtil.processDomainNotFound(configurationIndex, path, file);
                        return null;
                    }
                    //if not domains found
                    if ((okDomains == null || okDomains.isEmpty()) && (notOkDomains == null || notOkDomains.isEmpty())) {
                        WAIT_FILE.remove(file.getAbsolutePath());
                        path = FileProcessUtil.removeFirstPartIfEqual("domainNotFound", path);
                        new File(outboxFolder + "/domainNotFound" + path).mkdirs();
                        File newFile = new File(outboxFolder + "/domainNotFound" + path + "/" + FileProcessUtil.addIndex(file.getName()));
                        //TODO only rename first call then copy
                        file.renameTo(newFile);
                        if (DEBUG) {
                            System.out.println("StayPutUntilSentFileProcess.Domain Error: File moved to " + newFile.getAbsolutePath());
                        }
                        WAIT_FILE.put(newFile.getAbsolutePath(), System.currentTimeMillis());
                        return null;
                    }
                    //for each domains not ok
                    File firstFile = null;
                    if (notOkDomains != null) {
                        for (String domainName : notOkDomains) {
                            path = FileProcessUtil.removeFirstPartIfEqual(domainName, path);
                            new File(outboxFolder + "/" + domainName + path).mkdirs();
                            if (firstFile == null) {
                                WAIT_FILE.remove(file.getAbsolutePath());
                                firstFile = new File(outboxFolder + "/" + domainName + path + "/" + FileProcessUtil.addIndex(file.getName()));
                                //TODO only rename first call then copy
                                file.renameTo(firstFile);
                                if (DEBUG) {
                                    System.out.println("StayPutUntilSentFileProcess.File Error: File moved to " + firstFile.getAbsolutePath());
                                }
                                WAIT_FILE.put(firstFile.getAbsolutePath(), System.currentTimeMillis());
                            } else {
                                WAIT_FILE.remove(file.getAbsolutePath());
                                File newFile = new File(outboxFolder + "/" + domainName + path + "/" + FileProcessUtil.addIndex(file.getName()));
                                boolean ok = FileProcessUtil.copyFile(firstFile, newFile);
                                if (DEBUG) {
                                    System.out.println("StayPutUntilSentFileProcess.File Error: File copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                                }
                                WAIT_FILE.put(newFile.getAbsolutePath(), System.currentTimeMillis());
                            }
                        }
                    }
                    //ok domains
                    if (okDomains != null) {
                        WAIT_FILE.remove(file.getAbsolutePath());
                        firstFile = processSent(okDomains, path, sentFolder, firstFile, file);
                    }
                    return null;
                }
                case inBox -> {
                    return FileProcessUtil.processInbox(path, configurationIndex, okDomains, file, getDateString());
                }
                case doneWithBox -> {
                    String outboxFolder = FileProcessUtil.getOutbox(configurationIndex).getAbsolutePath();
                    System.out.println("deleting outbox " + outboxFolder + " of index " + configurationIndex);
                    File directory = new File(outboxFolder);
                    for (File childFile : directory.listFiles()) {
                        if (childFile.isDirectory()) {
                            //dont delete first level
                            FileProcessUtil.deleteEmptyDir(childFile.getName(), childFile);
                        }
                    }
                    return null;
                }
                default -> {
                }
            }
        }
        throw new IllegalStateException("folder of file is missing in config");
    }

    protected File processSent(List<String> okDomains, String path, String sentFolder, File firstFile, File file) {
        for (String domainName : okDomains) {
            path = FileProcessUtil.removeFirstPartIfEqual(domainName, path);
            new File(sentFolder + "/" + domainName + path).mkdirs();
            if (firstFile == null) {
                firstFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + FileProcessUtil.removeIndex(file.getName()));
                file.renameTo(firstFile);
                if (DEBUG) {
                    System.out.println("StayPutUntilSentFileProcess.File sent: file moved to " + firstFile.getAbsolutePath());
                }
            } else {
                File newFile = new File(sentFolder + "/" + domainName + path + "/" + getDateString() + "_" + FileProcessUtil.removeIndex(file.getName()));
                boolean ok = FileProcessUtil.copyFile(firstFile, newFile);
                if (DEBUG) {
                    System.out.println("StayPutUntilSentFileProcess.File sent: file copied to " + newFile.getAbsolutePath() + ", status=" + ok);
                }
            }
        }
        return firstFile;
    }

    protected String getDateString() {
        return "";
    }

    @Override
    public boolean doProcessFile(int configurationIndex, String receiverDomainName, File file) throws Exception {
        Long time = WAIT_FILE.get(file.getAbsolutePath());
        if (time != null) {
            if (System.currentTimeMillis() - time > WAIT_TIME) {
                WAIT_FILE.remove(file.getAbsolutePath());
                return true;
            }
            return false;
        }
        return true;
    }
}
