/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import com.maikenwinterberg.filedomainjumper.file.IFileProces;
import com.maikenwinterberg.filedomainjumper.file.ProcessFile;
import com.maikenwinterberg.socketregistry.api.AbstractRegisration;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ClientFileDomainJumper {

    private static final Properties PROPERTIES = new Properties();
    private static final List<ClientRegistry> DEFAULT_REGISTRIES = new LinkedList();
    private static final Map<String, ClientRegistry> CLIENT_REGISTRIES = new HashMap();
    private static final boolean DEBUG = false;

    public static String getProperty(String name) {
        return PROPERTIES.getProperty(name);
    }

    public static void main(String arg[]) throws Exception {
        System.out.println("Starting the file sender");
        while (true) {
            PROPERTIES.clear();
            PROPERTIES.load(new FileInputStream("conf/clientFileDomainJumper.properties"));
            String doDomainNameCheckOfClient = PROPERTIES.getProperty("doDomainNameCheckOfClient", "true");
            boolean doDomainCheck = true;
            try {
                doDomainCheck = Boolean.valueOf(doDomainNameCheckOfClient);
            } catch (Exception ex) {
            }
            String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
            String defaultRegistries = PROPERTIES.getProperty("defaultRegistries");
            String defaultServiceName = PROPERTIES.getProperty("defaultServiceName");
            //for all registries
            if (defaultRegistries != null && !defaultRegistries.trim().isEmpty()) {
                StringTokenizer tok = new StringTokenizer(defaultRegistries, ";");
                while (tok.hasMoreTokens()) {
                    try {
                        String registryConfig = tok.nextToken().toLowerCase();
                        if (CLIENT_REGISTRIES.get(registryConfig) != null) {
                            //allready configured
                            continue;
                        }
                        StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                        String url = tok2.nextToken();
                        String port = tok2.nextToken();
                        System.out.println("Init default registry: " + registryConfig + ", url= " + url + ", port=" + port);
                        ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), doDomainCheck, false);
                        CLIENT_REGISTRIES.put(registryConfig.toLowerCase(), clientRegistry);
                        DEFAULT_REGISTRIES.add(clientRegistry);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            }
            int index = 1;
            //for all registrations
            startOfLoop:
            while (true) {
                try {
                    //init properties
                    String outbox = PROPERTIES.getProperty(index + ".outbox");
                    File outboxFile = null;
                    if (outbox != null) {
                        outboxFile = new File(outbox);
                        outboxFile.mkdirs();
                        if (!outboxFile.exists() || !outboxFile.isDirectory()) {
                            System.out.println("Invalid outbox " + outbox + " of index " + index);
                            break;
                        }
                    } else {
                        //end of config
                        break;
                    }
                    String serviceName = PROPERTIES.getProperty(index + ".serviceName");
                    if (serviceName == null || serviceName.trim().isEmpty()) {
                        serviceName = defaultServiceName;
                    }
                    List<ClientRegistry> lookupRegistries = new LinkedList();
                    String registries = PROPERTIES.getProperty(index + ".registries");
                    if (registries != null && !registries.trim().isEmpty()) {
                        //inti registries on folder level
                        StringTokenizer tok2 = new StringTokenizer(registries, ";");
                        while (tok2.hasMoreTokens()) {
                            String registryAsKey = null;
                            try {
                                registryAsKey = tok2.nextToken().toLowerCase();
                                if (registryAsKey != null && !registryAsKey.trim().isEmpty()) {
                                    ClientRegistry r = CLIENT_REGISTRIES.get(registryAsKey);
                                    if (r == null) {
                                        if (DEBUG) {
                                            System.out.println("init registry " + registryAsKey);
                                        }
                                        StringTokenizer tok3 = new StringTokenizer(registryAsKey, ":");
                                        String url = tok3.nextToken();
                                        String port = tok3.nextToken();
                                        r = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), doDomainCheck, false);
                                        CLIENT_REGISTRIES.put(registryAsKey, r);
                                    }
                                    lookupRegistries.add(r);
                                }
                            } catch (Exception ex) {
                                System.out.println("cannot connect to " + registryAsKey);
                                ex.printStackTrace();
                            }
                        }
                    }
                    if (lookupRegistries.isEmpty()) {
                        lookupRegistries = DEFAULT_REGISTRIES;
                    }
                    // JumperTask initTask = new JumperTask(index, "", null, lookupRegistries, serviceName);
                    Map<String, SocketRegistration> registriesByDomain = new HashMap();
                    try {
                        for (File childFile : outboxFile.listFiles()) {
                            if (childFile.isDirectory()) {
                                //traverseTree(doubleCheck, initTask, "/" + outboxFile.getName(), childFile);
                                traverseTree(registriesByDomain, new JumperTask(index, "", childFile, lookupRegistries, serviceName));
                            } else if (childFile.isFile()) {
                                QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(index, "", childFile, lookupRegistries, serviceName));
                            }
                        }
                    } finally {
                        if (!registriesByDomain.isEmpty()) {
                            //delete if processed something
                            System.out.println("doneWithBox");
                            ProcessFile.processFile(index, null, null, null, null, IFileProces.DEST.doneWithBox);
                        }
                    }
                    //close socket connections
                    for (Iterator<SocketRegistration> i = registriesByDomain.values().iterator(); i.hasNext();) {
                        SocketRegistration sr = i.next();
                        System.out.println("closing socket for " + sr.getIp()+":"+sr.getPort());
                        sr.close();
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                index++;
            }
            try {
                //TODO configurable
                Thread.sleep(10000);
            } catch (Exception ex) {
            }
        }
    }

    private static void traverseTree(Map registriesByDomain, JumperTask initTask) throws Exception {
        File[] files = initTask.getFile().listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getLookupRegistries(), initTask.getServiceName()));
                } else if (childFile.exists() && childFile.isFile()) {
                    //TODO add task to a queue and have another thread read from the queue
                    QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getLookupRegistries(), initTask.getServiceName()));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
