/*
 * Martin Alexander Thomsen den 8 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import com.maikenwinterberg.filedomainjumper.file.IFileProces;
import com.maikenwinterberg.filedomainjumper.file.ProcessFile;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.SocketRegistration;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ClientFileDomainJumper {

    private static final Properties PROPERTIES = new Properties();
    private static final List<ClientRegistry> DEFAULT_REGISTRIES = new LinkedList();
    private static final Map<String, ClientRegistry> CLIENT_REGISTRIES = new HashMap();
    private static final boolean DEBUG = false;

    public static String getProperty(String name) {
        return PROPERTIES.getProperty(name);
    }

    public static void main(String arg[]) throws Exception {
        System.out.println("Starting the file sender");
        PROPERTIES.clear();
        PROPERTIES.load(new FileInputStream("conf/clientFileDomainJumper.properties"));
        String useExternalIDString = PROPERTIES.getProperty("useExternalID", "true");
        boolean useExternalID = true;
        try {
            useExternalID = Boolean.parseBoolean(useExternalIDString);
        } catch (Exception ex) {
        }
        String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
        String defaultRegistries = PROPERTIES.getProperty("defaultRegistries");
        String defaultServiceName = PROPERTIES.getProperty("defaultServiceName");
        //for all registries
        if (defaultRegistries != null && !defaultRegistries.trim().isEmpty()) {
            StringTokenizer tok = new StringTokenizer(defaultRegistries, ";");
            while (tok.hasMoreTokens()) {
                try {
                    String registryConfig = tok.nextToken().toLowerCase();
                    if (CLIENT_REGISTRIES.get(registryConfig) != null) {
                        //allready configured
                        continue;
                    }
                    StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                    String url = tok2.nextToken();
                    String port = "6666";
                    try {
                        if (tok2.hasMoreTokens()) {
                            port = tok2.nextToken();
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                    ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), useExternalID, false);
                    System.out.println("Init default registry: " + clientRegistry + ", url= " + url + ", port=" + port);
                    CLIENT_REGISTRIES.put(registryConfig.toLowerCase(), clientRegistry);
                    DEFAULT_REGISTRIES.add(clientRegistry);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
        long lastRegistrated = System.currentTimeMillis();
        long WAIT_TIME = (1000 * 60 * 10); //each 10 minute do reconnect of lookup registries
        java.util.Random rand = new java.util.Random();
        Map<String, SocketRegistration> registriesByDomain = new HashMap();
        System.out.println("starting traversing the outboxes...");
        out:
        while (true) {
            int index = 1;
            //for all registrations
            startOfLoop:
            while (true) {
                try {
                    //init properties
                    String outbox = PROPERTIES.getProperty(index + ".outbox");
                    File outboxFile = null;
                    if (outbox != null) {
                        outboxFile = new File(outbox);
                        outboxFile.mkdirs();
                        if (!outboxFile.exists() || !outboxFile.isDirectory()) {
                            System.out.println("Invalid outbox " + outbox + " of index " + index);
                            break;
                        }
                    } else {
                        //end of config
                        break;
                    }
                    String serviceName = PROPERTIES.getProperty(index + ".serviceName");
                    if (serviceName == null || serviceName.trim().isEmpty()) {
                        serviceName = defaultServiceName;
                    }
                    List<ClientRegistry> lookupRegistries = new LinkedList();
                    String registries = PROPERTIES.getProperty(index + ".registries");
                    if (registries != null && !registries.trim().isEmpty()) {
                        //inti registries on folder level
                        StringTokenizer tok2 = new StringTokenizer(registries, ";");
                        while (tok2.hasMoreTokens()) {
                            String registryAsKey = null;
                            try {
                                registryAsKey = tok2.nextToken().toLowerCase();
                                if (registryAsKey != null && !registryAsKey.trim().isEmpty()) {
                                    ClientRegistry r = CLIENT_REGISTRIES.get(registryAsKey);
                                    if (r == null) {
                                        if (DEBUG) {
                                            System.out.println("init registry " + registryAsKey);
                                        }
                                        StringTokenizer tok3 = new StringTokenizer(registryAsKey, ":");
                                        String url = tok3.nextToken();
                                        String port = "6666";
                                        try {
                                            if (tok3.hasMoreTokens()) {
                                                port = tok3.nextToken();
                                            }
                                        } catch (Exception ex) {
                                            ex.printStackTrace();
                                        }
                                        r = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), useExternalID, false);
                                        System.out.println("Init registry: " + r + ", url= " + url + ", port=" + port);
                                        CLIENT_REGISTRIES.put(registryAsKey, r);
                                    }
                                    lookupRegistries.add(r);
                                }
                            } catch (Exception ex) {
                                System.out.println("cannot connect to " + registryAsKey);
                                ex.printStackTrace();
                            }
                        }
                    }
                    if (lookupRegistries.isEmpty()) {
                        for (Iterator<ClientRegistry> i = DEFAULT_REGISTRIES.iterator(); i.hasNext();) {
                            lookupRegistries.add(i.next());
                        }
                    }
                    //randommize lookupRegistries
                    List l = new LinkedList();
                    //allways localhost first
                    for (int i = 0; i < lookupRegistries.size(); i++) {
                        ClientRegistry cr = lookupRegistries.get(i);
                        if (cr.isLocalhost()) {
                            l.add(lookupRegistries.get(i));
                        }
                    }
                    if (rand.nextBoolean()) {
                        //reversed
                        for (int i = lookupRegistries.size() - 1; i >= 0; i--) {
                            ClientRegistry cr = lookupRegistries.get(i);
                            if (cr.isLocalhost()) {
                                continue;
                            }
                            l.add(lookupRegistries.get(i));
                        }
                    } else {
                        for (int i = 0; i < lookupRegistries.size(); i++) {
                            ClientRegistry cr = lookupRegistries.get(i);
                            if (cr.isLocalhost()) {
                                continue;
                            }
                            l.add(lookupRegistries.get(i));
                        }
                    }
                    lookupRegistries = l;
                    // JumperTask initTask = new JumperTask(index, "", null, lookupRegistries, serviceName);
                    File files[] = outboxFile.listFiles();
                    if (files.length > 0) {
                        //reconnect lookup registries
                        //TODO implement this as a keep alive thread
                        if (System.currentTimeMillis() - lastRegistrated > WAIT_TIME) {
                            System.out.println("connecting to lookupRegistries");
                            for (Iterator<ClientRegistry> i = lookupRegistries.iterator(); i.hasNext();) {
                                //reconnect incase of restart
                                ClientRegistry r = i.next();
                                try {
                                    //in case of dynamic ip
                                    r.updateDefaultDomainNameOnClient();
                                    //in case of registry service down
                                    r.reconnect();
                                    lastRegistrated = System.currentTimeMillis();
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                    lookupRegistries.remove(r);
                                }
                            }
                            registriesByDomain = new HashMap();
                        }
                        if (lookupRegistries.isEmpty()) {
                            System.out.println("No valid lookup registries found, please change the configuraiton");
                            break out;
                        }
                        try {
                            for (File childFile : files) {
                                if (childFile.isDirectory()) {
                                    //traverseTree(doubleCheck, initTask, "/" + outboxFile.getName(), childFile);
                                    traverseTree(registriesByDomain, new JumperTask(index, "", childFile, defaultDomainNameOfClient, lookupRegistries, serviceName));
                                } else if (childFile.isFile()) {
                                    QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(index, "", childFile, defaultDomainNameOfClient, lookupRegistries, serviceName));
                                }
                            }
                        } finally {
                            if (!registriesByDomain.isEmpty()) {
                                //delete if processed something
                                if (DEBUG) {
                                    System.out.println("doneWithBox");
                                }
                                ProcessFile.processFile(index, null, null, null, null, IFileProces.DEST.doneWithBox);
                            }
                        }
                        //close socket connections
                        for (Iterator<SocketRegistration> i = registriesByDomain.values().iterator(); i.hasNext();) {
                            SocketRegistration sr = i.next();
                            System.out.println("closing socket for " + sr.getIp() + ":" + sr.getPort());
                            sr.close();
                        }
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                index++;
            }
            try {
                //TODO configurable
                Thread.sleep(10000);
            } catch (Exception ex) {
            }
        }

        System.out.println(
                "The MaikenWinterbergFileSender stoppend.");
    }

    private static void traverseTree(Map registriesByDomain, JumperTask initTask) throws Exception {
        File[] files = initTask.getFile().listFiles();
        for (File childFile : files) {
            try {
                if (childFile.isDirectory()) {
                    traverseTree(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getDomainNameOfClient(), initTask.getLookupRegistries(), initTask.getServiceName()));
                } else if (childFile.exists() && childFile.isFile()) {
                    //TODO add task to a queue and have another thread read from the queue
                    QueueHandler.handleTaskInQueue(registriesByDomain, new JumperTask(initTask.getOutboxIndex(), initTask.getPath() + "/" + initTask.getFile().getName(), childFile, initTask.getDomainNameOfClient(), initTask.getLookupRegistries(), initTask.getServiceName()));
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
