/*
 * Martin Alexander Thomsen den 24 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import java.io.File;
import java.util.List;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 * @see doc/stayPutUntilSent.pdf
 */
public class StayPutUntilSentNoSentFileProcess extends StayPutUntilSentFileProcess {

    @Override
    protected File processSent(List<String> okDomains, String path, String sentFolder, File firstFile, File file) {
        if (okDomains != null && okDomains.size() > 0 && file != null && file.exists()) {
            file.delete();
        }
        return firstFile;
    }
}
