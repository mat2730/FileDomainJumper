/*
 * Martin Alexander Thomsen den 6 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper;

import java.io.FileInputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import com.maikenwinterberg.socketregistry.api.ClientRegistry;
import com.maikenwinterberg.socketregistry.api.ClientRegistryAddress;
import com.maikenwinterberg.socketregistry.security.IRegistrySecurity;
import com.maikenwinterberg.socketregistry.security.RegistrySecurity;
import com.maikenwinterberg.socketregistry.security.StaticRegistrySecurity;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class FileDomainJumper {

    private static final Properties PROPERTIES = new Properties();
    private static final List<ClientRegistry> DEFAULT_REGISTRIES = new LinkedList();
    private static final Map<String, ClientRegistry> CLIENT_REGISTRIES = new HashMap();
    public static final boolean DEBUG = false;

    private static ServerSocket SERVER_SOCKET;

    public static String getProperty(String name) {
        return PROPERTIES.getProperty(name);
    }

    public static String getSecurityImpl() {
        try {
            String c = getProperty("securityImpl");
            IRegistrySecurity rs = (IRegistrySecurity) Class.forName(c).newInstance();
            return rs.getClass().getName();
        } catch (Exception ex) {
            //ignore
        }
        return StaticRegistrySecurity.class.getName();
    }

    private int register() throws Exception {
        PROPERTIES.clear();
        PROPERTIES.load(new FileInputStream("conf/fileDomainJumper.properties"));
        String defaultDomainNameOfClient = PROPERTIES.getProperty("defaultDomainNameOfClient");
        String defaultRegistries = PROPERTIES.getProperty("defaultRegistries");
        String useExternalIDString = PROPERTIES.getProperty("useExternalID", "true");
        boolean useExternalID = true;
        try {
            useExternalID = Boolean.parseBoolean(useExternalIDString);
        } catch (Exception ex) {
        }

        //for all registries
        StringTokenizer tok = new StringTokenizer(defaultRegistries, ";");
        while (tok.hasMoreTokens()) {
            try {
                String registryConfig = tok.nextToken();
                if (FileDomainJumper.DEBUG) {
                    System.out.println("Init default registry: " + registryConfig);
                }
                StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                String url = tok2.nextToken();
                String port = tok2.nextToken();
                ClientRegistry clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, url, Integer.parseInt(port), useExternalID, false);
                CLIENT_REGISTRIES.put(registryConfig, clientRegistry);
                DEFAULT_REGISTRIES.add(clientRegistry);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        if (FileDomainJumper.DEBUG) {
            System.out.println("registries: " + CLIENT_REGISTRIES);
        }
        //for all registrations -> register
        int count = 0;
        int index = 1;
        //for all registrations
        while (true) {
            try {
                if (FileDomainJumper.DEBUG) {
                    System.out.println("Init registration index " + index);
                }
                String type = PROPERTIES.getProperty(index + ".registration.type");
                if (type == null || type.trim().isEmpty()) {
                    break;
                }
                String domainName = PROPERTIES.getProperty(index + ".registration.domainName");
                String serviceName = PROPERTIES.getProperty(index + ".registration.serviceName");
                String ip = PROPERTIES.getProperty(index + ".registration.ip");
                String port = PROPERTIES.getProperty("port");
                String secure = PROPERTIES.getProperty(index + ".registration.secure");
                String id = PROPERTIES.getProperty(index + ".registration.id");
                String registries = PROPERTIES.getProperty(index + ".registration.registries");
                if (Integer.parseInt(id) != index) {
                    throw new IllegalStateException("Invalid id. The ID must match the index");
                }
                if (ip == null || ip.trim().isEmpty()) {
                    ip = defaultDomainNameOfClient;
                }
                if (domainName == null || domainName.trim().isEmpty()) {
                    domainName = defaultDomainNameOfClient;
                }
                String publicKeyAsBase64 = null;
                if (secure != null && secure.equalsIgnoreCase("false")) {
                    //do nothing
                } else {
                    publicKeyAsBase64 = RegistrySecurity.toBase64(getSecurityImpl(), RegistrySecurity.getKeyPair(getSecurityImpl(), this).getPublic()); //RSAUtil.toBase64(RSAUtil.getRSAKeyPar(this).getPublic());
                }
                if (FileDomainJumper.DEBUG) {
                    System.out.println("propertiy registration " + id + " " + ip + ":" + port + "/" + serviceName + "." + domainName);
                }
                if (registries == null || registries.isEmpty()) {
                    //for all default Registries
                    for (Iterator<ClientRegistry> i = DEFAULT_REGISTRIES.iterator(); i.hasNext();) {
                        ClientRegistry clientRegistry = i.next();
                        ClientRegistryAddress registryAddress = clientRegistry.registerSocket(domainName, serviceName, id, ip, port, publicKeyAsBase64, getSecurityImpl());
                        System.out.println("Registration " + index + " at: " + registryAddress + " is completed of registry: " + clientRegistry);
                    }
                } else {
                    //for all registries
                    tok = new StringTokenizer(registries, ";");
                    while (tok.hasMoreTokens()) {
                        try {
                            String registryConfig = tok.nextToken();
                            ClientRegistry clientRegistry = CLIENT_REGISTRIES.get(registryConfig);
                            if (clientRegistry == null) {
                                StringTokenizer tok2 = new StringTokenizer(registryConfig, ":");
                                if (FileDomainJumper.DEBUG) {
                                    System.out.println("Init registry at: " + tok2);
                                }
                                String registryurl = tok2.nextToken();
                                String registryport = tok2.nextToken();
                                clientRegistry = ClientRegistry.getRegistryInstance(defaultDomainNameOfClient, registryurl, Integer.parseInt(registryport), useExternalID, false);
                                CLIENT_REGISTRIES.put(registryConfig, clientRegistry);
                                ClientRegistryAddress registryAddress = clientRegistry.registerSocket(domainName, serviceName, id, ip, port, publicKeyAsBase64, getSecurityImpl());
                                System.out.println("Registration " + index + " at: " + registryAddress + " is completed of registry: " + clientRegistry);
                            }
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }
                count++;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            index++;

            if (count == 0) {
                throw new IllegalStateException("Nothing registrated");
            }
        }
        return count;
    }

    public static void main(String[] args) throws Exception {
        FileDomainJumper jumper = new FileDomainJumper();
        try {
            int numberOfReg = jumper.register();
            System.out.println("Done with " + numberOfReg + " registrations");
        } catch (Exception ex) {
            ex.printStackTrace();
            return;
        }
        int port = Integer.parseInt(PROPERTIES.getProperty("port"));
        String bindAddr = PROPERTIES.getProperty("bindaddr");
        InetAddress addr = InetAddress.getByName(bindAddr);
        int backlog = 0;
        SERVER_SOCKET = new ServerSocket(port, backlog, addr);

        System.out.println("Listening on port " + addr + ":" + port + "...");
        while (true) {
            Socket clientSocket = SERVER_SOCKET.accept();
            Thread thread = new FileJumperServerSocketThread(clientSocket, jumper);
            thread.start();
        }
    }
}
