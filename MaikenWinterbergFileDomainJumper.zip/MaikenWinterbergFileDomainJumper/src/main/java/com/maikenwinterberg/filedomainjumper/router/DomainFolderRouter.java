/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maikenwinterberg.filedomainjumper.router;

import java.io.File;
import java.net.InetAddress;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author martin
 */
public class DomainFolderRouter implements IDocumentRouter {

    @Override
    public List<String> getDomainNamesOfRecievers(int index, File file) {
        List<String> l = new LinkedList();
        addParent(l, file);
        return l;
    }

    private void addParent(List<String> domains, File f) {
        File parentFile = f.getParentFile();
        if (parentFile == null) {
            return;
        }
        String domainName = parentFile.getName();
        InetAddress inetAddress = null;
        try {
            inetAddress = InetAddress.getByName(domainName);
            if (inetAddress != null) {
                String hostAddress = inetAddress.getHostAddress();
                if (hostAddress != null) {
                    domains.add(domainName);
                }
                System.out.println("inetAddress " + inetAddress + " of domain " + domainName);
            }
        } catch (Exception ex) {
            //ignore
        }
        addParent(domains, parentFile);
    }
}
