/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file.persistence;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JDBCFileRegistry implements IFileRegistry {

    private static final Map CACHE = new HashMap();
    private static final boolean INFO = false;
    private static Connection connection;

    public JDBCFileRegistry() throws Exception {
        this(ClientFileDomainJumper.getProperty("driver"), ClientFileDomainJumper.getProperty("url"), ClientFileDomainJumper.getProperty("username"), ClientFileDomainJumper.getProperty("password"));
    }

    public JDBCFileRegistry(String driver, String url, String username, String password) throws Exception {
        if (connection == null || connection.isClosed()) {
            if (driver == null || driver.isEmpty()) {
                driver = "org.h2.Driver";
            }
            if (url == null || url.isEmpty()) {
                url = "jdbc:h2:file:~/fileregistrydb";
            }
            if (username == null || username.isEmpty()) {
                username = "sa";
            }
            if (password == null) {
                password = "";
            }
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
            PreparedStatement st = connection.prepareStatement("create table IF NOT EXISTS fileregistry(domainname varchar(255), filename varchar(255), filesize bigint, filedate datetime, createdat datetime default CURRENT_TIMESTAMP, updatedat datetime default CURRENT_TIMESTAMP, PRIMARY KEY(domainname,filename,filesize,filedate));");
            st.executeUpdate();
        }
    }

    @Override
    public boolean isRegistrated(int configurationIdex, String domainName, File file) throws Exception {
        String fileName = file.getAbsolutePath();
        BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        long fileSize = file.length();
        String inCache = (String) CACHE.get(domainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis());
        if (inCache != null) {
            return true;
        }
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("select * from fileregistry where domainname=? and filename=? and filesize=? and filedate=?");
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, domainName);
        st.setString(2, fileName);
        st.setLong(3, fileSize);
        st.setDate(4, new Date(fileDate.toMillis()));
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        ResultSet r = st.executeQuery();
        if (r.next()) {
            if (INFO) System.out.println("is registrated");
            CACHE.put(domainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis(), "");
            return true;
        } else {
            if (INFO) System.out.println("is not registrated: " + fileName + " to domain " + domainName);
            return false;
        }
    }

    @Override
    public void registerFile(int configurationIdex, String domainName, File file) throws Exception {
        String fileName = file.getAbsolutePath();
        BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        long fileSize = file.length();
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("insert into fileregistry(domainname,filename,filesize,filedate) values(?,?,?,?)");
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, domainName);
        st.setString(2, fileName);
        st.setLong(3, fileSize);
        st.setDate(4, new Date(fileDate.toMillis()));
        st.executeUpdate();
        CACHE.put(domainName + "." + fileName + "." + fileSize + "." + fileDate.toMillis(), "");
    }
}
