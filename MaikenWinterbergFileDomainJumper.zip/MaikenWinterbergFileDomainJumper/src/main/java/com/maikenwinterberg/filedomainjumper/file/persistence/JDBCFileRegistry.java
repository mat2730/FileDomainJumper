/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file.persistence;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JDBCFileRegistry implements IFileRegistry {

    private static final boolean INFO = true;
    private static Connection connection;

    public JDBCFileRegistry() throws Exception {
        this(Registry.getProperty("driver"), ClientFileDomainJumper.getProperty("url"), ClientFileDomainJumper.getProperty("username"), ClientFileDomainJumper.getProperty("password"));
    }

    public JDBCFileRegistry(String driver, String url, String username, String password) throws Exception {
        if (connection == null || connection.isClosed()) {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:file:~/fileregistrydb", "sa", "");
            PreparedStatement st = connection.prepareStatement("create table IF NOT EXISTS fileregistry(domainname varchar(255), filename varchar(255), filesize bigint, filedate datetime, createdat datetime default CURRENT_TIMESTAMP, updatedat datetime default CURRENT_TIMESTAMP, PRIMARY KEY(domainname,filename,filesize,filedate));");
            st.executeUpdate();
        }
    }

    @Override
    public boolean isRegistrated(int configurationIdex, String domainName, File file) throws Exception {
        String fileName = file.getAbsolutePath();
        BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        long fileSize = file.length();
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("select * from fileregistry where domainname=? and filename=? and filesize=? and filedate=?");
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, domainName);
        st.setString(2, fileName);
        st.setLong(3, fileSize);
        st.setDate(4, new Date(fileDate.toMillis()));
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        ResultSet r = st.executeQuery();
        if (r.next()) {
            System.out.println("is registrated");
            return true;
        }
        else {
            System.out.println("is not registrated");
            return false;
        }
    }

    @Override
    public void registerFile(int configurationIdex, String domainName, File file) throws Exception {
        String fileName = file.getAbsolutePath();
        BasicFileAttributes attr = Files.readAttributes(file.toPath(), BasicFileAttributes.class);
        FileTime fileDate = attr.lastModifiedTime();
        long fileSize = file.length();
        StringBuilder sqlBuf = new StringBuilder();
        sqlBuf.append("insert into fileregistry(domainname,filename,filesize,filedate) values(?,?,?,?)");
        if (INFO) {
            System.out.println(sqlBuf.toString());
        }
        PreparedStatement st = connection.prepareStatement(sqlBuf.toString());
        st.setString(1, domainName);
        st.setString(2, fileName);
        st.setLong(3, fileSize);
        st.setDate(4, new Date(fileDate.toMillis()));
        st.executeUpdate();
    }
}
