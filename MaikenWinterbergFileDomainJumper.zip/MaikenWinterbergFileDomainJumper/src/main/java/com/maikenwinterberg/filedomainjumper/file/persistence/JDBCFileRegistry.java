/*
 * Martin Alexander Thomsen den 18 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file.persistence;

import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.socketregistry.server.Registry;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class JDBCFileRegistry implements IFileRegistry {

    private static Connection connection;

    public JDBCFileRegistry() throws Exception {
        this(Registry.getProperty("driver"), ClientFileDomainJumper.getProperty("url"), ClientFileDomainJumper.getProperty("username"), ClientFileDomainJumper.getProperty("password"));
    }

    public JDBCFileRegistry(String driver, String url, String username, String password) throws Exception {
        if (connection == null || connection.isClosed()) {
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection("jdbc:h2:file:~/registrydb", "sa", "");
            PreparedStatement st = connection.prepareStatement("create table IF NOT EXISTS fileregistry(type varchar(10), domainname varchar(255), servicename varchar(255), attributes varchar(4048), public_key varchar(4048), createdat datetime default CURRENT_TIMESTAMP, updatedat datetime default CURRENT_TIMESTAMP, PRIMARY KEY(type,domainname,servicename));");
            st.executeUpdate();
        }
    }

    @Override
    public boolean isRegistrated(int configurationIdex, String domainName, File file) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void registerFile(int configurationIdex, String domainName, File file) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}