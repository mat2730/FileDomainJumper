/*
 * Martin Alexander Thomsen den 10 Juli 2024
 */
package com.maikenwinterberg.filedomainjumper.file;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.maikenwinterberg.filedomainjumper.ClientFileDomainJumper;
import com.maikenwinterberg.filedomainjumper.FileDomainJumper;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.inBox;
import static com.maikenwinterberg.filedomainjumper.file.IFileProces.DEST.outBox;

/**
 * @author Martin Alexander Thomsen
 * @author Ron Georg Martin Richard
 * @see documentnetwork.com
 * @see maikenwinterberg.com
 */
public class ProcessFile {

    private final static IFileProces DEFAULT_FILE_PROCESSER = new StayPutUntilSentFileProcess();
    private final static Map<Integer, IFileProces> FILE_PROCESSERS = new HashMap();

    public static File processFile(int configurationIndex, List<String> okDomains, List<String> notOkDomains, String path, File fileFromInbox, IFileProces.DEST destination) throws Exception {
        return newInstance(configurationIndex, destination).processFile(configurationIndex, okDomains, notOkDomains, path, fileFromInbox, destination);
    }

    public static boolean doProcessFile(int configurationIndex, String receiverDomainName, File file) throws Exception {
        //this method is only called from outbox
        return newInstance(configurationIndex, IFileProces.DEST.outBox).doProcessFile(configurationIndex, receiverDomainName, file);
    }

    public static IFileProces newInstance(int configurationIndex, IFileProces.DEST destination) throws Exception {
        IFileProces p = FILE_PROCESSERS.get(configurationIndex);
        if (p != null) {
            return p;
        }
        //inti className
        String className = null;
        if (null != destination) {
            switch (destination) {
                case doneWithBox -> {

                }
                case outBox -> {
                    String defaultFileProcesser = ClientFileDomainJumper.getProperty("defaultFileProcesser");
                    className = ClientFileDomainJumper.getProperty(configurationIndex + ".fileProcesser");
                    if (className == null || className.trim().isEmpty()) {
                        className = defaultFileProcesser;
                    }
                    break;
                }
                case inBox -> {
                    String defaultFileProcesser = FileDomainJumper.getProperty("defaultFileProcesser");
                    className = FileDomainJumper.getProperty(configurationIndex + ".fileProcesser");
                    if (className == null || className.trim().isEmpty()) {
                        className = defaultFileProcesser;
                    }
                    break;
                }
                default -> {
                }
            }
        }
        //process class
        if (className != null && !className.trim().isEmpty()) {
            try {
                p = (IFileProces) Class.forName(className).newInstance();
                FILE_PROCESSERS.put(configurationIndex, p);
                return p;
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        //default
        return DEFAULT_FILE_PROCESSER;
    }
}
