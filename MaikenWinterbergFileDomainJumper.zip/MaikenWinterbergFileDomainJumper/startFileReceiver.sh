java --class-path ./target/classes:./lib/MaikenWinterbergSocketRegistry-1.0-SNAPSHOT.jar com/maikenwinterberg/filedomainjumper/FileDomainJumper > log/fileReceiver.log
