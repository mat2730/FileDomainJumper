echo unInstalling service...
sudo systemctl stop MaikenWinterbergFileReceiver.service
sudo rm /etc/systemd/system/MaikenWinterbergFileReceiver.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s