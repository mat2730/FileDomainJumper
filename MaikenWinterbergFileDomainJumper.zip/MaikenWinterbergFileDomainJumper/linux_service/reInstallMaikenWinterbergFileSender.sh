echo installing service...
sudo systemctl stop MaikenWinterbergFileSender.service
sudo cp MaikenWinterbergFileSender.service /etc/systemd/system
sudo systemctl daemon-reload
sudo systemctl start MaikenWinterbergFileSender.service
sudo systemctl enable MaikenWinterbergFileSender.service
echo done installing service
#Ssleep 10s