echo unInstalling service...
sudo systemctl stop MaikenWinterbergFileSender.service
sudo rm /etc/systemd/system/MaikenWinterbergFileSender.service 
sudo systemctl daemon-reload
echo done unInstalling service
sleep 10s